> async function chatWithGPT(your_qus) {
      const response = await fetch("https://tools.revesery.com/ai/ai.php?query=" + encodeURIComponent(your_qus), {
        method: "GET",
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.9999.999 Safari/537.36"
        }
      });

        const data = await response.json();
        return data.result;
}
 chatWithGPT('kamu siapa')
 
 > async function stickerSearch(querry) {
	const link = await axios.get(`https://getstickerpack.com/stickers?query=${querry}`);
	const $ = cheerio.load(link.data)
	let sticker1 = {
		sticker: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(1) > a > div > img').attr('src'),
		nama: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(1) > a > div > span.title').text().trim(),
		creator: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(1) > a > div > span.username').text().trim()
	}
	let sticker2 = {
		sticker: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(2) > a > div > img').attr('src') ,
		nama: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(2) > a > div > span.title').text().trim() ,
		creator: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(2) > a > div > span.username').text().trim() 
	}
	let sticker3 = {
		sticker: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(3) > a > div > img').attr('src') ,
		nama: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(3) > a > div > span.title').text().trim() ,
		creator: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(3) > a > div > span.username').text().trim() 
	}
	let sticker4 = {
		sticker: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(4) > a > div > img').attr('src') ,
		nama: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(4) > a > div > span.title').text().trim() ,
		creator: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(4) > a > div > span.username').text().trim() 
	}
	let sticker5 = {
		sticker: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(5) > a > div > img').attr('src') ,
		nama: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(5) > a > div > span.title').text().trim() ,
		creator: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(5) > a > div > span.username').text().trim() 
	}
	let sticker6 = {
		sticker: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(6) > a > div > img').attr('src') ,
		nama: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(6) > a > div > span.title').text().trim() ,
		creator: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(6) > a > div > span.username').text().trim() 
	}
	let sticker7 = {
		sticker: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(7) > a > div > img').attr('src') ,
		nama: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(7) > a > div > span.title').text().trim() ,
		creator: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(7) > a > div > span.username').text().trim() 
	}
	let sticker8 = {
		sticker: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(8) > a > div > img').attr('src') ,
		nama: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(8) > a > div > span.title').text().trim() ,
		creator: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(8) > a > div > span.username').text().trim() 
	}
	let sticker9 = {
		sticker: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(9) > a > div > img').attr('src') ,
		nama: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(9) > a > div > span.title').text().trim() ,
		creator: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(9) > a > div > span.username').text().trim() 
	}
	let sticker10 = {
		sticker: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(10) > a > div > img').attr('src') ,
		nama: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(10) > a > div > span.title').text().trim() ,
		creator: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(10) > a > div > span.username').text().trim() 
	}
	let sticker11 = {
		sticker: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(11) > a > div > img').attr('src') ,
		nama: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(11) > a > div > span.title').text().trim() ,
		creator: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(11) > a > div > span.username').text().trim() 
	}
	let sticker12 = {
		sticker: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(12) > a > div > img').attr('src') ,
		nama: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(12) > a > div > span.title').text().trim() ,
		creator: $('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(12) > a > div > span.username').text().trim() 
	}
	let stickerlop =  [
		$('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(1) > a > div > img').attr('src'),
		$('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(2) > a > div > img').attr('src'),
		$('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(3) > a > div > img').attr('src'),
		$('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(4) > a > div > img').attr('src'),
		$('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(5) > a > div > img').attr('src'),
		$('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(6) > a > div > img').attr('src'),
		$('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(7) > a > div > img').attr('src'),
		$('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(8) > a > div > img').attr('src'),
		$('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(9) > a > div > img').attr('src'),
		$('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(10) > a > div > img').attr('src'),
		$('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(11) > a > div > img').attr('src'),
		$('#stickerPacks').find('div > div:nth-child(3) > div:nth-child(12) > a > div > img').attr('src')
	]
let data = {
		sticker: stickerlop, sticker1, sticker2, sticker3, sticker4, sticker5, sticker6, sticker7, sticker8, sticker9, sticker10, sticker11, sticker12
	}
	return data
}
stickerSearch ('pentol')

> function quotesAnime() {
    return new Promise((resolve, reject) => {
        const page = Math.floor(Math.random() * 184)
        axios.get('https://otakotaku.com/quote/feed/'+page)
        .then(({ data }) => {
            const $ = cheerio.load(data)
            const hasil = []
            $('div.kotodama-list').each(function(l, h) {
                hasil.push({
                    link: $(h).find('a').attr('href'),
                    gambar: $(h).find('img').attr('data-src'),
                    karakter: $(h).find('div.char-name').text().trim(),
                    anime: $(h).find('div.anime-title').text().trim(),
                    episode: $(h).find('div.meta').text(),
                    up_at: $(h).find('small.meta').text(),
                    quotes: $(h).find('div.quote').text().trim()
                })
            })
            resolve(hasil)
        }).catch(reject)
    })
}
quotesAnime()

> async function Couple() {
    try {
        const response = await fetch("https://tools.revesery.com/couple/revesery.php");

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        
        return data;
    } catch (error) {
        console.error(`An error occurred: ${error.message}`);
        throw error; // Rethrow the error to handle it further up the call stack
    }
}
 Couple ()
 
 > async function fetchUser(q) {
  const url = 'https://www.tiktokstalk.com/user/' + q;
  const response = await fetch(url);
  
  if (!response.ok) {
    throw 'Failed to fetch user data';
  }
  
  const html = await response.text();
  const $ = cheerio.load(html);

  const formattedNumber = numStr => {
    const num = parseInt(numStr.replace(/[^\d]/g, ''), 10);
    return isNaN(num) ? 'NaN' : num.toLocaleString();
  };

  const userInformation = {
    profileImage: $('.user-info figure img').attr('src'),
    username: $('.user-info .title h1').text().trim(),
    fullName: $('.user-info .title h2').text().trim(),
    bio: $('.user-info .description p').text().trim(),
    likes: formattedNumber($('.number-box .count:eq(0)').text()),
    followers: formattedNumber($('.number-box .count:eq(1)').text()),
    following: formattedNumber($('.number-box .count:eq(2)').text())
  };

  return userInformation;
}

fetchUser('avosky')

> async function asu() {
    return new Promise((resolve, reject) => {
        const page = Math.floor(Math.random() * 1153)
        axios.get('https://sfmcompile.club/page/'+page)
        .then((data) => {
            const $ = cheerio.load(data.data)
            const hasil = []
            $('#primary > div > div > ul > li > article').each(function (a, b) {
                hasil.push({
                    title: $(b).find('header > h2').text(),
                    link: $(b).find('header > h2 > a').attr('href'),
                    category: $(b).find('header > div.entry-before-title > span > span').text().replace('in ', ''),
                    share_count: $(b).find('header > div.entry-after-title > p > span.entry-shares').text(),
                    views_count: $(b).find('header > div.entry-after-title > p > span.entry-views').text(),
                    type: $(b).find('source').attr('type') || 'image/jpeg',
                    video_1: $(b).find('source').attr('src') || $(b).find('img').attr('data-src'),
                    video_2: $(b).find('video > a').attr('href') || ''
                })
            })
            resolve(hasil)
        })
    })
}
asu()

> async function randomgore() {
  return new Promise(async (resolve, reject) => {
    rand = Math.floor(Math.random() * 218) + 1;
    randvid = Math.floor(Math.random() * 16) + 1;
    if (rand === 1) {
      slink = 'https://seegore.com/gore/';
    } else {
      slink = `https://seegore.com/gore/page/${rand}/`;
    }
    axios.get(slink)
      .then(({ data }) => {
        const $ = cheerio.load(data);
        const link = [];
        const result = [];
        const username = [];
        const linkp = $(`#post-items > li:nth-child(${randvid}) > article > div.post-thumbnail > a`).attr('href');
        const thumbb = $(`#post-items > li:nth-child(${randvid}) > article > div.post-thumbnail > a > div > img`).attr('src');
        axios.get(linkp)
          .then(({ data }) => {
            const $$ = cheerio.load(data);
            const format = {
              judul: $$('div.single-main-container > div > div.bb-col.col-content > div > div > div > div > header > h1').text(),
              views: $$('div.single-main-container > div > div.bb-col.col-content > div > div > div > div > div.s-post-meta-block.bb-mb-el > div > div > div.col-r.d-table-cell.col-md-6.col-sm-6.text-right-sm > div > span > span.count').text(),
              comment: $$('div.single-main-container > div > div.bb-col.col-content > div > div > div > div > div.s-post-meta-block.bb-mb-el > div > div > div.col-r.d-table-cell.col-md-6.col-sm-6.text-right-sm > div > a > span.count').text() == '' ? 'Tidak ada komentar' : $$('div.single-main-container > div > div.bb-col.col-content > div > div > div > div > div.s-post-meta-block.bb-mb-el > div > div > div.col-r.d-table-cell.col-md-6.col-sm-6.text-right-sm > div > a > span.count').text(),
              thumb: thumbb,
              link: $$('video > source').attr('src')
            };
            const result = {
              creator: 'Lenttobs',
              data: format
            };
            resolve(result);
          })
          .catch(reject);
      });
  });
}
randomgore ()

> function igstalk(username) {
  return new Promise(async (resolve, reject) => {
    try {
      const { data } = await axios.get("https://www.inststalk.com/search?user=" + username)
      const $ = cheerio.load(data)
      const search = $("div.row > div.col-sm-6.col-md-4.col-lg-3").map((_, el) => {
        return {
          username: $(el).find("a").attr("title"),
          img: $(el).find("a > div.user-image > div.background.lazy").attr("data-src"),
         url: "https://www.inststalk.com" + $(el).find("a").attr("href")
        }
      }).get()
      if (search.length == 0) throw "User Not Found!"
      const response = await axios.get(search[0].url)
      const $$ = cheerio.load(response.data)
      const result = {
        status: 200,
        profile: $$("div.user-info > figure > img").attr("src"),
        username: $$("div.user-info > div.article div.top div.title > h1").text().trim(),
        name: $$("div.user-info > div.article div.top div.title > h2").text().trim(),       
        description: $$("div.user-info > div.article > div.description > p").text().trim(), 
        posts: $$("div.col-lg-5.separate-column > div.row > div.col > div.number-box > .count").eq(0).text().trim(),
        followers: $$("div.col-lg-5.separate-column > div.row > div.col > div.number-box > .count").eq(1).text().trim(),
        following: $$("div.col-lg-5.separate-column > div.row > div.col > div.number-box > .count").eq(2).text().trim()
      } 
      resolve(result)
    } catch (e) {
      console.log(e)
      reject({
        status: 300,
        message: "User Not Found"
      })
    }
  })
}
igstalk('jokowi')

> async function artinama(value) {
    return new Promise((resolve, reject) => {
        axios.get('https://primbon.com/arti_nama.php?nama1='+value+'&proses=+Submit%21+')
        .then(({ data }) => {
            let $ = cheerio.load(data)
            let fetchText = $('#body').text()
            let hasil
            try {
                hasil = {
                    status: true,
                    message: {
                        nama: value,
                        arti: fetchText.split('memiliki arti: ')[1].split('Nama:')[0].trim(),
                        catatan: 'Gunakan juga aplikasi numerologi Kecocokan Nama, untuk melihat sejauh mana keselarasan nama anda dengan diri anda.'
                    }
                }
            } catch {
                hasil = {
                    status: false,
                    message: `Tidak ditemukan arti nama "${value}" Cari dengan kata kunci yang lain.`
                }
            }
            resolve(hasil)
        })
    })
}
artinama('Kuncoro')

> function hentai() {
    return new Promise((resolve, reject) => {
        const page = Math.floor(Math.random() * 1153)
        axios.get('https://sfmcompile.club/page/'+page)
        .then((data) => {
            const $ = cheerio.load(data.data)
            const hasil = []
            $('#primary > div > div > ul > li > article').each(function (a, b) {
                hasil.push({
                    title: $(b).find('header > h2').text(),
                    link: $(b).find('header > h2 > a').attr('href'),
                    category: $(b).find('header > div.entry-before-title > span > span').text().replace('in ', ''),
                    share_count: $(b).find('header > div.entry-after-title > p > span.entry-shares').text(),
                    views_count: $(b).find('header > div.entry-after-title > p > span.entry-views').text(),
                    type: $(b).find('source').attr('type') || 'image/jpeg',
                    video_1: $(b).find('source').attr('src') || $(b).find('img').attr('data-src'),
                    video_2: $(b).find('video > a').attr('href') || ''
                })
            })
            resolve(hasil)
        })
    })
}
hentai()

> async function searchGif(query) {
  const url = `http://www.pornhub.com/gifs/search?search=${query}`;
  const response = await fetch(url);
  const html = await response.text();
  const $ = cheerio.load(html);
  
  const gifs = $('ul.gifs.gifLink li');

    return gifs.map((i, gif) => {
      const data = $(gif).find('a');

      return {
        title: data.find('span').text(),
        url: 'http://dl.phncdn.com#id#.gif'.replace('#id#', data.attr('href')),
        webm: data.find('video').attr('data-webm'),
      };
    }).get();
}
searchGif('indonesia')

> function ghrepo(e) {
  return new Promise(async (t, a) => {
    await axios
      .get(`https://api.github.com/search/repositories?q=${e}`, {
        headers: { Authorization: "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" },
      })
      .then((e) => {
        if (200 == e.status) {
          const a = e.data.items;
          (data = {}),
            (data.code = 0 == e.data.total_count ? 404 : 200),
            (data.message = 0 == e.data.total_count ? " Not found" : "OK"),
            
            (data.totalCount = e.data.total_count),
            (data.items = []),
            0 != data.totalCount
              ? a.forEach((e) => {
                  data.items.push({
                    id: e.id,
                    nodeId: e.node_id,
                    nameRepo: e.name,
                    fullNameRepo: e.full_name,
                    url_repo: e.html_url,
                    description: e.description,
                    git_url: e.git_url,
                    ssh_url: e.ssh_url,
                    clone_url: e.clone_url,
                    svn_url: e.svn_url,
                    homepage: e.homepage,
                    stargazers: e.stargazers_count,
                    watchers: e.watchers,
                    forks: e.forks,
                    defaultBranch: e.default_branch,
                    language: e.language,
                    isPrivate: e.private,
                    isFork: e.fork,
                    createdAt: e.created_at,
                    updatedAt: e.updated_at,
                    pushedAt: e.pushed_at,
                    author: {
                      username: e.owner.login,
                      id_user: e.owner.id,
                      avatar_url: e.owner.avatar_url,
                      user_github_url: e.owner.html_url,
                      type: e.owner.type,
                      isSiteAdmin: e.owner.site_admin,
                    },
                  });
                })
              : (data.items = []),
            t(data);
        } else a({ code: 500, status: !1, message: "Server Bermasalah" });
      })
      .catch((e) => {
        a(e);
      });
  });
}
 ghrepo('lenttobs')