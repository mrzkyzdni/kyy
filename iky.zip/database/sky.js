require('./config')
require('./menu2')
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys')
const fs = require('fs')
const fsx = require('fs-extra')
const util = require('util')
const BodyForm = require('form-data')
const yts = require('yt-search')
const { fromBuffer } = require('file-type')
const chalk = require('chalk')
const { v4: uuidv4 } = require('uuid')
const { exec, spawn, execSync } = require("child_process")
const axios = require('axios')
const path = require('path')
const users = {};
const antiEmote = true;
const emojiRegex = /\p{Emoji}/u;
const notes = {}; // Objek untuk menyimpan catatan pengguna
const pasienSakit = {};
const obatTersedia = ['Paracetamol', 'Antibiotik', 'Vitamin C', 'Obat Pusing'];
const obatDokter = {};
const StickerXeon = JSON.parse(fs.readFileSync('./database/xeonsticker.json'))
const os = require('os')
const fetch = require('node-fetch');
const cheerio = require('cheerio');
const moment = require('moment-timezone')
const { JSDOM } = require('jsdom')
let { Image } = require('node-webpmux')
const { smims } = require('./lib/uploadImage')
const crypto = require('crypto');
const Jimp = require('jimp');
const { mediafireDl } = require('./lib/mediafire.js')
const { fetchBuffer, buffergif, pickRandom } = require("./lib/myfunc2")
const speed = require('performance-now')

const { performance } = require('perf_hooks')
const { Primbon } = require('scrape-primbon')
const textpro2 = require('./lib/textpro2')
const anon = require('./lib/menfess')
const ytdl = require('ytdl-core')
const primbon = new Primbon()
const { smsg, formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins } = require('./lib/myfunc')

// read database
let tebaklagu = db.data.game.tebaklagu = []
let _family100 = db.data.game.family100 = []
let kuismath = db.data.game.math = []
let tebakgambar = db.data.game.tebakgambar = []
let tebakkata = db.data.game.tebakkata = []
let caklontong = db.data.game.lontong = []
let caklontong_desk = db.data.game.lontong_desk = []
let tebakkalimat = db.data.game.kalimat = []
let tebaklirik = db.data.game.lirik = []
let tebaktebakan = db.data.game.tebakan = []
let isGameActive = false;
let isactiveFishingGames = false;
let players = null; // Daftar ID pemain dalam permainan
let impostorId = null; //ID
let secretWord = null; // Kata yang akan ditebak
let tagCount = {}; // Menyimpan jumlah tag yang telah dikirim
let tagQueue = {}; // Menyimpan antrian tag untuk setiap 
const activeGames = {};
let requiredClaps = 0;
const activeFishingGames = {};
let players1 = {};
let totalClaps = 0;
let conversationState = null;
let kirimpesan = true;
let registeredUsers = {};
let gameInProgress = false;
let playerAlive = true;
let spamCounter = {};
const adventures = [
    "Anda menemukan gua yang misterius. Apakah Anda akan masuk? (ya/tidak)",
    "Anda bertemu monster di hutan. Apakah Anda akan melawan? (ya/tidak)",
    "Anda menemukan harta karun yang tersembunyi. Apakah Anda akan mengambilnya? (ya/tidak)"
];
const chatURL = 'https://beta.character.ai/chat2?char=-p04V7wg7AT5CcJumGnEB2LVWdjvuJEfVjs1P3LOSwo';  

const results = [
    "Selamat! Anda berhasil menemukan harta yang berlimpah.",
    "Sayang sekali, Anda kalah dalam pertarungan melawan monster.",
    "Anda mendapat kutukan setelah mengambil harta karun. Sebaiknya hati-hati."
];

//DB
let autosticker = JSON.parse(fs.readFileSync('./database/autosticker.json'))
let ntvirtex = JSON.parse(fs.readFileSync('./database/antivirus.json'))
let nttoxic = JSON.parse(fs.readFileSync('./database/antitoxic.json'))
let ntwame = JSON.parse(fs.readFileSync('./database/antiwame.json'))
let welcome = JSON.parse(fs.readFileSync("./database/welcome.json"));
let ntlinkgc =JSON.parse(fs.readFileSync('./database/antilinkgc.json'))
let ntlinkall =JSON.parse(fs.readFileSync('./database/antilinkall.json'))
let ntibatu =JSON.parse(fs.readFileSync('./database/antibatu.json'))
let ntiemoji =JSON.parse(fs.readFileSync('./database/antiemoji.json'))
let simion = JSON.parse(fs.readFileSync('./database/simion.json'))
let bacat = JSON.parse(fs.readFileSync('./database/bacat.json'))
let ntilinktwt =JSON.parse(fs.readFileSync('./database/antilinktwitter.json'))
let owner = JSON.parse(fs.readFileSync('./database/owner.json'))
let ntilinktt =JSON.parse(fs.readFileSync('./database/antilinktiktok.json'))
let ntilinktg =JSON.parse(fs.readFileSync('./database/antilinktelegram.json'))
let ntilinkfb =JSON.parse(fs.readFileSync('./database/antilinkfacebook.json'))
let akinator = JSON.parse(fs.readFileSync('./src/akinator.json'))
let ntilinkig =JSON.parse(fs.readFileSync('./database/antilinkinstagram.json'))
let ntilinkyt =JSON.parse(fs.readFileSync('./database/antilinkyt.json'))
const banned = JSON.parse(fs.readFileSync('./database/banned.json'))
const prem = JSON.parse(fs.readFileSync('./database/premium.json'))
module.exports = sky = async (sky, m, chatUpdate, store) => {
    try {
        var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
        var budy = (typeof m.text == 'string' ? m.text : '')
        var prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix
        global.prefix = prefix
        const isCmd = body.startsWith(prefix)
        const from = m.key.remoteJid
        const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()        
        var args = body.trim().split(/ +/).slice(1)
        var args1 = body.trim().split(/ +/).slice(1)
        args = args.concat(['','','','','',''])
        const totalFitur = () =>{
            var mytext = fs.readFileSync("./sky.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
        const pushname = m.pushName || "No Name"
        const botNumber = await sky.decodeJid(sky.user.id)
        const isCreator = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const itsMe = m.sender == botNumber ? true : false
        const text = q = args.join(" ").trim()
        const fatkuns = (m.quoted || m)         
        const isGroup = from.endsWith("@g.us");        
        const isBan = banned.includes(m.sender)
        const quoted = (fatkuns.mtype == 'buttonsMessage') ? fatkuns[Object.keys(fatkuns)[1]] : (fatkuns.mtype == 'templateMessage') ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] : (fatkuns.mtype == 'product') ? fatkuns[Object.keys(fatkuns)[0]] : m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const qmsg = (quoted.msg || quoted)
        const mentionByTag = m.sender
        const mentionByReply = m.sender
        const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
        const isMedia = /image|video|sticker|audio/.test(mime)
//GROUP
        const isAutoSticker = m.isGroup ? autosticker.includes(from) : false
        const antiVirtex = m.isGroup ? ntvirtex.includes(from) : false
        const Antilinkgc = m.isGroup ? ntlinkgc.includes(m.chat) : false
        const AntiLinkYt = m.isGroup ? ntilinkyt.includes(from) : false
        const AntiBatu = m.isGroup ? ntibatu.includes(from) : false
        const antiEmote = m.isGroup ? ntiemoji.includes(from) : false
        const SimiActive = m.isGroup ? simion.includes(from) : false
        const AntiLinkInstagram = m.isGroup ? ntilinkig.includes(from) : false
        const AntiLinkFacebook = m.isGroup ? ntilinkfb.includes(from) : false
        const AntiLinkTiktok = m.isGroup ? ntilinktt.includes(from) : false
        const bocet = m.isGroup ? bacat.includes(from) : false
        const antilinkinstagram = m.isGroup ? ntilinktg.includes(from) : false
        const AntiLinkTelegram = m.isGroup ? ntilinktg.includes(from) : false
        const isWelcome = m.isGroup ? welcome.includes(m.chat) : false;
        const AntiLinkTwitter = m.isGroup ? ntilinktwt.includes(from) : false
        const AntiLinkAll = m.isGroup ? ntlinkall.includes(from) : false
        const antiToxic = m.isGroup ? nttoxic.includes(from) : false
        const antiWame = m.isGroup ? ntwame.includes(from) : false      
        // Group
        const groupMetadata = m.isGroup ? await sky.groupMetadata(m.chat).catch(e => {}) : ''
        const groupName = m.isGroup ? groupMetadata.subject : ''         
        const participants = m.isGroup ? await groupMetadata.participants : ''
        const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
    	const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
    	const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
        const isPrem = prem.includes(m.sender)
    	const isPremium = isCreator || global.premium.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender) || false
	try {
            let isNumber = x => typeof x === 'number' && !isNaN(x)
            let limitUser = isPremium ? global.limitawal.premium : global.limitawal.free
            let BalanceUser = isPremium ? global.balanceawal.premium : global.balanceawal.free
            let user = db.data.users[m.sender];
if (typeof user !== 'object') db.data.users[m.sender] = {};
if (user) {    
    if (!isNumber(user.limit)) user.limit = limitUser;
    if (!isNumber(user.balance)) user.balance = BalanceUser;
    if (!isNumber(user.gold)) user.gold = 0;
    if (!isNumber(user.silver)) user.silver = 0;
    if (!isNumber(user.emerald)) user.emerald = 0;
    if (!isNumber(user.potion)) user.potion = 0;
} else {
    global.db.data.users[m.sender] = {
        afkTime: -1,
        afkReason: '',
        limit: limitUser,
        balance: BalanceUser,
        gold: 0,
        silver: 0,
        emerald: 0,
        potion: 0,
        premium: false
    };
}            
 // Days
        const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')


        const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if(time2 < "23:59:00"){
        var ucapanWaktu = 'Selamat Malam 🏙️'
        }
        if(time2 < "19:00:00"){
        var ucapanWaktu = 'Selamat Petang 🌆'
        }
        if(time2 < "18:00:00"){
        var ucapanWaktu = 'Selamat Sore 🌇'
        }
        if(time2 < "15:00:00"){
        var ucapanWaktu = 'Selamat Siang 🌤️'
        }
        if(time2 < "10:00:00"){
        var ucapanWaktu = 'Selamat Pagi 🌄'
        }
        if(time2 < "05:00:00"){
        var ucapanWaktu = 'Selamat Subuh 🌆'
        }
        if(time2 < "03:00:00"){
        var ucapanWaktu = 'Selamat Tengah Malam 🌃'
        }    
            let chats = db.data.chats[m.chat]
            if (typeof chats !== 'object') db.data.chats[m.chat] = {}
            if (chats) {
                if (!('mute' in chats)) chats.mute = false
                if (!('antilink' in chats)) chats.antilink = false
                if (!('antipushkontakv1' in chats)) chats.antivirtex = true
                if (!('antipushkontakv2' in chats)) chats.antivirtex = true
            } else global.db.data.chats[m.chat] = {
                mute: false,
                antilink: false,
                antipushkontakv1: false,
                antipushkontakv2: false,
            }
	    let setting = db.data.settings[botNumber]
        if (typeof setting !== 'object') db.data.settings[botNumber] = {}
	    if (setting) {
    	    if (!('anticall' in setting)) setting.anticall = true
    		if (!isNumber(setting.status)) setting.status = 0
    		if (!('autobio' in setting)) setting.autobio = false
	    } else global.db.data.settings[botNumber] = {
    	    anticall: true,
    		status: 0,
    		autobio: false
	    }
	    
        } catch (err) {
            console.error(err)
        }
	      const fkontak = {
            key: {
                participant: `0@s.whatsapp.net`,
                ...(m.chat ? {
                    remoteJid: `status@broadcast`
                } : {})
            },
            message: {
                'contactMessage': {
                    'displayName': `${pushname}`,
                    'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${botname},;;;\nFN:${botname}\nitem1.TEL;waid=${owner}:+${owner}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
                    'jpegThumbnail': thumb,
                    thumbnail: thumb,
                    sendEphemeral: true
                }   
            }
        }
 if (m.chat.endsWith('@s.whatsapp.net') && !isCmd) {
let room = Object.values(anon.anonymous).find(p => p.state == "CHATTING" && p.check(sender))
if (room) {
let other = room.other(sender)
m.copyNForward(other, true, m.quoted && m.quoted.fromMe ? {
contextInfo: {
...m.msg.contextInfo,
forwardingScore: 0,
isForwarded: true,
participant: other
}
} : {})
}
}
//
//
const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}
if (spamCounter[sender]) {
    spamCounter[sender]++;
    if (spamCounter[sender] === 8) {
        sky.groupParticipantsUpdate(m.chat, [sender], 'remove');
        m.reply('Kamu telah di-kick karena mengirim spam berturut-turut sebanyak 8 kali.');
        delete spamCounter[sender]; // Hapus dari daftar spamCounter
    } else {
        setTimeout(() => {
            delete spamCounter[sender];
        }, 3000); // 10000 milidetik = 10 detik
    }
} else {
    spamCounter[sender] = 1;
}

        // Public & Self
        if (!sky.public) {
            if (!m.key.fromMe) return
        }        
//Download Mp4
const downloadMp4 = async (Link ) => {
try{
await ytdl.getInfo(Link);
let mp4File = getRandom('.mp4') 
let nana = ytdl(Link)
.pipe(fs.createWriteStream(mp4File))
.on("finish", async () => {    
await sky.sendMessage(from, { contextInfo: {externalAdReply: {showAdAttribution: true, title: `${q}`, mediaType: 3,  renderLargerThumbnail : true, sourceUrl: `https://wa.me/6283870640443`																														
}}, video: fs.readFileSync(mp4File), caption: `${mess.success}`,gifPlayback: false},{quoted: m})			
fs.unlinkSync(`./${mp4File}`)
})     
} catch(err) {
m.reply(`${err}`)
}
}
//Download Mp3
const downloadMp3 = async (Link ) => {
try{
await ytdl.getInfo(Link);
let mp3File = getRandom('.mp3') 
ytdl(Link, {filter: 'audioonly'})
.pipe(fs.createWriteStream(mp3File))
.on("finish", async () => {  
await sky.sendMessage(from, { audio:  fs.readFileSync(mp3File), mimetype: 'audio/mp4' },{ quoted: m })
fs.unlinkSync(mp3File)
})       
} catch (err){
console.log(color(err))
}
}
function sendLiveLocation(to, locationData, duration, options = {}) {
    const msg = {
        location: locationData,
        liveLocation: true,
        liveDuration: duration
    };
    sky.sendMessage(to, msg, options);
}

function sendOTP(number) {
  const otp = Math.floor(1000 + Math.random() * 9000);
  registeredUsers[number] = { otp };
    sky.sendText(sender, `OTP untuk ${number}: ${otp}`);
}

//ADDG
async function jarak(from, to) {
	let html = (await axios(`https://www.google.com/search?q=${encodeURIComponent('jarak ' + from + ' to ' + to)}&hl=id`)).data
	let $ = cheerio.load(html), obj = {}
	let img = html.split("var s=\'")?.[1]?.split("\'")?.[0]
	obj.img = /^data:.*?\/.*?;base64,/i.test(img) ? Buffer.from(img.split`,` [1], 'base64') : ''
	obj.desc = $('div.BNeawe.deIvCb.AP7Wnd').text()?.trim()
	return obj
}
async function addExif(buffer, packname, author, categories = [''], extra = {}) {
	const img = new Image()
	const json = { 'sticker-pack-id': 'parel-kntll', 'sticker-pack-name': packname, 'sticker-pack-publisher': author, 'emojis': categories, 'is-avatar-sticker': 1, ...extra }
	let exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
	let jsonBuffer = Buffer.from(JSON.stringify(json), 'utf8')
	let exif = Buffer.concat([exifAttr, jsonBuffer])
	exif.writeUIntLE(jsonBuffer.length, 14, 4)
	await img.load(buffer)
	img.exif = exif
	return await img.save(null)
}
async function loading () {
var hawemod = [
"🟨🟨🟨🟨🟨🟨🟨🟨",
"🟨🟦🟦🔲🔲🟦🟦🟨",
"🏽🏽🏽🏽🏽🏽🏽🏽",
"🏽⬜🟦🏽🏽🟦⬜🏽",
"🏽🏽🏽🏽🏽🏽🏽🏽",
"🏽🏽🟫🏽🏽🟫🏽🏽",
"🏽🏽🟫🟫🟫🟫🏽🏽",
"NARUTO",
]
let { key } = await sky.sendMessage(from, {text: 'ʟᴏᴀᴅɪɴɢ...'})//Pengalih isu

for (let i = 0; i < hawemod.length; i++) {
/*await delay(10)*/
await sky.sendMessage(from, {text: hawemod[i], edit: key });//PESAN LEPAS
}
}
async function skysend(chatId, message, options = {}){
    let generate = await generateWAMessage(chatId, message, options)
    let type2 = getContentType(generate.message)
    if ('contextInfo' in options) generate.message[type2].contextInfo = options?.contextInfo
    if ('contextInfo' in message) generate.message[type2].contextInfo = message?.contextInfo
    return await sky.relayMessage(chatId, generate.message, { messageId: generate.key.id })
}
async function getLatestAnime() {
  try {
    const response = await axios.get('https://myanimelist.net/anime/season');
    const $ = cheerio.load(response.data);
    
    const animeList = [];
    
    $('div.seasonal-anime').each((index, element) => {
      const title = $(element).find('div.title-text').text().trim();
      const link = $(element).find('div.title-text a').attr('href');
      
      if (title && link) {
        animeList.push({ title, link });
      }
    });
    
    return animeList;
  } catch (error) {
    console.error('Error fetching latest anime:', error);
    return [];
  }
}
let list = []
for (let i of owner) {
list.push({
	    	displayName: await sky.getName(i),
	    	vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await sky.getName(i)}\nFN:${await sky.getName(i)}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Click here to chat\nitem2.EMAIL;type=INTERNET:${ytname}\nitem2.X-ABLabel:YouTube\nitem3.URL:${socialm}\nitem3.X-ABLabel:GitHub\nitem4.ADR:;;${location};;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
	    })
	}
async function getLatestBBCNews() {
  try {
    const response = await axios.get('https://www.bbc.co.uk/news');
    const $ = cheerio.load(response.data);
    
    const news = [];
    
    $('div.gs-c-promo').each((index, element) => {
      const title = $(element).find('h3').text();
      const link = $(element).find('a').attr('href');
      
      if (title && link) {
        news.push({ title, link });
      }
    });
    
    return news;
  } catch (error) {
    console.error('Error fetching BBC news:', error);
    return [];
  }
}
async function performAdvancedBugHunting(url) {
    try {
        const response = await axios.get(url);
        const $ = cheerio.load(response.data);

        const headers = response.headers;
        const status = response.status;
        const contentType = headers['content-type'];

        // Check for insecure HTTP resources
        const insecureResources = [];
        $('*[src^="http://"]').each((index, element) => {
            insecureResources.push($(element).attr('src'));
        });

        // Check for forms without secure attribute
        const formsWithoutSecure = $('form:not([method="post"])');

        // More vulnerability checks can be added here

        const report = `Laporan Bug Hunting untuk ${url}:\nStatus: ${status}\nTipe Konten: ${contentType}\nCek Sumber Tidak Aman\n${insecureResources.join('\n')}\nFormulir Tanpa Atribut Aman\n${formsWithoutSecure.length} formulir tanpa atribut "method" yang aman`;

        return report;
    } catch (error) {
        throw 'Gagal melakukan Bug Hunting.';
    }
}
// Function to fetch quotes from URL
function quotes(input) {
    return new Promise((resolve, reject) => {
        fetch('https://jagokata.com/kata-bijak/kata-' + input.replace(/\s/g, '_') + '.html?page=1')
            .then(res => res.text())
            .then(res => {
                const $ = cheerio.load(res);
                data = [];
                $('div[id="main"]').find('ul[id="citatenrijen"] > li').each(function (index, element) {
                    x = $(this).find('div[class="citatenlijst-auteur"] > a').text().trim();
                    y = $(this).find('span[class="auteur-beschrijving"]').text().trim();
                    z = $(element).find('q[class="fbquote"]').text().trim();
                    data.push({ author: x, bio: y, quote: z });
                });
                data.splice(2, 1);
                if (data.length == 0) return resolve({ creator: '@neoxr - Wildan Izzudin & @ariffb.id - Ariffb', status: false });
                resolve({ creator: '@skyyyy', status: true, data });
            }).catch(reject);
    });
}
async function getIpInfo(ip) {
    try {
        const response = await axios.get(`https://ipinfo.io/${ip}/json`);
        return response.data;
    } catch (error) {
        throw 'Gagal mendapatkan informasi IP.';
    }
}
        const replygc = (teks) => {
skysend(m.chat,
{ text: teks,
contextInfo:{
mentionedJid:[sender],
forwardingScore: 9999999,
isForwarded: true, 
"externalAdReply": {
"showAdAttribution": true,
"containsAutoReply": true,
"title": `avosky-md`,
"body": `avosky-md`,
"previewType": "PHOTO",
"thumbnailUrl": ``,
"thumbnail": fs.readFileSync(`./src/fotonya.jpg`),
"sourceUrl": `https://chat.whatsapp.com/FvrzXkSKH1vKbeX2c2qKam`}}},
{ quoted: m})
}
//bug
const avosky = { 
key: {
fromMe: [], 
participant: "0@s.whatsapp.net", ...(from ? { remoteJid: "" } : {}) 
},

'message': {
 "stickerMessage": {
"url": "https://mmg.whatsapp.net/d/f/At6EVDFyEc1w_uTN5aOC6eCr-ID6LEkQYNw6btYWG75v.enc",
"fileSha256": "YEkt1kHkOx7vfb57mhnFsiu6ksRDxNzRBAxqZ5O461U=",
"fileEncSha256": "9ryK8ZNEb3k3CXA0X89UjCiaHAoovwYoX7Ml1tzDRl8=",
"mediaKey": "nY85saH7JH45mqINzocyAWSszwHqJFm0M0NvL7eyIDM=",
"mimetype": "image/webp",
"height": 40,
"width": 40,
"directPath": "/v/t62.7118-24/19433981_407048238051891_5533188357877463200_n.enc?ccb=11-4&oh=01_AVwXO525CP-5rmcfl6wgs6x9pkGaO6deOX4l6pmvZBGD-A&oe=62ECA781",
"fileLength": "99999999",
"mediaKeyTimestamp": "16572901099967",
        'isAnimated': []
}}}		
	// auto set bio
	if (db.data.settings[botNumber].autobio) {
	    let setting = global.db.data.settings[botNumber]
	    if (new Date() * 1 - setting.status > 1000) {
		let uptime = await runtime(process.uptime())
		await sky.updateProfileStatus(`${sky.user.name} | Runtime : ${runtime(uptime)}`)
		setting.status = new Date() * 1
	    }
	}
	async function waitForMessage(from, regex, timeout) {
    return new Promise(async (resolve) => {
        const startTime = Date.now();

        while (Date.now() - startTime < timeout) {
            const messages = await sky.sendMessage(m.chat, { fromMe: false })
            
            for (const message of messages) {
                if (message.sender === from && regex.test(message.content)) {
                    resolve(message);
                    return;
                }
            }

            await new Promise(resolve => setTimeout(resolve, 1000)); // Tunggu selama 1 detik sebelum cek kembali
        }

        resolve(null); // Timeout tercapai
    });
}
function formatSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function sizeLimit(size, limit) {
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const limitSize = parseFloat(limit);
  const limitUnit = limit.replace(/[\d.]/g, '');
  const limitIndex = sizes.findIndex(unit => unit === limitUnit);
  const currentSize = parseFloat(size);
  const currentUnit = size.replace(/[\d.]/g, '');
  const currentIndex = sizes.findIndex(unit => unit === currentUnit);

  if (currentIndex > limitIndex) {
    return {
      oversize: true,
      currentSize: currentSize,
      currentUnit: currentUnit,
      limitSize: limitSize,
      limitUnit: limitUnit
    };
  } else {
    return {
      oversize: false,
      currentSize: currentSize,
      currentUnit: currentUnit,
      limitSize: limitSize,
      limitUnit: limitUnit
    };
  }
}

function jsonFormat(json) {
  return JSON.stringify(json, null, 2);
}
async function replyprem(teks) {
    m.reply(`sorry fitur ini hanya untuk premium only jika ingin premium bisa ketik .buyprem`)
}	
async function sendNextTag(user) {
  if (tagQueue[user] && tagQueue[user].currentIndex < tagQueue[user].amount) {
    const target = tagQueue[user].target;
    const currentIndex = tagQueue[user].currentIndex;

    // Mengirim tag berikutnya
    sky.sendTextWithMentions(from, `${target}`);
    
    // Menambahkan 1 ke currentIndex dan menjalankan pengiriman tag selanjutnya setelah jeda
    tagQueue[user].currentIndex++;
    setTimeout(() => {
      sendNextTag(user);
    }, 1000); // Jeda 1 detik
  } else {
    // Menghapus antrian tag setelah selesai
    delete tagQueue[user];
  }
}  
// Fungsi untuk mengacak urutan elemen dalam array
function shuffleArray(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}
function drawCard() {
    const cards = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    const randomIndex = Math.floor(Math.random() * cards.length);
    return cards[randomIndex];
}

function calculateScore(hand) {
    let score = 0;
    let numOfAces = 0;

    for (let card of hand) {
        if (card === 'A') {
            numOfAces++;
            score += 11;
        } else if (['K', 'Q', 'J'].includes(card)) {
            score += 10;
        } else {
            score += parseInt(card);
        }
    }

    while (numOfAces > 0 && score > 21) {
        score -= 10;
        numOfAces--;
    }

    return score;
}

	        // Autosticker gc
        if (isAutoSticker) {
            if (/image/.test(mime) && !/webp/.test(mime)) {
                let mediac = await quoted.download()
                await sky.sendImageAsSticker(from, mediac, m, { packname: global.packname, author: global.author })
                console.log(`Auto sticker detected`)
            } else if (/video/.test(mime)) {
                if ((quoted.msg || quoted).seconds > 11) return
                let mediac = await quoted.download()
                await sky.sendVideoAsSticker(from, mediac, m, { packname: global.packname, author: global.author })
            }
        }
    if (antiEmote) {
    if (emojiRegex.test(budy)) {
        if (!isBotAdmins) return
bcl = `Admin Bebas Emoji`
if (isAdmins) return m.reply(bcl)
if (m.key.fromMe) return m.reply(bcl)
kice = m.sender
            await sky.sendMessage(m.chat, {
               delete: {
                  remoteJid: m.chat,
                  fromMe: false,
                  id: m.key.id,
                  participant: m.key.participant
               }
            })             	
sky.sendMessage(from, {text:`Sorry ${pushname} No Emoji here `, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
} else {
}
}
           if (SimiActive) {
axios.get(`https://api.lolhuman.xyz/api/simi?apikey=GataDios&text=.%20${text}&badword=true`).then(({ data }) => {
 m.reply(`${data.result}`)
 	})
    } else { 
}
    if (bocet) {
if (isGroup && bocet && !itsMe && !isCreator) return 
}
         if (AntiBatu)
         if (budy.match("🗿")) {
         if (!isBotAdmins) return
bcl = `「 Admin Kan Bebas 🗿 」 `
if (isAdmins) return m.reply(bcl)
if (m.key.fromMe) return m.reply(bcl)
kice = m.sender
            await sky.sendMessage(m.chat, {
               delete: {
                  remoteJid: m.chat,
                  fromMe: false,
                  id: m.key.id,
                  participant: m.key.participant
               }
            })             	
sky.sendMessage(from, {text:`\`\`\`「 🗿 Detected 」\`\`\`\n\n@${kice.split("@")[0]} His Anti Stone Message Has Been Deleted`, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
} else {
}
 // Antiwame by xeon
  if (antiWame)
  if (budy.includes("wa.me","Wa.me")) {
if (!isBotAdmins) return 
bvl = `\`\`\`「 Wa.me Link Detected 」\`\`\`\n\nAdmin has sent a wa.me link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
kice = m.sender
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Wa.me Link Detected 」\`\`\`\n\n@${kice.split("@")[0]} Has been kicked because of sending wa.me link in this group`, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
} else {
}
         //Anti Link Push kontakV1
        if (db.data.chats[m.chat].antipushkontakv1) {
            if (budy.match(`pushkontak`)) {
                m.reply(`「 ANTI PUSH KONTAK 」\n\nKamu Terdeteksi Sedang Push kontak, Anak Yatim Lagi Push kontak 😂 !`)
                if (!isBotAdmins) return m.reply(`Ehh Bot Gak Admin T_T`)
                if (isAdmins) return m.reply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return m.reply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
        }
        //SKYY
     //Anti Promosi
        if (db.data.chats[m.chat].antipushkontakv2) {
            if (budy.match(`panel`)) {
                m.reply(`「 ANTI PROMOSI 」\n\nKamu Terdeteksi Sedang Promosi, Anak Yatim Lagi Promosi 😂 !`)
                if (!isBotAdmins) return m.reply(`Ehh Bot Gak Admin T_T`)
                if (isAdmins) return m.reply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return m.reply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
        }
// Anti Link
        if (Antilinkgc) {
        if (budy.match(`chat.whatsapp.com`)) {
        if (!isBotAdmins) return mess.botAdmin
        let gclink = (`https://chat.whatsapp.com/`+await sky.groupInviteCode(m.chat))
        let isLinkThisGc = new RegExp(gclink, 'i')
        let isgclink = isLinkThisGc.test(m.text)
        if (isgclink) return sky.sendMessage(m.chat, {text: `\`\`\`「 Group Link Detected 」\`\`\`\n\nYou won't be kicked by a bot because what you send is a link to this group`})
        if (isAdmins) return sky.sendMessage(m.chat, {text: `\`\`\`「 Group Link Detected 」\`\`\`\n\nAdmin has sent a link, admin is free to post any link`})
        
        kice = m.sender
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
			sky.sendMessage(from, {text:`\`\`\`「 Group Link Detected 」\`\`\`\n\n@${kice.split("@")[0]} Has been kicked because of sending group link in this group`, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
            }            
        }
//antivirtex by xeon
  if (antiVirtex) {
  if (budy.length > 3500) {
  if (!isBotAdmins) return mess.botAdmin
          await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
			sky.sendMessage(from, {text:`\`\`\`「 Virus Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending virus in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
  }
  }
//anti bad words by xeon
if (antiToxic)
if (BadXeon.includes(messagesD)) {
if (m.text) {
bvl = `\`\`\`「 Bad Word Detected 」\`\`\`\n\nYou are using bad word but you are an admin/owner that's why i won't kick you😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			await sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Bad Word Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} was kicked because of using bad words in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})}
}
//antilink youtube video by xeon
if (AntiLinkYt)
if (budy.includes("https://youtu.be/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 YoutTube Video Link Detected 」\`\`\`\n\nAdmin has sent a youtube video link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 YouTube Video Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending youtube video link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink instagram by xeon
if (AntiLinkInstagram)
   if (budy.includes("https://www.instagram.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Instagram Link Detected 」\`\`\`\n\nAdmin has sent a instagram link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Instagram Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending instagram link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink facebook by xeon
if (AntiLinkFacebook)
   if (budy.includes("https://facebook.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Facebook Link Detected 」\`\`\`\n\nAdmin has sent a facebook link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Facebook Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending facebook link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink telegram by xeon
if (AntiLinkTelegram)
   if (budy.includes("https://t.me/")){
if (AntiLinkTelegram)
if (!isBotAdmins) return
bvl = `\`\`\`「 Telegram Link Detected 」\`\`\`\n\nAdmin has sent a telegram link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Telegram Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending telegram link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink tiktok by xeon
if (AntiLinkTiktok)
   if (budy.includes("https://www.tiktok.com/","https://vt.tiktok.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Tiktok Link Detected 」\`\`\`\n\nAdmin has sent a tiktok link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Tiktok Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending tiktok link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink twitter by xeon
if (AntiLinkTwitter)
   if (budy.includes("https://twitter.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Twitter Link Detected 」\`\`\`\n\nAdmin has sent a twitter link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Tiktok Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending twitter link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
 // Akinator Setting Start
 
	if (akinator.hasOwnProperty(m.sender.split('@')[0]) && isCmd && ["0", "1", "2", "3", "4", "5"].includes(body)) {
                kuis = true
                var { server, frontaddr, session, signature, question, step } = akinator[m.sender.split('@')[0]]
                if (step == "0" && budy == "5") throw("Maaf Anda telah mencapai pertanyaan pertama")
                var ini_url = `https://api.lolhuman.xyz/api/akinator/answer?apikey=GataDios&server=${server}&frontaddr=${frontaddr}&session=${session}&signature=${signature}&answer=${budy}&step=${step}`
                var get_result = await fetchJson(ini_url)
                var get_result = get_result.result
                if (get_result.hasOwnProperty("name")) {
                    var ini_name = get_result.name
                    var description = get_result.description
                    ini_txt = `${ini_name} - ${description}\n\n`
                    ini_txt += "Apakah Tebakan Saya Benar? Tuan/Nyonya\n\nSekian dan terima gaji. Akinator by Avosky-MD"
                    await sky.sendImage(m.chat, get_result.image, ini_txt, m).then(() => {
                        delete akinator[m.sender.split('@')[0]]
                        fs.writeFileSync("./src/akinator.json", JSON.stringify(akinator))
                    })
                    return
                }
                var { question, _, step } = get_result
                ini_txt = `🤔🤔\n${question}\n\n`
                ini_txt += "0 - Ya\n"
                ini_txt += "1 - Tidak\n"
                ini_txt += "2 - Saya Tidak Tau\n"
                ini_txt += "3 - Mungkin\n"
                ini_txt += "4 - Mungkin Tidak\n"
                ini_txt += "5 - Kembali ke Pertanyaan Sebelumnya"
                if (args[0] === '5') {
                    var ini_url = `https://api.lolhuman.xyz/api/akinator/back?apikey=GataDios&server=${server}&frontaddr=${frontaddr}&session=${session}&signature=${signature}&answer=${budy}&step=${step}`
                    var get_result = await fetchJson(ini_url)
                    var get_result = get_result.result
                    var { question, _, step } = get_result
                    ini_txt = `🤔🤔\n${question}\n\n`
                    ini_txt += "0 - Ya\n"
                    ini_txt += "1 - Tidak\n"
                    ini_txt += "2 - Saya Tidak Tau\n"
                    ini_txt += "3 - Mungkin\n"
                    ini_txt += "4 - Mungkin Tidak"
                    ini_txt += "5 - Kembali ke Pertanyaan Sebelumnya"
                }
                sky.sendText(m.chat, ini_txt, m).then(() => {
                    const data_ = akinator[m.sender.split('@')[0]]
                    data_["question"] = question
                    data_["step"] = step
                    akinator[m.sender.split('@')[0]] = data_
                    fs.writeFileSync("./src/akinator.json", JSON.stringify(akinator))
                })
            }
			
 // Akinator settings end
//antilink all by xeon
if (AntiLinkAll)
   if (budy.includes("https://")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Link Detected 」\`\`\`\n\nAdmin has sent a link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
      // Mute Chat
      if (db.data.chats[m.chat].mute && !isAdmins && !isCreator) {
      return
      }

        // Respon Cmd with media
        if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.sticker)) {
        let hash = global.db.data.sticker[m.msg.fileSha256.toString('base64')]
        let { text, mentionedJid } = hash
        let messages = await generateWAMessage(m.chat, { text: text, mentions: mentionedJid }, {
            userJid: sky.user.id,
            quoted: m.quoted && m.quoted.fakeObj
        })
        messages.key.fromMe = areJidsSameUser(m.sender, sky.user.id)
        messages.key.id = m.key.id
        messages.pushName = m.pushName
        if (m.isGroup) messages.participant = m.sender
        let msg = {
            ...chatUpdate,
            messages: [proto.WebMessageInfo.fromObject(messages)],
            type: 'append'
        }
        sky.ev.emit('messages.upsert', msg)
        }
	    
 
	if (('family100'+m.chat in _family100) && isCmd) {
            kuis = true
            let room = _family100['family100'+m.chat]
            let teks = budy.toLowerCase().replace(/[^\w\s\-]+/, '')
            let isSurender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
            if (!isSurender) {
                let index = room.jawaban.findIndex(v => v.toLowerCase().replace(/[^\w\s\-]+/, '') === teks)
                if (room.terjawab[index]) return !0
                room.terjawab[index] = m.sender
            }
            let isWin = room.terjawab.length === room.terjawab.filter(v => v).length
            let caption = `
Jawablah Pertanyaan Berikut :\n${room.soal}\n\n\nTerdapat ${room.jawaban.length} Jawaban ${room.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}
${isWin ? `Semua Jawaban Terjawab` : isSurender ? 'Menyerah!' : ''}
${Array.from(room.jawaban, (jawaban, index) => {
        return isSurender || room.terjawab[index] ? `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '@' + room.terjawab[index].split('@')[0] : ''}`.trim() : false
    }).filter(v => v).join('\n')}
    ${isSurender ? '' : `Perfect Player`}`.trim()
            sky.sendText(m.chat, caption, m, { contextInfo: { mentionedJid: parseMention(caption) }}).then(mes => { return _family100['family100'+m.chat].pesan = mesg }).catch(_ => _)
            if (isWin || isSurender) delete _family100['family100'+m.chat]
        }
        if (kuismath.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = kuismath[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                await m.reply(`🎮 Kuis Matematika  🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete kuismath[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }

        if (tebakgambar.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakgambar[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                    const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah;
                await m.reply(`🎮 Tebak Gambar 🎮\n\nJawaban Benar 🎉\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance`)
                delete tebakgambar[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }        					
if (tebakkata.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
    kuis = true
    jawaban = tebakkata[m.sender.split('@')[0]]
    if (budy.toLowerCase() == jawaban) {
        const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
        await m.reply(`🎮 Tebak Kata 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`);
        delete tebakkata[m.sender.split('@')[0]];
    } else {
        m.reply('*Jawaban Salah!*');
    }
}
        if (caklontong.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = caklontong[m.sender.split('@')[0]]
	    deskripsi = caklontong_desk[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                    const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
                await m.reply(`🎮 Cak Lontong 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete caklontong[m.sender.split('@')[0]]
		delete caklontong_desk[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }

        if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakkalimat[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                    const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
                await m.reply(`🎮 Tebak Kalimat 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete tebakkalimat[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }

        if (tebaklirik.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebaklirik[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                    const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
                await m.reply(`🎮 Tebak Lirik 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete tebaklirik[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }
	    
	if (tebaktebakan.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebaktebakan[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                                const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
                await m.reply(`🎮 Tebak Tebakan 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete tebaktebakan[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }
        
        //TicTacToe
	    this.game = this.game ? this.game : {}
	    let room = Object.values(this.game).find(room => room.id && room.game && room.state && room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state == 'PLAYING')
	    if (room) {
	    let ok
	    let isWin = !1
	    let isTie = !1
	    let isSurrender = !1
	    // m.reply(`[DEBUG]\n${parseInt(m.text)}`)
	    if (!/^([1-9]|(me)?nyerah|surr?ender|off|skip)$/i.test(m.text)) return
	    isSurrender = !/^[1-9]$/.test(m.text)
	    if (m.sender !== room.game.currentTurn) { // nek wayahku
	    if (!isSurrender) return !0
	    }
	    if (!isSurrender && 1 > (ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1))) {
	    m.reply({
	    '-3': 'Game telah berakhir',
	    '-2': 'Invalid',
	    '-1': 'Posisi Invalid',
	    0: 'Posisi Invalid',
	    }[ok])
	    return !0
	    }
	    if (m.sender === room.game.winner) isWin = true
	    else if (room.game.board === 511) isTie = true
	    let arr = room.game.render().map(v => {
	    return {
	    X: '❌',
	    O: '⭕',
	    1: '1️⃣',
	    2: '2️⃣',
	    3: '3️⃣',
	    4: '4️⃣',
	    5: '5️⃣',
	    6: '6️⃣',
	    7: '7️⃣',
	    8: '8️⃣',
	    9: '9️⃣',
	    }[v]
	    })
	    if (isSurrender) {
	    room.game._currentTurn = m.sender === room.game.playerX
	    isWin = true
	    }
	    let winner = isSurrender ? room.game.currentTurn : room.game.winner
	    let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Menang!` : isTie ? `Game berakhir` : `Giliran ${['❌', '⭕'][1 * room.game._currentTurn]} (@${room.game.currentTurn.split('@')[0]})`}
❌: @${room.game.playerX.split('@')[0]}
⭕: @${room.game.playerO.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
	    if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== m.chat)
	    room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = m.chat
	    if (room.x !== room.o) await sky.sendText(room.x, str, m, { mentions: parseMention(str) } )
	    await sky.sendText(room.o, str, m, { mentions: parseMention(str) } )
	    if (isTie || isWin) {
	    delete this.game[room.id]
	    }
	    }

        //Suit PvP
	    this.suit = this.suit ? this.suit : {}
	    let roof = Object.values(this.suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
	    if (roof) {
	    let win = ''
	    let tie = false
	    if (m.sender == roof.p2 && /^(acc(ept)?|terima|gas|oke?|tolak|gamau|nanti|ga(k.)?bisa|y)/i.test(m.text) && m.isGroup && roof.status == 'wait') {
	    if (/^(tolak|gamau|nanti|n|ga(k.)?bisa)/i.test(m.text)) {
	    sky.sendTextWithMentions(m.chat, `@${roof.p2.split`@`[0]} menolak suit, suit dibatalkan`, m)
	    delete this.suit[roof.id]
	    return !0
	    }
	    roof.status = 'play'
	    roof.asal = m.chat
	    clearTimeout(roof.waktu)
	    //delete roof[roof.id].waktu
	    sky.sendText(m.chat, `Suit telah dikirimkan ke chat

@${roof.p.split`@`[0]} dan 
@${roof.p2.split`@`[0]}

Silahkan pilih suit di chat masing"
klik https://wa.me/${botNumber.split`@`[0]}`, m, { mentions: [roof.p, roof.p2] })
	    if (!roof.pilih) sky.sendText(roof.p, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
	    if (!roof.pilih2) sky.sendText(roof.p2, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
	    roof.waktu_milih = setTimeout(() => {
	    if (!roof.pilih && !roof.pilih2) sky.sendText(m.chat, `Kedua pemain tidak niat main,\nSuit dibatalkan`)
	    else if (!roof.pilih || !roof.pilih2) {
	    win = !roof.pilih ? roof.p2 : roof.p
	    sky.sendTextWithMentions(m.chat, `@${(roof.pilih ? roof.p2 : roof.p).split`@`[0]} tidak memilih suit, game berakhir`, m)
	    }
	    delete this.suit[roof.id]
	    return !0
	    }, roof.timeout)
	    }
	    let jwb = m.sender == roof.p
	    let jwb2 = m.sender == roof.p2
	    let g = /gunting/i
	    let b = /batu/i
	    let k = /kertas/i
	    let reg = /^(gunting|batu|kertas)/i
	    if (jwb && reg.test(m.text) && !roof.pilih && !m.isGroup) {
	    roof.pilih = reg.exec(m.text.toLowerCase())[0]
	    roof.text = m.text
	    m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih2 ? `\n\nMenunggu lawan memilih` : ''}`)
	    if (!roof.pilih2) sky.sendText(roof.p2, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
	    }
	    if (jwb2 && reg.test(m.text) && !roof.pilih2 && !m.isGroup) {
	    roof.pilih2 = reg.exec(m.text.toLowerCase())[0]
	    roof.text2 = m.text
	    m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih ? `\n\nMenunggu lawan memilih` : ''}`)
	    if (!roof.pilih) sky.sendText(roof.p, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
	    }
	    let stage = roof.pilih
	    let stage2 = roof.pilih2
	    if (roof.pilih && roof.pilih2) {
	    clearTimeout(roof.waktu_milih)
	    if (b.test(stage) && g.test(stage2)) win = roof.p
	    else if (b.test(stage) && k.test(stage2)) win = roof.p2
	    else if (g.test(stage) && k.test(stage2)) win = roof.p
	    else if (g.test(stage) && b.test(stage2)) win = roof.p2
	    else if (k.test(stage) && b.test(stage2)) win = roof.p
	    else if (k.test(stage) && g.test(stage2)) win = roof.p2
	    else if (stage == stage2) tie = true
	    sky.sendText(roof.asal, `_*Hasil Suit*_${tie ? '\nSERI' : ''}

@${roof.p.split`@`[0]} (${roof.text}) ${tie ? '' : roof.p == win ? ` Menang \n` : ` Kalah \n`}
@${roof.p2.split`@`[0]} (${roof.text2}) ${tie ? '' : roof.p2 == win ? ` Menang \n` : ` Kalah \n`}
`.trim(), m, { mentions: [roof.p, roof.p2] })
	    delete this.suit[roof.id]
	    }
	    }
	    
	    let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
	    for (let jid of mentionUser) {
            let user = global.db.data.users[jid]
            if (!user) continue
            let afkTime = user.afkTime
            if (!afkTime || afkTime < 0) continue
            let reason = user.afkReason || ''
            m.reply(`
Jangan tag dia!
Dia sedang AFK ${reason ? 'dengan alasan ' + reason : 'tanpa alasan'}
Selama ${clockString(new Date - afkTime)}
`.trim())
        }

        if (db.data.users[m.sender].afkTime > -1) {
            let user = global.db.data.users[m.sender]
            sky.sendTextWithMentions(m.chat, `@${m.sender.split('@')[0]} berhenti AFK${user.afkReason ? ' setelah ' + user.afkReason : ''}
Selama ${clockString(new Date - user.afkTime)}`)
            user.afkTime = -1
            user.afkReason = ''
        }
        
            const cmdGrup = ["⧠ • 𝙻𝙸𝙽𝙺𝙶𝚁𝙾𝚄𝙿","⧠ • 𝙴𝙿𝙷𝙴𝙼𝙴𝚁𝙰𝙻","⧠ • 𝚂𝙴𝚃𝙿𝙿𝙶𝙲","⧠ • 𝚂𝙴𝚃𝙽𝙰𝙼𝙴","⧠ • 𝚂𝙴𝚃𝙳𝙴𝚂𝙲","⧠ • 𝙶𝚁𝙾𝚄𝙿","⧠ • 𝙴𝙳𝙸𝚃𝙸𝙽𝙵𝙾","⧠ • 𝙰𝙳𝙳","⧠ • 𝙺𝙸𝙲𝙺","⧠ • 𝙷𝙸𝙳𝙴𝚃𝙰𝙶","⧠ • 𝚃𝙰𝙶𝙰𝙻𝙻","⧠ • 𝙰𝙽𝚃𝙸𝙻𝙸𝙽𝙺𝙰𝙻𝙻","⧠ • 𝙰𝙽𝚃𝙸𝙻𝙸𝙽𝙺𝙵𝙰𝙲𝙴𝙱𝙾𝙾𝙺","⧠ • 𝙰𝙽𝚃𝙸𝙻𝙸𝙽𝙺𝙸𝙽𝚂𝚃𝙰𝙶𝚁𝙰𝙼","⧠ • 𝙰𝙽𝚃𝙸𝙻𝙸𝙽𝙺𝚃𝚆𝙸𝚃𝚃𝙴𝚁","⧠ • 𝚃𝙾𝚃𝙰𝙶","⧠ • 𝙰𝙽𝚃𝙸𝙻𝙸𝙽𝙺𝚈𝚃","⧠ • 𝙰𝙽𝚃𝙸𝙿𝚄𝚂𝙷𝙺𝙾𝙽𝚃𝙰𝙺𝚅𝟷","⧠ • 𝙰𝙽𝚃𝙸𝙿𝚄𝚂𝙷𝙺𝙾𝙽𝚃𝙰𝙺𝚅𝟸","⧠ • 𝙰𝙽𝚃𝙸𝙻𝙸𝙽𝙺𝙶𝙲","⧠ • 𝙰𝙽𝚃𝙸𝚅𝙸𝚁𝚃𝙴𝚇","⧠ • 𝙰𝙽𝚃𝙸𝚆𝙰𝙼𝙴","⧠ • 𝙰𝙽𝚃𝙸𝙻𝙸𝙽𝙺𝚃𝙸𝙺𝚃𝙾𝙺","⧠ • 𝙼𝚄𝚃𝙴","⧠ • 𝙰𝚄𝚃𝙾𝚂𝚃𝙸𝙲𝙺𝙴𝚁","⧠ • 𝙲𝙻𝙾𝚂𝙴𝚃𝙸𝙼𝙴","⧠ • 𝙾𝙿𝙴𝙽𝚃𝙸𝙼𝙴","⧠ • 𝙿𝚁𝙾𝙼𝙾𝚃𝙴","⧠ • 𝙳𝙴𝙼𝙾𝚃𝙴","⧠ • 𝙻𝙸𝚂𝚃𝙾𝙽𝙻𝙸𝙽𝙴","⧠ • 𝙳𝙴𝙼𝙾𝚃𝙴𝙰𝙻𝙻","⧠ • 𝙿𝚁𝙾𝙼𝙾𝚃𝙴𝙰𝙻𝙻","⧠ • 𝙰𝙽𝚃𝙸𝙱𝙰𝚃𝚄","⧠ • 𝙲𝙴𝙺𝙿𝚁𝙾𝚅𝙸𝙳𝙴𝚁","⧠ • 𝚃𝙰𝙶𝙰𝙻𝙻𝟸","⧠ • 𝙺𝙸𝙲𝙺𝚁𝙰𝙽𝙳𝙾𝙼","⧠ • 𝚃𝙰𝙶𝙰𝙻𝙻𝟹","⧠ • 𝙷𝙸𝙳𝙴𝚃𝙰𝙶","⧠ • 𝚃𝙰𝙶","⧠ • 𝚃𝙰𝙶𝟸","⧠ • 𝙹𝙰𝙼","⧠ • 𝚁𝙰𝙽𝙳𝙾𝙼𝚃𝙰𝙶","⧠ • 𝙲𝙴𝙺𝚁𝙴𝙶𝙸𝙾𝙽𝙼𝙴𝙼𝙱𝙴𝚁","⧠ • 𝙿𝙸𝙲𝙺","⧠ • 𝚆𝙴𝙻𝙲𝙾𝙼𝙴","⧠ • 𝚁𝙰𝙽𝙳𝙾𝙼𝙿𝚁𝙾𝙼𝙾𝚃𝙴","⧠ • 𝚁𝙰𝙽𝙳𝙾𝙼𝙺𝙾𝙽𝚃𝙰𝙺","⧠ • 𝙲𝙴𝙺𝙼𝙴𝙼𝙱𝙴𝚁","⧠ • 𝚂𝙴𝙽𝙳𝙻𝙸𝙽𝙺𝙶𝙲"]
        const cmdDown = ["⧠ • 𝚃𝙸𝙺𝚃𝙾𝙺𝙽𝙾𝚆𝙼","⧠ • 𝚃𝙸𝙺𝚃𝙾𝙺𝙼𝙿𝟹","⧠ • 𝙸𝙽𝚂𝚃𝙰𝙶𝚁𝙰𝙼","⧠ • 𝚃𝚆𝙸𝚃𝚃𝙴𝚁","⧠ • 𝚃𝚆𝙸𝚃𝚃𝙴𝚁𝙼𝙿𝟹","⧠ • 𝙵𝙰𝙲𝙴𝙱𝙾𝙾𝙺","⧠ • 𝙿𝙸𝙽𝚃𝙴𝚁𝙴𝚂𝚃𝙳𝙻","⧠ • 𝚈𝚃𝙼𝙿𝟹","⧠ • 𝚈𝚃𝙼𝙿𝟺","⧠ • 𝙶𝙴𝚃𝙼𝚄𝚂𝙸𝙲","⧠ • 𝙶𝙴𝚃𝚅𝙸𝙳𝙴𝙾","⧠ • 𝙹𝙾𝙾𝚇","⧠ • 𝚂𝙾𝚄𝙽𝙳𝙲𝙻𝙾𝚄𝙳","⧠ • 𝙼𝙴𝙳𝙸𝙰𝙵𝙸𝚁𝙴"]
        const cmdSearch = ["⧠ • 𝙿𝙻𝙰𝚈","⧠ • 𝚈𝚃𝚂","⧠ • 𝙶𝙾𝙾𝙶𝙻𝙴","⧠ • 𝙶𝙸𝙼𝙰𝙶𝙴","⧠ • 𝙿𝙸𝙽𝚃𝙴𝚁𝙴𝚂𝚃","⧠ • 𝚆𝙰𝙻𝙻𝙿𝙰𝙿𝙴𝚁","⧠ • 𝚆𝙸𝙺𝙸𝙼𝙴𝙳𝙸𝙰","⧠ • 𝚈𝚃𝚂𝙴𝙰𝚁𝙲𝙷","⧠ • 𝚁𝙸𝙽𝙶𝚃𝙾𝙽𝙴","⧠ • 𝙸𝙶𝚂𝚃𝙰𝙻𝙺","⧠ • 𝚃𝚃𝚂𝚃𝙰𝙻𝙺","⧠ • 𝙶𝙷𝚂𝚃𝙰𝙻𝙺","⧠ • 𝙼𝙻𝚂𝚃𝙰𝙻𝙺","⧠ • 𝙿𝙻𝙰𝚈𝚂𝚃𝙾𝚁𝙴","⧠ • 𝙶𝚂𝙼𝙰𝚁𝙴𝙽𝙰","⧠ • 𝙹𝙰𝙳𝚆𝙰𝙻𝙱𝙸𝙾𝚂𝙺𝙾𝙿","⧠ • 𝙽𝙾𝚆𝙿𝙻𝙰𝚈𝙸𝙽𝙶𝙱𝙸𝙾𝚂𝙺𝙾𝙿","⧠ • 𝙺𝙸𝚂𝙰𝙷𝙽𝙰𝙱𝙸","⧠ • 𝙺𝙱𝙱𝙸","⧠ • 𝚁𝙾𝙱𝙾𝙶𝚄𝚁𝚄","⧠ • 𝙱𝚁𝙰𝙸𝙽𝙻𝚈","⧠ • 𝙰𝙻𝚀𝚄𝚁𝙰𝙽","⧠ • 𝚃𝙰𝙵𝚂𝙸𝚁𝚂𝚄𝚁𝙰𝙷","⧠ • 𝙹𝙰𝙳𝚆𝙰𝙻𝙱𝙾𝙻𝙰","⧠ • 𝙹𝙰𝙳𝚆𝙰𝙻𝚂𝙾𝙻𝙰𝚃","⧠ • 𝙹𝙰𝙳𝚆𝚃𝚅","⧠ • 𝙹𝙰𝙳𝚆𝙰𝙻𝚃𝚅𝙽𝙾𝚆","⧠ • 𝙲𝙽𝙽𝙸𝙽𝙳𝙾𝙽𝙴𝚂𝙸𝙰","⧠ • 𝙲𝙽𝙽𝙽𝙰𝚂𝙸𝙾𝙽𝙰𝙻","⧠ • 𝙲𝙽𝙽𝙸𝙽𝚃𝙴𝚁𝙽𝙰𝚂𝙸𝙾𝙽𝙰𝙻","⧠ • 𝙸𝙽𝙵𝙾𝙶𝙴𝙼𝙿𝙰","⧠ • 𝙸𝙽𝙵𝙾𝙲𝚄𝙰𝙲𝙰","⧠ • 𝙺𝙾𝙳𝙴𝙿𝙾𝚂","⧠ • 𝙰𝙸","⧠ • 𝙶𝙱𝙰𝚁𝙳","⧠ • 𝙲𝙰𝚁𝙸𝚂𝚃𝙸𝙲𝙺𝙴𝚁","⧠ • 𝙰𝙸𝙽𝙸𝙼𝙴","⧠ • 𝙰𝙸𝙳𝙸𝙵𝙵","⧠ • 𝙰𝙺𝙰𝚁","⧠ • 𝙺𝙰𝙻𝙸","⧠ • 𝙿𝙰𝙽𝙶𝙺𝙰𝚃","⧠ • 𝙲𝚁𝙴𝙰𝚃𝙴","⧠ • 𝙰𝙸𝙽𝙸𝙼𝙴𝟸","⧠ • 𝙽𝙿𝙼","⧠ • 𝚂𝙴𝙰𝚁𝙲𝙷𝙰𝙽𝙸𝙼𝙴","⧠ • 𝚀𝚄𝙾𝚃𝙴𝙼𝙰𝙺𝙴𝚁","⧠ • 𝚂𝙺𝚈","⧠ • 𝙰𝙱𝙾𝚄𝚃𝙽𝚄𝙼𝙱𝙴𝚁","⧠ • 𝙵𝙰𝙲𝚃𝙾𝚁𝙽𝚄𝙼𝙱𝙴𝚁","⧠ • 𝙹𝙾𝙺𝙴𝚀𝚄𝙾𝚃𝙴","⧠ • 𝙳𝙴𝙵𝙸𝙽𝙸𝚂𝙸","⧠ • 𝙸𝙽𝙵𝙾𝙼𝙾𝚅𝙸𝙴","⧠ • 𝙴𝚂𝚃𝙸𝙼𝙰𝚂𝙸","⧠ • 𝙱𝙴𝚁𝙸𝚃𝙰","⧠ • 𝚃𝙴𝙺𝙽𝙾𝙻𝙾𝙶𝙸","⧠ • 𝙷𝙰𝙿𝙿𝚈𝙼𝙾𝙳","⧠ • 𝚆𝙰𝚃𝚃𝙿𝙰𝙳","⧠ • 𝙹𝙰𝚁𝙰𝙺","⧠ • 𝙸𝙺𝚈","⧠ • 𝙱𝚄𝙶𝙷𝚄𝙽𝚃𝙴𝚁","⧠ • 𝙸𝙿𝙸𝙽𝙵𝙾","⧠ • 𝚀𝚄𝙾𝚃𝙴","⧠ • 𝚃𝙾𝚇𝙸𝙲𝙷𝙴𝙲𝙺","⧠ • 𝚁𝙴𝚂𝙴𝙿","⧠ • 𝙰𝚈𝙰𝚃","⧠ • 𝙲𝙰𝚁𝙸𝚂𝚄𝚁𝙰𝙷","⧠ •𝙰𝙽𝙸𝙼𝙴𝙻𝙰𝚂𝚃","⧠ • 𝙱𝙱𝙲𝙽𝙴𝚆𝚂","⧠ • 𝙸𝙽𝙵𝙾𝙽𝙴𝙶𝙰𝚁𝙰","⧠ • 𝙺𝙰𝙼𝚄𝚂","⧠ • 𝚂𝙸𝙽𝙾𝙽𝙸𝙼"]
        const cmdRand = ["⧠ • 𝙲𝙾𝙵𝙵𝙴","⧠ • 𝚀𝚄𝙾𝚃𝙴𝚂𝙰𝙽𝙸𝙼𝙴","⧠ • 𝙼𝙾𝚃𝙸𝚅𝙰𝚂𝙸","⧠ • 𝙳𝙸𝙻𝙰𝙽𝚀𝚄𝙾𝚃𝙴","⧠ • 𝙱𝚄𝙲𝙸𝙽𝚀𝚄𝙾𝚃𝙴","⧠ • 𝙺𝙰𝚃𝙰𝚂𝙴𝙽𝙹𝙰","⧠ • 𝙿𝚄𝙸𝚂𝙸","⧠ • 𝙿𝙰𝙽𝚃𝚄𝙽","⧠ • 𝙲𝙾𝚄𝙿𝙻𝙴","⧠ • 𝙰𝙽𝙸𝙼𝙴","⧠ • 𝚁𝙰𝙽𝙳𝙾𝙼𝙼𝙴𝙼𝙴","⧠ • 𝙼𝙴𝙼𝙴𝙸𝙽𝙳𝙾","⧠ • 𝙳𝙰𝚁𝙺𝙹𝙾𝙺𝙴","⧠ • 𝚆𝙰𝙸𝙵𝚄","⧠ • 𝙷𝚄𝚂𝙱𝚄","⧠ • 𝙽𝙴𝙺𝙾","⧠ • 𝚂𝙷𝙸𝙽𝙾𝙱𝚄","⧠ • 𝚆𝙰𝙸𝙵𝚄𝚂","⧠ • 𝙽𝙴𝙺𝙾𝚂","⧠ • 𝚃𝚁𝙰𝙿","⧠ • 𝙱𝙻𝙾𝚆𝙹𝙾𝙱","⧠ • 𝙲𝚁𝚈","⧠ • 𝙺𝙸𝙻𝙻","⧠ • 𝙷𝚄𝙶","⧠ • 𝙿𝙰𝚃","⧠ • 𝙻𝙸𝙲𝙺","⧠ • 𝙺𝙸𝚂𝚂","⧠ • 𝙱𝙸𝚃𝙴","⧠ • 𝚈𝙴𝙴𝚃","⧠ • 𝙱𝚄𝙻𝙻𝚈","⧠ • 𝙱𝙾𝙽𝙺","⧠ • 𝚆𝙸𝙽𝙺","⧠ • 𝙿𝙾𝙺𝙴","⧠ • 𝙽𝙾𝙼","⧠ • 𝚂𝙻𝙰𝙿","⧠ • 𝚂𝙼𝙸𝙻𝙴","⧠ • 𝚆𝙰𝚅𝙴","⧠ • 𝙰𝚆𝙾𝙾","⧠ • 𝙱𝙻𝚄𝚂𝙷","⧠ • 𝚂𝙼𝚄𝙶","⧠ • 𝙶𝙻𝙾𝙼𝙿","⧠ • 𝙷𝙰𝙿𝙿𝚈","⧠ • 𝙳𝙰𝙽𝙲𝙴","⧠ • 𝙲𝚁𝙸𝙽𝙶𝙴","⧠ • 𝙲𝚄𝙳𝙳𝙻𝙴","⧠ • 𝙷𝙸𝙶𝙷𝙵𝙸𝚅𝙴","⧠ • 𝚂𝙷𝙸𝙽𝙾𝙱𝚄","⧠ • 𝙷𝙰𝙽𝙳𝙷𝙾𝙻𝙳","⧠ • 𝚆𝙾𝙾𝙵","⧠ • 𝟾𝙱𝙰𝙻𝙻","⧠ • 𝙶𝙾𝙾𝚂𝙴","⧠ • 𝙶𝙴𝙲𝙶","⧠ • 𝙵𝙴𝙴𝙳","⧠ • 𝙰𝚅𝙰𝚃𝙰𝚁","⧠ • 𝙵𝙾𝚇_𝙶𝙸𝚁𝙻","⧠ • 𝙻𝙸𝚉𝙰𝚁𝙳"]
        const cmdMaker = ["⧠ • 𝟹𝙳𝙲𝙷𝚁𝙸𝚂𝚃𝙼𝙰𝚂","⧠ • 𝟹𝙳𝙳𝙴𝙴𝙿𝚂𝙴𝙰","⧠ • 𝙰𝙼𝙴𝚁𝙸𝙲𝙰𝙽𝙵𝙻𝙰𝙶","⧠ • 𝟹𝙳𝚂𝙲𝙸𝙵𝙸","⧠ • 𝟹𝙳𝚁𝙰𝙸𝙽𝙱𝙾𝚆","⧠ • 𝟹𝙳𝚆𝙰𝚃𝙴𝚁𝙿𝙸𝙿𝙴","⧠ • 𝙷𝙰𝙻𝙻𝙾𝚆𝙴𝙴𝙽𝚂𝙺𝙴𝙻𝙴𝚃𝙾𝙽","⧠ • 𝚂𝙺𝙴𝚃𝙲𝙷","⧠ • 𝙱𝙻𝚄𝙴𝙲𝙸𝚁𝙲𝚄𝙸𝚃","⧠ • 𝚂𝙿𝙰𝙲𝙴","⧠ • 𝙼𝙴𝚃𝙰𝙻𝙻𝙸𝙲","⧠ • 𝙵𝙸𝙲𝚃𝙸𝙾𝙽","⧠ • 𝙶𝚁𝙴𝙴𝙽𝙷𝙾𝚁𝚁𝙾𝚁","⧠ • 𝚃𝚁𝙰𝙽𝚂𝙵𝙾𝚁𝙼𝙴𝚁","⧠ • 𝙱𝙴𝚁𝚁𝚈","⧠ • 𝚃𝙷𝚄𝙽𝙳𝙴𝚁","⧠ • 𝙼𝙰𝙶𝙼𝙰","⧠ • 𝟹𝙳𝙲𝚁𝙰𝙲𝙺𝙴𝙳𝚂𝚃𝙾𝙽𝙴","⧠ • 𝟹𝙳𝙽𝙴𝙾𝙽𝙻𝙸𝙶𝙷𝚃","⧠ • 𝙸𝙼𝙿𝚁𝙴𝚂𝚂𝙸𝚅𝙴𝙶𝙻𝙸𝚃𝙲𝙷","⧠ • 𝙽𝙰𝚃𝚄𝚁𝙰𝙻𝙻𝙴𝙰𝚅𝙴𝚂","⧠ • 𝙵𝙸𝚁𝙴𝚆𝙾𝚁𝙺𝚂𝙿𝙰𝚁𝙺𝙻𝙴","⧠ • 𝙼𝙰𝚃𝚁𝙸𝚇","⧠ • 𝙳𝚁𝙾𝙿𝚆𝙰𝚃𝙴𝚁","⧠ • 𝙷𝙰𝚁𝚁𝚈𝙿𝙾𝚃𝚃𝙴𝚁","⧠ • 𝙵𝙾𝙶𝙶𝚈𝚆𝙸𝙽𝙳𝙾𝚆","⧠ • 𝙽𝙴𝙾𝙽𝙳𝙴𝚅𝙸𝙻𝚂","⧠ • 𝙲𝙷𝚁𝙸𝚂𝚃𝙼𝙰𝚂𝙷𝙾𝙻𝙸𝙳𝙰𝚈","⧠ • 𝟹𝙳𝙶𝚁𝙰𝙳𝙸𝙴𝙽𝚃","⧠ • 𝙱𝙻𝙰𝙲𝙺𝙿𝙸𝙽𝙺","⧠ • 𝙶𝙻𝚄𝙴𝚃𝙴𝚇𝚃","⧠ • 𝚂𝙷𝙰𝙳𝙾𝚆","⧠ • 𝚁𝙾𝙼𝙰𝙽𝚃𝙸𝙲","⧠ • 𝚂𝙼𝙾𝙺𝙴","⧠ • 𝙱𝚄𝚁𝙽𝙿𝙰𝙿𝙿𝙴𝚁","⧠ • 𝚁𝙰𝙸𝙽𝙱𝙾𝚆","⧠ • 𝙻𝙾𝚅𝙴𝙼𝚂𝙶","⧠ • 𝙶𝚁𝙰𝚂𝚂𝙼𝚂𝙶","⧠ • 𝙻𝙾𝚅𝙴𝚃𝙴𝚇𝚃","⧠ • 𝙲𝙾𝙵𝙵𝙴𝙲𝚄𝙿","⧠ • 𝙱𝚄𝚃𝚃𝙴𝚁𝙵𝙻𝚈","⧠ • 𝙷𝙰𝚁𝚁𝚈𝙿𝙾𝚃𝚃𝙴𝚁","⧠ • 𝙱𝙻𝙰𝙲𝙺𝙿𝙸𝙽𝙺","⧠ • 𝙸𝙶𝙲𝙴𝚁𝚃𝙸𝙵𝙸𝙲𝙰𝚃𝙴","⧠ • 𝚈𝚃𝙲𝙴𝚁𝚃𝙸𝙵𝙸𝙲𝙰𝚃𝙴","⧠ • 𝚆𝙴𝚃𝙶𝙻𝙰𝚂𝚂","⧠ • 𝙼𝚄𝙻𝚃𝙸𝙲𝙾𝙻𝙾𝚁𝟹𝙳","⧠ • 𝚆𝙰𝚃𝙴𝚁𝙲𝙾𝙻𝙾𝚁","⧠ • 𝙻𝚄𝚇𝚄𝚁𝚈𝙶𝙾𝙻𝙳","⧠ • 𝙶𝙰𝙻𝙰𝚇𝚈𝚆𝙰𝙻𝙻𝙿𝙰𝙿𝙴𝚁","⧠ • 𝙻𝙸𝙶𝙷𝚃𝚃𝙴𝚇𝚃","⧠ • 𝙱𝙴𝙰𝚄𝚃𝙸𝙵𝚄𝙻𝙵𝙻𝙾𝚆𝙴𝚁","⧠ • 𝙿𝚄𝙿𝙿𝚈𝙲𝚄𝚃𝙴","⧠ • 𝚁𝙾𝚈𝙰𝙻𝚃𝙴𝚇𝚃","⧠ • 𝙷𝙴𝙰𝚁𝚃𝚂𝙷𝙰𝙿𝙴𝙳","⧠ • 𝙱𝙸𝚁𝚃𝙷𝙳𝙰𝚈𝙲𝙰𝙺𝙴","⧠ • 𝙶𝙰𝙻𝙰𝚇𝚈𝚂𝚃𝚈𝙻𝙴","⧠ • 𝙷𝙾𝙻𝙾𝙶𝚁𝙰𝙼𝟹𝙳","⧠ • 𝙶𝚁𝙴𝙴𝙽𝙽𝙴𝙾𝙽","⧠ • 𝙶𝙻𝙾𝚂𝚂𝚈𝙲𝙷𝚁𝙾𝙼𝙴","⧠ • 𝙶𝚁𝙴𝙴𝙽𝙱𝚄𝚂𝙷","⧠ • 𝙼𝙴𝚃𝙰𝙻𝙻𝙾𝙶𝙾","⧠ • 𝙽𝙾𝙴𝙻𝚃𝙴𝚇𝚃","⧠ • 𝙶𝙻𝙸𝚃𝚃𝙴𝚁𝙶𝙾𝙻𝙳","⧠ • 𝚃𝙴𝚇𝚃𝙲𝙰𝙺𝙴","⧠ • 𝚂𝚃𝙰𝚁𝚂𝙽𝙸𝙶𝙷𝚃","⧠ • 𝚆𝙾𝙾𝙳𝙴𝙽𝟹𝙳","⧠ • 𝚃𝙴𝚇𝚃𝙱𝚈𝙽𝙰𝙼𝙴","⧠ • 𝚆𝚁𝙸𝚃𝙴𝙶𝙰𝙻𝙰𝙲𝚈","⧠ • 𝙶𝙰𝙻𝙰𝚇𝚈𝙱𝙰𝚃","⧠ • 𝚂𝙽𝙾𝚆𝟹𝙳","⧠ • 𝙱𝙸𝚁𝚃𝙷𝙳𝙰𝚈𝙳𝙰𝚈","⧠ • 𝙶𝙾𝙻𝙳𝙿𝙻𝙰𝚈𝙱𝚄𝚃𝚃𝙾𝙽","⧠ • 𝚂𝙸𝙻𝚅𝙴𝚁𝙿𝙻𝙰𝚈𝙱𝚄𝚃𝚃𝙾𝙽","⧠ • 𝙵𝚁𝙴𝙴𝙵𝙸𝚁𝙴","⧠ • 𝙱𝙻𝙰𝙲𝙺𝙿𝙸𝙽𝙺","⧠ • 𝙽𝙴𝙾𝙽","⧠ • 𝙶𝚁𝙴𝙴𝙽𝙽𝙴𝙾𝙽","⧠ • 𝙰𝙳𝚅𝙰𝙽𝙲𝙴𝙶𝙻𝙾𝚆","⧠ • 𝙵𝚄𝚃𝚄𝚁𝙴𝙽𝙴𝙾𝙽","⧠ • 𝚂𝙰𝙽𝙳𝚆𝚁𝙸𝚃𝙸𝙽𝙶","⧠ • 𝚂𝙰𝙽𝙳𝚂𝚄𝙼𝙼𝙴𝚁","⧠ • 𝚂𝙰𝙽𝙳𝙴𝙽𝙶𝚁𝙰𝚅𝙴𝙳","⧠ • 𝙼𝙴𝚃𝙰𝙻𝙳𝙰𝚁𝙺","⧠ • 𝙽𝙴𝙾𝙽𝙻𝙸𝙶𝙷𝚃","⧠ • 𝙲𝙰𝚁𝙱𝙾𝙽","⧠ • 𝙷𝙾𝙻𝙾𝙶𝚁𝙰𝙿𝙷𝙸𝙲","⧠ • 𝚃𝙴𝚇𝚃𝟷𝟿𝟷𝟽","⧠ • 𝙼𝙸𝙽𝙸𝙾𝙽","⧠ • 𝙳𝙴𝙻𝚄𝚇𝙴𝚂𝙸𝙻𝚅𝙴𝚁","⧠ • 𝙽𝙴𝚆𝚈𝙴𝙰𝚁𝙲𝙰𝚁𝙳","⧠ • 𝙱𝙻𝙾𝙾𝙳𝙵𝚁𝙾𝚂𝚃𝙴𝙳","⧠ • 𝙷𝙰𝙻𝙻𝙾𝚆𝙴𝙴𝙽","⧠ • 𝙹𝙾𝙺𝙴𝚁𝙻𝙾𝙶𝙾","⧠ • 𝙵𝙸𝚁𝙴𝚆𝙾𝚁𝙺𝚂𝙿𝙰𝚁𝙺𝙻𝙴","⧠ • 𝙽𝙰𝚃𝚄𝚁𝙴𝙻𝙴𝙰𝚅𝙴𝚂","⧠ • 𝚆𝙾𝙽𝙳𝙴𝚁𝙵𝚄𝙻𝙶𝚁𝙰𝙵𝙵𝙸𝚃𝙸","⧠ • 𝚂𝙻𝙸𝙲𝙴𝙳","⧠ • 𝙱𝙾𝙺𝙴𝙷","⧠ • 𝙰𝙼𝙾𝙽𝙶𝚄𝚂","⧠ • 𝚃𝙾𝚇𝙸𝙲","⧠ • 𝚂𝚃𝚁𝙰𝚆𝙱𝙴𝚁𝚁𝚈","⧠ • 𝙱𝙾𝚇𝟹𝙳","⧠ • 𝚁𝙾𝙰𝙳𝚆𝙰𝚁𝙽𝙸𝙽𝙶","⧠ • 𝙱𝚁𝙴𝙰𝙺𝚆𝙰𝙻𝙻","⧠ • 𝙸𝙲𝙴𝙲𝙾𝙻𝙳","⧠ • 𝙻𝚄𝚇𝚄𝚁𝚈","⧠ • 𝙲𝙻𝙾𝚄𝙳","⧠ • 𝚂𝚄𝙼𝙼𝙴𝚁𝚂𝙰𝙽𝙳","⧠ • 𝙷𝙾𝚁𝚁𝙾𝚁𝙱𝙻𝙾𝙾𝙳","⧠ • 𝚃𝙷𝚄𝙽𝙳𝙴𝚁","⧠ • 𝚃𝙾𝙻𝙾𝙻𝚂𝙴𝚁𝚃𝙸","⧠ • 𝙱𝚄𝙲𝙸𝙽𝚂𝙴𝚁𝚃𝙸","⧠ • 𝙿𝙰𝙲𝙰𝚁𝚂𝙴𝚁𝚃𝙸","⧠ • 𝙼𝙴𝙼𝙴𝟷","⧠ • 𝙼𝙴𝙼𝙴𝟸","⧠ • 𝚉𝙾𝙼𝙱𝙸𝙴","⧠ • 𝙽𝙰𝙼𝙰𝙹𝙴𝙿𝙰𝙽𝙶","⧠ • 𝚀𝚄𝙾𝚃𝙴𝚆𝙾𝙾𝙳","⧠ • 𝙰𝙾𝚅𝚆𝙰𝙻𝙻","⧠ • 𝙼𝙻𝚆𝙰𝙻𝙻","⧠ • 𝙻𝙾𝙶𝙾𝙶𝙰𝙼𝙸𝙽𝙶"]
        const cmdFun = ["⧠ • 𝚂𝙸𝙼𝙸𝙷","⧠ • 𝙷𝙰𝙻𝙰𝙷","⧠ • 𝙷𝙸𝙻𝙸𝙷","⧠ • 𝙷𝚄𝙻𝚄𝙷","⧠ • 𝙷𝙴𝙻𝙴𝙷","⧠ • 𝙷𝙾𝙻𝙾𝙷","⧠ • 𝙹𝙰𝙳𝙸𝙰𝙽","⧠ • 𝙹𝙾𝙳𝙾𝙷𝙺𝚄","⧠ • 𝙳𝙴𝙻𝚃𝚃𝚃","⧠ • 𝚃𝙸𝙲𝚃𝙰𝙲𝚃𝙾𝙴","⧠ • 𝙵𝙰𝙼𝙸𝙻𝚈𝟷𝟶𝟶","⧠ • 𝚃𝙴𝙱𝙰𝙺","⧠ • 𝙼𝙰𝚃𝙷","⧠ • 𝚂𝚄𝙸𝚃𝙿𝚅𝙿","⧠ • 𝚂𝙰𝙽𝙶𝙴𝙲𝙴𝙺","⧠ • 𝙲𝙴𝙺𝚂𝙰𝙽𝙶𝙴","⧠ • 𝙶𝙰𝚈𝙲𝙴𝙺","⧠ • 𝙲𝙴𝙺𝙶𝙰𝚈","⧠ • 𝙻𝙴𝚂𝙱𝙸𝙲𝙴𝙺","⧠ • 𝙲𝙴𝙺𝙻𝙴𝚂𝙱𝙸","⧠ • 𝙺𝙰𝙿𝙰𝙽𝙺𝙰𝙷","⧠ • 𝚆𝙰𝙽𝙶𝚈","⧠ • 𝙲𝙴𝙺𝙼𝙰𝚃𝙸","⧠ • 𝙲𝙰𝙽𝚃𝙸𝙺𝙲𝙴𝙺","⧠ • 𝙲𝙴𝙺𝙲𝙰𝙽𝚃𝙸𝙺","⧠ • 𝙶𝙰𝙽𝚃𝙴𝙽𝙶𝙲𝙴𝙺","⧠ • 𝙲𝙴𝙺𝙶𝙰𝙽𝚃𝙴𝙽𝙶","⧠ • 𝚁𝙰𝚃𝙴","⧠ • 𝙱𝙰𝙶𝙰𝙸𝙼𝙰𝙽𝙰𝙺𝙰𝙷","⧠ • 𝙱𝙸𝚂𝙰𝙺𝙰𝙷","⧠ • 𝙰𝙿𝙰𝙺𝙰𝙷","⧠ • 𝚃𝚁𝚄𝚃𝙷","⧠ • 𝙳𝙰𝚁𝙴","⧠ • 𝙰𝙺𝙸𝙽𝙰𝚃𝙾𝚁","⧠ • 𝙲𝙰𝙽𝙲𝙴𝙻𝙰𝙺𝙸𝙽𝙰𝚃𝙾𝚁","⧠ • 𝙲𝙷𝙴𝙲𝙺𝙼𝙴","⧠ • 𝚁𝙰𝚃𝙴𝟷","⧠ • 𝙿𝙸𝙲𝙺","⧠ • 𝙸𝙼𝙿𝙾𝚂𝚃𝙾𝚁𝙼𝚄𝙻𝙰𝙸","⧠ • 𝙸𝙼𝙿𝙾𝚂𝚃𝙾𝚁𝙲𝙴𝙺","⧠ • 𝙸𝙼𝙿𝙾𝚂𝚃𝙾𝚁𝙰𝙺𝙷𝙸𝚁𝙸","⧠ • 𝚃𝙴𝙱𝙰𝙺𝙼𝚄𝙻𝙰𝙸","⧠ • 𝚃𝙴𝙱𝙰𝙺𝙺","⧠ • 𝚃𝙴𝙱𝙰𝙺𝙰𝙺𝙷𝙸𝚁𝙸","⧠ • 𝙲𝙴𝙺𝙸𝙽𝙵𝙾","⧠ • 𝚃𝙴𝙿𝚄𝙺𝙶𝙰𝙼𝙴","⧠ • 𝚃𝙴𝙿𝚄𝙺","⧠ • 𝚂𝚄𝙸𝚃𝙱𝙾𝚃","⧠ • 𝙶𝙰𝙼𝙴𝙷𝙰𝙽𝚃𝚄","⧠ • 𝚀𝚀","⧠ • 𝙰𝙳𝚄𝙰𝚈𝙰𝙼","⧠ • 𝙰𝙳𝚄𝙻𝙰𝚈𝙰𝙽𝙶𝙰𝙽","⧠ • 𝙰𝙳𝚄𝙸𝙺𝙰𝙽","⧠ • 𝙱𝙰𝙻𝙰𝙿𝙰𝙽","⧠ • 𝙱𝙴𝚁𝙰𝙽𝚃𝙴𝙼","⧠ • 𝙱𝙴𝚁𝚃𝙰𝚁𝚄𝙽𝙶","⧠ • 𝙰𝙳𝚄𝙼𝙰𝚂𝙰𝙺","⧠ • 𝙿𝙴𝚃𝚄𝙰𝙻𝙰𝙽𝙶𝙰𝙽𝙴𝙿𝙸𝙺","⧠ • 𝙼𝙴𝙼𝙱𝙰𝙽𝙶𝚄𝙽𝚁𝚄𝙼𝙰𝙷","⧠ • 𝙱𝙴𝚁𝙱𝚄𝚁𝚄","⧠ • 𝙰𝙳𝚅𝙴𝙽𝚃𝚄𝚁𝙴","⧠ • 𝙲𝙰𝚂𝙸𝙽𝙾","⧠ • 𝙰𝙳𝚄𝙷𝙴𝚆𝙰𝙽","⧠ • 𝙲𝙾𝙸𝙽𝙵𝙻𝙸𝙿","⧠ • 𝚁𝙾𝚄𝙻𝙴𝚃𝚃𝙴","⧠ • 𝙳𝙸𝙲𝙴𝙶𝙰𝙼𝙱𝙻𝙴","⧠ • 𝚂𝙻𝙾𝚃𝙼𝙰𝙲𝙷𝙸𝙽𝙴","⧠ • 𝙱𝙻𝙰𝙲𝙺𝙹𝙰𝙲𝙺","⧠ • 𝙼𝙴𝙽𝙰𝙽𝙰𝙼𝚄𝙱𝙸","⧠ • 𝙰𝙳𝚄𝙿𝙰𝙷𝙻𝙰𝚆𝙰𝙽","⧠ • 𝚂𝙾𝚄𝙽𝙳","⧠ • 𝙺𝙰𝙻𝙰𝙷𝙺𝙰𝙽𝙼𝙾𝙽𝚂𝚃𝙴𝚁","⧠ • 𝙱𝙾𝚇𝙸𝙽𝙶","⧠ • 𝙼𝙰𝙽𝙲𝙸𝙽𝙶","⧠ • 𝙱𝙴𝚁𝙺𝙴𝙻𝙰𝙷𝙸","⧠ • 𝚂𝙺𝙾𝚁","⧠ • 𝙳𝙾𝙺𝚃𝙴𝚁","⧠ • 𝙵𝙿𝚂𝙻𝙾𝙶𝙾","⧠ • 𝙰𝙽𝙾𝙽𝚈𝙼𝙾𝚄𝚂𝙻𝙾𝙶𝙾","⧠ • 𝙻𝙸𝙼𝙸𝚃","⧠ • 𝙱𝚄𝚈𝙻𝙸𝙼𝙸𝚃","⧠ • 𝚃𝙵𝙻𝙸𝙼𝙸𝚃","⧠ • 𝚃𝙵𝙱𝙰𝙻𝙰𝙽𝙲𝙴","⧠ • 𝙱𝙸𝙽𝙶𝙾","⧠ • 𝙲𝚅𝙻𝙸𝙼𝙸𝚃","⧠ • 𝙰𝙳𝚄𝙰𝙻𝙸𝙴𝙽","⧠ • 𝙿𝙾𝙺𝙴𝚁","⧠ • 𝙸𝙺𝚈","⧠ • 𝚂𝙷𝙾𝙿","⧠ • 𝙿𝚁𝙸𝙲𝙴","⧠ • 𝙼𝙸𝙽𝙸𝙽𝙶"]
                const cmdSup = ["𖣐 • 𝙰𝙸𝙽𝙸𝙼𝙴","𖣐 • 𝙰𝙸𝙽𝙸𝙼𝙴𝟸","𖣐 • 𝙰𝙸𝙳𝙰𝙻𝙻𝙴","𖣐 • 𝙶𝙱𝙰𝚁𝙳","𖣐 • 𝙰𝙸","𖣐 • 𝚃𝙾𝙰𝙽𝙸𝙼𝙴","𖣐 • 𝚃𝙾𝙰𝙽𝙸𝙼𝙴𝟸","𖣐 • 𝚃𝙾𝙰𝙽𝙸𝙼𝙴𝟹","𖣐 • 𝙰𝙸𝙲𝚁𝙴𝙰𝚃𝙴","𖣐 • 𝙰𝙸𝙳𝙸𝙵𝙵","𖣐 • 𝙰𝙸𝚆𝙰𝚁𝙽𝙰𝙸𝙽","𖣐 • 𝚁𝙴𝙼𝙸𝙽𝙸","𖣐 • 𝙰𝙸𝚅𝙸𝙳𝙴𝙾","𖣐 • 𝚂𝚃𝙰𝙱𝙻𝙴𝙳𝙸𝙵𝙵","𖣐 • 𝙿𝙴𝙽𝙳𝙴𝚃𝙰","𖣐 • 𝙰𝙻𝚀𝚄𝚁𝙰𝙽","𖣐 • 𝙰𝙸𝚂𝙲𝙴𝙽𝙴","𖣐 • 𝙰𝙸𝙴𝙳𝙸𝚃","𖣐 • 𝙰𝙸𝙲𝚁𝙴𝙰𝚃𝙴𝟸","𖣐 • 𝙳𝙾𝙺𝚃𝙴𝚁","𖣐 • 𝙿𝙸𝙻𝙾𝚃","𖣐 • 𝙶𝚄𝚁𝚄","𖣐 • 𝙷𝚁𝙳","𖣐 • 𝙿𝙾𝙻𝙸𝚂𝙸","𖣐 • 𝚄𝚂𝚃𝙰𝙳","𖣐 • 𝙰𝙸𝙳𝙱","𖣐 • 𝙱𝙸𝙺𝚂𝚄","𖣐 • 𝙱𝙸𝙽𝙶","𖣐 • 𝙳𝙾𝚂𝙴𝙽","𖣐 • 𝙼𝙸𝙳𝙹𝙾𝚄𝚁𝙽𝙴𝚈","𖣐 • 𝙰𝙸𝚁𝙴𝙰𝙻𝙸𝚂𝚃𝙸𝙲","𖣐 • 𝙰𝙸𝙽𝙴𝙸𝙼𝙰","𖣐 • 𝙰𝙸𝙰𝙱𝚂𝙾𝙻𝚄𝚃𝙴𝙻𝚈","𖣐 • 𝙰𝙸𝙰𝙱𝚂𝙾𝙻𝚄𝚃𝙴𝙻𝚈2","𖣐 • 𝙰𝙸𝙰𝙽𝚈𝚃𝙷𝙸𝙽𝙶","𖣐 • 𝙰𝙸𝙽𝙴𝙸𝙼𝙰","𖣐 • 𝙽𝙰𝚁𝚄𝚃𝙾","𖣐 • 𝙻𝚄𝙵𝙵𝚈","𖣐 • 𝙼𝙰𝚁𝙰𝙷","𖣐 • 𝚂𝙴𝙹𝙰𝚁𝙰𝙷","𖣐 • 𝚂𝙿𝙾𝙽𝙶𝙴𝙱𝙾𝙱","𖣐 • 𝙰𝙸𝙲𝚄𝚂𝚃𝙾𝙼𝙴","𖣐 • 𝙰𝙸𝙲𝚁𝙴𝙰𝚃𝙴3","𖣐 • 𝙰𝙸𝙶𝙴𝙽𝙴𝚁𝙰𝚃𝙾𝚁","𖣐 • 𝙶𝚄𝚁𝙰","𖣐 • 𝙿𝚁𝙰𝙱𝙾𝚆𝙾","𖣐 • 𝙼𝙴𝙶𝙰𝚆𝙰𝚃𝙸","𖣐 • 𝙹𝙾𝙺𝙾𝚆𝙸","𖣐 • 𝙴𝙻𝙾𝙽𝙼𝚄𝚂𝙺","𖣐 • 𝚁𝙾𝙽𝙰𝙻𝙳𝙾","𖣐 • 𝙼𝙴𝚂𝚂𝙸","𖣐 • 𝙽𝙴𝚈𝙼𝙰𝚁","𖣐 • 𝚃𝙽𝙸","𖣐 • 𝙺𝙴𝙹𝙰𝙼","𖣐 • 𝙷𝙰𝙲𝙺𝙴𝚁","𖣐 • 𝙿𝙴𝙼𝙱𝚄𝙽𝚄𝙷","𖣐 • 𝙼𝙰𝙻𝙸𝙽𝙶","𖣐 • 𝙳𝚄𝙺𝚄𝙽","𖣐 • 𝙻𝚄𝙲𝙸𝙵𝙴𝚁","𖣐 • 𝙷𝙰𝙺𝙸𝙼","𖣐 • 𝙺𝚈𝚈","𖣐 • 𝙺𝚈","𖣐 • 𝙿𝚁𝙾𝙼𝙿𝚃","𖣐 • 𝙿𝚁𝙾𝙼𝙿𝚃𝟸","𖣐 • 𝙰𝙸𝙱𝙸𝙽𝙶","𖣐 • 𝙰𝙸𝙱𝙸𝙽𝙶𝟸","𖣐 • 𝙿𝙴𝚁𝙿𝙻𝙴𝚇𝙸𝚃𝚈","𖣐 • 𝙰𝙸𝙼𝙰𝚃𝙷"]
        const cmdAnime = ["⧠ • 𝙰𝙺𝙸𝚁𝙰","⧠ • 𝙰𝙺𝙸𝚈𝙰𝙼𝙰","⧠ • 𝙰𝙽𝙰","⧠ • 𝙰𝚂𝚄𝙽𝙰","⧠ • 𝙰𝚈𝚄𝚉𝙰𝚆𝙰","⧠ • 𝙱𝙾𝚁𝚄𝚃𝙾","⧠ • 𝙲𝙷𝙸𝚃𝙾𝙶𝙴","⧠ • 𝙳𝙴𝙸𝙳𝙰𝚁𝙰","⧠ • 𝙳𝙾𝚁𝙰𝙴𝙼𝙾𝙽","⧠ • 𝙴𝙻𝙰𝙸𝙽𝙰","⧠ • 𝙴𝙼𝙸𝙻𝙸𝙰","⧠ • 𝙴𝚁𝚉𝙰","⧠ • 𝙶𝚁𝙴𝙼𝙾𝚁𝚈","⧠ • 𝙷𝙴𝚂𝚃𝙸𝙰","⧠ • 𝙷𝙸𝙽𝙰𝚃𝙰","⧠ • 𝙸𝙽𝙾𝚁𝙸","⧠ • 𝙸𝚂𝚄𝚉𝚄","⧠ • 𝙸𝚃𝙰𝙲𝙷𝙸","⧠ • 𝙸𝚃𝙾𝚁𝙸","⧠ • 𝙺𝙰𝙶𝙰𝚂","⧠ • 𝙺𝙰𝙶𝚄𝚁𝙰","⧠ • 𝙺𝙰𝙺𝙰𝚂𝙸𝙷","⧠ • 𝙺𝙰𝙾𝚁𝙸","⧠ • 𝙺𝙴𝙽𝙴𝙺𝙸","⧠ • 𝙺𝙾𝚃𝙾𝚁𝙸","⧠ • 𝙺𝚄𝚁𝚄𝙼𝙸","⧠ • 𝙻𝙾𝙻𝙸","⧠ • 𝙼𝙰𝙳𝙰𝚁𝙰","⧠ • 𝙼𝙸𝙺𝙰𝚂𝙰","⧠ • 𝙼𝙸𝙺𝚄","⧠ • 𝙼𝙸𝙽𝙰𝚃𝙾","⧠ • 𝙽𝙰𝚁𝚄𝚃𝙾","⧠ • 𝙽𝙴𝚉𝚄𝙺𝙾","⧠ • 𝙾𝙽𝙴𝙿𝙸𝙴𝙲𝙴","⧠ • 𝙿𝙾𝙺𝙴𝙼𝙾𝙽","⧠ • 𝚁𝙸𝚉𝙴","⧠ • 𝚂𝙰𝙶𝙸𝚁𝙸","⧠ • 𝚂𝙰𝙺𝚄𝚁𝙰","⧠ • 𝚂𝙰𝚂𝚄𝙺𝙴","⧠ • 𝚂𝙷𝙸𝙽𝙰","⧠ • 𝚂𝙷𝙸𝙽𝙺𝙰","⧠ • 𝚂𝙷𝙸𝚉𝚄𝙺𝙰","⧠ • 𝚂𝙷𝙾𝚃𝙰","⧠ • 𝚃𝙾𝚄𝙺𝙰𝙲𝙷𝙰𝙽","⧠ • 𝚃𝚂𝚄𝙽𝙰𝙳𝙴","⧠ • 𝚈𝚄𝙺𝙸","⧠ • 𝙾𝙿𝙿𝙰𝙸"]
        const cmdPrimbon = ["⧠ • 𝙽𝙾𝙼𝙾𝚁𝙷𝙾𝙺𝙸","⧠ • 𝙰𝚁𝚃𝙸𝙼𝙸𝙼𝙿𝙸","⧠ • 𝙰𝚁𝚃𝙸𝙽𝙰𝙼𝙰","⧠ • 𝚁𝙰𝙼𝙰𝙻𝙹𝙾𝙳𝙾𝙷","⧠ • 𝚁𝙰𝙼𝙰𝙻𝙹𝙾𝙳𝙾𝙷𝙱𝙰𝙻𝙸","⧠ • 𝚂𝚄𝙰𝙼𝙸𝙸𝚂𝚃𝚁𝙸","⧠ • 𝚁𝙰𝙼𝙰𝙻𝙲𝙸𝙽𝚃𝙰","⧠ • 𝙲𝙾𝙲𝙾𝙺𝙽𝙰𝙼𝙰","⧠ • 𝙿𝙰𝚂𝙰𝙽𝙶𝙰𝙽","⧠ • 𝙹𝙰𝙳𝙸𝙰𝙽𝙽𝙸𝙺𝙰𝙷","⧠ • 𝚂𝙸𝙵𝙰𝚃𝚄𝚂𝙰𝙷𝙰","⧠ • 𝚁𝙴𝚉𝙴𝙺𝙸","⧠ • 𝙿𝙴𝙺𝙴𝚁𝙹𝙰𝙰𝙽","⧠ • 𝙿𝙴𝙽𝚈𝙰𝙺𝙸𝚃","⧠ • 𝙵𝙴𝙽𝙶𝚂𝙷𝚄𝙸","⧠ • 𝙷𝙰𝚁𝙸𝙱𝙰𝙸𝙺","⧠ • 𝙷𝙰𝚁𝙸𝚂𝙰𝙽𝙶𝙰𝚁","⧠ • 𝙷𝙰𝚁𝙸𝚂𝙸𝙰𝙻","⧠ • 𝙽𝙰𝙶𝙰𝙷𝙰𝚁𝙸","⧠ • 𝙰𝚁𝙰𝙷𝚁𝙴𝚉𝙴𝙺𝙸","⧠ • 𝙿𝙴𝚁𝚄𝙽𝚃𝚄𝙽𝙶𝙰𝙽","⧠ • 𝚆𝙴𝚃𝙾𝙽","⧠ • 𝙺𝙰𝚁𝙰𝙺𝚃𝙴𝚁","⧠ • 𝙺𝙴𝙱𝙴𝚁𝚄𝙽𝚃𝚄𝙽𝙶𝙰𝙽","⧠ • 𝙼𝙴𝙼𝙰𝙽𝙲𝙸𝙽𝙶","⧠ • 𝙼𝙰𝚂𝙰𝚂𝚄𝙱𝚄𝚁","⧠ • 𝚉𝙾𝙳𝙸𝙰𝙺","⧠ • 𝚂𝙷𝙸𝙾"]
        const cmdConv = ["⧠ • 𝙰𝚃𝚃𝙿","⧠ • 𝙰𝚃𝚃𝙿𝟸","⧠ • 𝚃𝚃𝙿","⧠ • 𝚃𝚃𝙿𝟸","⧠ • 𝚃𝚃𝙿𝟹","⧠ • 𝚃𝚃𝙿𝟺","⧠ • 𝚃𝚃𝙿𝟻","⧠ • 𝚃𝚃𝙿𝟼","⧠ • 𝚃𝙾𝙸𝙼𝙰𝙶𝙴","⧠ • 𝚀𝙲","⧠ • 𝚁𝙴𝙼𝙾𝚅𝙴𝙱𝙶","⧠ • 𝚂𝚃𝙸𝙲𝙺𝙴𝚁","⧠ • 𝚂𝚃𝙸𝙲𝙺𝙴𝚁𝚆𝙼","⧠ • 𝙴𝙼𝙾𝙹𝙸𝙼𝙸𝚇","⧠ • 𝙴𝙼𝙾𝙹𝙸𝙼𝙸𝚇𝟸","⧠ • 𝚃𝙾𝚅𝙸𝙳𝙴𝙾","⧠ • 𝚃𝙾𝙶𝙸𝙵","⧠ • 𝚃𝙾𝚄𝚁𝙻","⧠ • 𝚃𝙾𝚅𝙽","⧠ • 𝚃𝙾𝙼𝙿𝟹","⧠ • 𝚆𝙼","⧠ • 𝚃𝙾𝙰𝚄𝙳𝙸𝙾","⧠ • 𝙴𝙱𝙸𝙽𝙰𝚁𝚈","⧠ • 𝙳𝙱𝙸𝙽𝙰𝚁𝚈","⧠ • 𝚂𝚃𝚈𝙻𝙴𝚃𝙴𝚇𝚃","⧠ • 𝚂𝙼𝙴𝙼𝙴","⧠ • 𝚂𝙼𝙸𝙼","⧠ • 𝙱𝙰𝚂𝚂","⧠ • 𝙱𝙻𝙾𝚆𝙽","⧠ • 𝙳𝙴𝙴𝙿","⧠ • 𝙴𝙰𝚁𝚁𝙰𝙿𝙴","⧠ • 𝙵𝙰𝚂𝚃","⧠ • 𝙵𝙰𝚃","⧠ • 𝙽𝙸𝙶𝙷𝚃𝙲𝙾𝚁𝙴","⧠ • 𝚁𝙴𝚅𝙴𝚁𝚂𝙴","⧠ • 𝚁𝙾𝙱𝙾𝚃","⧠ • 𝚂𝙻𝙾𝚆","⧠ • 𝚃𝚄𝙿𝙰𝙸","⧠ • 𝚂𝙷𝙾𝚁𝚃𝙻𝙸𝙽𝙺","⧠ • 𝚂𝙷𝙾𝚁𝚃𝙻𝙸𝙽𝙺𝟸","⧠ • 𝚂𝙷𝙾𝚁𝚃𝙻𝙸𝙽𝙺𝟹","⧠ • 𝚂𝙷𝙾𝚁𝚃𝙻𝙸𝙽𝙺𝟺","⧠ • 𝙸𝙽𝚂𝚃𝙰𝙶𝚁𝙰𝙼","⧠ • 𝚂𝙲𝙰𝚁𝚈","⧠ • 𝙶𝙻𝙸𝚃𝙲𝙷","⧠ • 𝚁𝙴𝙹𝙴𝙲𝚃𝙴𝙳","⧠ • 𝙿𝚂𝟺","⧠ • 𝙱𝚁𝙰𝚉𝚉𝙴𝚁𝚂","⧠ • 𝙳𝙸𝚂𝚃𝙾𝚁𝚃","⧠ • 𝙼𝙾𝚄𝚂𝚃𝙰𝙲𝙷𝙴","⧠ • 𝙵𝚁𝙰𝙼𝙴","⧠ • 𝙼𝙸𝚂𝚂𝙸𝙾𝙽𝙿𝙰𝚂𝚂𝙴𝙳","⧠ • 𝙴𝙼𝙱𝙾𝚂𝚂","⧠ • 𝚂𝙿𝙾𝙽𝙶𝙴𝙱𝙾𝙱","⧠ • 𝙵𝙰𝙲𝙴𝙱𝙾𝙾𝙺","⧠ • 𝙳𝙸𝚂𝙲𝙾𝚁𝙳𝙷𝙾𝚄𝚂𝙴","⧠ • 𝙺𝙰𝚁𝙴𝙽𝙷𝙰𝚅𝙴","⧠ • 𝚃𝙷𝙰𝙽𝙾𝚂","⧠ • 𝙰𝙿𝙿𝚁𝙾𝚅𝙴𝙳","⧠ • 𝙱𝚄𝚁𝙽","⧠ • 𝙲𝙷𝙰𝙻𝙻𝙴𝙽𝙶𝙴𝚁","⧠ • 𝙲𝚁𝚄𝚂𝙷","⧠ • 𝙳𝙸𝚃𝙰𝙲𝚃𝙾𝚁","⧠ • 𝚅𝙴𝚁𝚂𝚄𝚂","⧠ • 𝚃𝙾𝙰𝙽𝙸𝙼𝙴","⧠ • 𝟷𝟿𝟽𝟽", "⧠ • 𝙰𝙳𝙴𝙽", "⧠ • 𝙱𝚁𝙰𝙽𝙽𝙰𝙽", "⧠ • 𝙱𝚁𝙾𝙾𝙺𝙻𝚈𝙽", "⧠ • 𝙲𝙻𝙰𝚁𝙴𝙽𝙳𝙾𝙽", "⧠ • 𝙴𝙰𝚁𝙻𝚈𝙱𝙸𝚁𝙳","⧠ • 𝙶𝙸𝙽𝙶𝙷𝙰𝙼","⧠ • 𝙷𝚄𝙳𝚂𝙾𝙽","⧠ • 𝙸𝙽𝙺𝚆𝙴𝙻𝙻", "⧠ • 𝙺𝙴𝙻𝚅𝙸𝙽","⧠ • 𝙻𝙰𝚁𝙺","⧠ • 𝙻𝙾𝙵𝙸","⧠ • 𝙼𝙰𝚅𝙴𝙽", "⧠ • 𝙼𝙰𝚈𝙵𝙰𝙸𝚁","⧠ • 𝙼𝙾𝙾𝙽","⧠ • 𝙽𝙰𝚂𝙷𝚅𝙸𝙻𝙻𝙴","⧠ • 𝙿𝙴𝚁𝙿𝙴𝚃𝚄𝙰","⧠ • 𝚁𝙴𝚈𝙴𝚂","⧠ • 𝚁𝙸𝚂𝙴","⧠ • 𝚂𝚃𝙸𝙽𝚂𝙾𝙽","⧠ • 𝚂𝙻𝚄𝙼𝙱𝙴𝚁","⧠ • 𝚃𝙾𝙰𝚂𝚃𝙴𝚁","⧠ • 𝚅𝙰𝙻𝙴𝙽𝙲𝙸𝙰","⧠ • 𝚃𝚃𝚂","⧠ • 𝚃𝙾𝙰𝙽𝙸𝙼𝙴𝟸","⧠ • 𝚃𝙾𝙰𝙽𝙸𝙼𝙴𝟹","⧠ • 𝙷𝙸𝚃𝚄𝙽𝙶𝙺𝙰𝚃𝙰","⧠ • 𝙷𝙸𝚃𝚄𝙽𝙶𝙷𝚄𝚁𝚄𝙵","⧠ • 𝙲𝙾𝚄𝙽𝚃","⧠ • 𝙱𝙰𝙹𝚄𝙸𝙽","⧠ • 𝙷𝙰𝚁𝙶𝙰𝙱𝙱𝙼","⧠ • 𝚁𝙸𝙽𝙶𝙺𝙰𝚂𝙰𝙽","⧠ • 𝙺𝙾𝙽𝚅𝙴𝚁𝚂𝙸","⧠ • 𝙴𝙲𝙷𝙾","⧠ • 𝚃𝚁𝙰𝙽𝚂𝙻𝙰𝚃𝙴","⧠ • 𝚁𝚅𝙾","⧠ • 𝚁𝙴𝙰𝙳𝚅𝙸𝙴𝚆𝙾𝙽𝙲𝙴"]
        const cmdMain = ["⧠ • 𝙿𝙸𝙽𝙶","⧠ • 𝙾𝚆𝙽𝙴𝚁","⧠ • 𝙼𝙴𝙽𝚄","⧠ • 𝙳𝙴𝙻𝙴𝚃𝙴","⧠ • 𝙸𝙽𝙵𝙾𝙲𝙷𝙰𝚃","⧠ • 𝚀𝚄𝙾𝚃𝙴𝙳","⧠ • 𝙻𝙸𝚂𝚃𝙿𝙲","⧠ • 𝚁𝚄𝙽𝚃𝙸𝙼𝙴","⧠ • 𝙻𝙸𝚂𝚃𝙶𝙲","⧠ • 𝙻𝙸𝚂𝚃𝙾𝙽𝙻𝙸𝙽𝙴","⧠ • 𝚆𝙰𝙽𝚄𝙼𝙱𝙴𝚁","⧠ • 𝚂𝙿𝙴𝙴𝙳𝚃𝙴𝚂𝚃","⧠ • 𝚂𝙴𝚃𝙲𝙼𝙳","⧠ • 𝙻𝙸𝚂𝚃𝙲𝙼𝙳","⧠ • 𝙳𝙴𝙻𝙲𝙼𝙳","⧠ • 𝙻𝙾𝙲𝙺𝙲𝙼𝙳","⧠ • 𝙰𝙳𝙳𝙼𝚂𝙶","⧠ • 𝙻𝙸𝚂𝚃𝙼𝚂𝙶","⧠ • 𝙶𝙴𝚃𝙼𝚂𝙶","⧠ • 𝚂𝚂𝚆𝙴𝙱","⧠ • 𝙳𝙴𝙻𝙼𝚂𝙶","⧠ • 𝙰𝙽𝙾𝙽𝚈𝙼𝙾𝚄𝚂","⧠ • 𝚂𝚃𝙰𝚁𝚃","⧠ • 𝙽𝙴𝚇𝚃","⧠ • 𝙺𝙴𝙻𝚄𝙰𝚁","⧠ • 𝚁𝙴𝙰𝙻𝙾𝚆𝙽𝙴𝚁"]
        const cmdOwner = ["⧠ • 𝚁𝙴𝙰𝙲𝚃","⧠ • 𝙲𝙷𝙰𝚃","⧠ • 𝙹𝙾𝙸𝙽","⧠ • 𝙻𝙴𝙰𝚅𝙴","⧠ • 𝙱𝙻𝙾𝙲𝙺","⧠ • 𝚄𝙽𝙱𝙻𝙾𝙲𝙺","⧠ • 𝙱𝙲𝙶𝚁𝙾𝚄𝙿","⧠ • 𝙱𝙲𝙰𝙻𝙻","⧠ • 𝚂𝙴𝚃𝙿𝙿𝙱𝙾𝚃","⧠ • 𝚂𝙴𝚃𝙴𝚇𝙸𝙵","⧠ • 𝙺𝙴𝙽𝙾𝙽","⧠ • 𝚅𝙴𝚁𝙸𝙵𝚈","⧠ • 𝙱𝙲𝙰𝙻𝙻𝟸","⧠ • 𝙰𝙽𝚃𝙸𝙲𝙰𝙻𝙻","⧠ • 𝚂𝙴𝚃𝚂𝚃𝙰𝚃𝚄𝚂","⧠ • 𝚂𝙴𝚃𝙽𝙰𝙼𝙴𝙱𝙾𝚃","⧠ • 𝚂𝙰𝚅𝙴𝙰𝙻𝙻","⧠ • 𝚂𝚅𝙺𝙾𝙽𝚃𝙰𝙺","⧠ • 𝚂𝙴𝚃𝙴𝚇𝙸𝙵","⧠ • 𝚄𝙽𝙱𝙰𝙽𝙽𝙴𝙳","⧠ • 🌷" ,"⧠ • 🐲","⧠ • 🐉","⧠ • 🌵","⧠ • 🎄","⧠ • 🌲","⧠ • 🌳","⧠ • 🌱","⧠ • 🌿","⧠ • 🍀","⧠ • ☘️","⧠ • 𝚂𝙰𝙽𝚃𝙴𝚃𝙶𝙲","⧠ • 𝙰𝙳𝙳𝙿𝚁𝙴𝙼","⧠ • 𝙳𝙴𝙻𝙿𝚁𝙴𝙼","⧠ • 𝙻𝙸𝚂𝚃𝙿𝚁𝙴𝙼","⧠ • 𝙳𝙴𝙻𝚂𝙴𝚂𝙸","⧠ • 𝙱𝙰𝙽𝙲𝙷𝙰𝚃","⧠ • 𝚄𝙽𝙱𝙰𝙽𝙲𝙷𝙰𝚃","⧠ • 𝙶𝙴𝚃𝙲𝙰𝚂𝙴","⧠ • 𝙰𝙳𝙳𝙲𝙰𝚂𝙴","⧠ • 𝙳𝙴𝙻𝙴𝚃𝙴𝙲𝙰𝚂𝙴","⧠ • 𝙻𝙸𝚂𝚃𝙳𝙱","⧠ • 𝚁𝙴𝚂𝙴𝚃𝙳𝙱","⧠ • 𝙳𝙴𝚃𝙰𝙸𝙻𝚄𝚂𝙴𝚁","⧠ • 𝙳𝙴𝙻𝙴𝚃𝙴𝚄𝚂𝙴𝚁"]
           const allCmd = [...cmdGrup, ...cmdDown, ...cmdSearch, ...cmdRand, ...cmdMaker, ...cmdFun, ...cmdPrimbon, ...cmdConv, ...cmdMain, ...cmdOwner]
	    
        switch(command) {
	    case 'afk': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let user = global.db.data.users[m.sender]
                user.afkTime = + new Date
                user.afkReason = text
                m.reply(`${m.pushName} Telah Afk${text ? ': ' + text : ''}`)
            }
            break           
        case 'ttc': case 'ttt': case 'tictactoe': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            let TicTacToe = require("./lib/tictactoe")
            this.game = this.game ? this.game : {}
            if (Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) throw 'Kamu masih didalam game'
            let room = Object.values(this.game).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
            if (room) {
            m.reply('Partner ditemukan!')
            room.o = m.chat
            room.game.playerO = m.sender
            room.state = 'PLAYING'
            let arr = room.game.render().map(v => {
            return {
            X: '❌',
            O: '⭕',
            1: '1️⃣',
            2: '2️⃣',
            3: '3️⃣',
            4: '4️⃣',
            5: '5️⃣',
            6: '6️⃣',
            7: '7️⃣',
            8: '8️⃣',
            9: '9️⃣',
            }[v]
            })
            let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Menunggu @${room.game.currentTurn.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
            if (room.x !== room.o) await sky.sendText(room.x, str, m, { mentions: parseMention(str) } )
            await sky.sendText(room.o, str, m, { mentions: parseMention(str) } )
            } else {
            room = {
            id: 'tictactoe-' + (+new Date),
            x: m.chat,
            o: '',
            game: new TicTacToe(m.sender, 'o'),
            state: 'WAITING'
            }
            if (text) room.name = text
            m.reply('Menunggu partner' + (text ? ` mengetik command dibawah ini ${prefix}${command} ${text}` : ''))
            this.game[room.id] = room
            }
            }
            break
            case 'delttc': case 'delttt': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            let roomnya = Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))
            if (!roomnya) throw `Kamu sedang tidak berada di room tictactoe !`
            delete this.game[roomnya.id]
            m.reply(`Berhasil delete session room tictactoe !`)
            }
            break
case 'addfunc': {
    if (!isCreator) {
        m.reply('Anda tidak memiliki izin untuk menambahkan case baru.');
        return;
    }
    if (!text) {
        m.reply('Silakan masukkan isi function.');
        return;
    }
    const cases = fs.readFileSync('sky.js').toString();
    const caseBody = text;
    const newCase = `${caseBody}\n`;
    const indexOfBreak = cases.lastIndexOf('//ADDG');
    if (indexOfBreak === -1) {
        m.reply('Terjadi kesalahan');
        return;
    }
    const updatedCases = cases.slice(0, indexOfBreak) + newCase + cases.slice(indexOfBreak);
    fs.writeFileSync('sky.js', updatedCases);
    m.reply('Done Added Function!');
    }
    break
case 'addcase': {
    if (!isCreator) {
        m.reply('Anda tidak memiliki izin untuk menambahkan case baru.');
        return;
    }
    if (!text) {
        m.reply('Silakan masukkan isi case.');
        return;
    }
    const cases = fs.readFileSync('sky.js').toString();
    const caseBody = text;
    const newCase = `${caseBody}\n`;
    const indexOfBreak = cases.lastIndexOf('//ADDF');
    if (indexOfBreak === -1) {
        m.reply('Terjadi kesalahan');
        return;
    }
    const updatedCases = cases.slice(0, indexOfBreak) + newCase + cases.slice(indexOfBreak);
    fs.writeFileSync('sky.js', updatedCases);
    m.reply('Case berhasil ditambahkan!');
    break;
}
case 'deletecase': {
    if (!isCreator) {
        m.reply('Anda tidak memiliki izin untuk menghapus case.');
        return;
    }

    if (!text) {
        m.reply('Silakan masukkan nama case yang ingin dihapus.');
        return;
    }

    const cases = fs.readFileSync('sky.js').toString();
    const caseNameToDelete = text;
    const startIndex = cases.indexOf(`case '${caseNameToDelete}':`);

    if (startIndex === -1) {
        m.reply(`Case '${caseNameToDelete}' tidak ditemukan.`);
        return;
    }

    const endIndex = cases.indexOf('break', startIndex);

    if (endIndex === -1) {
        m.reply('Terjadi kesalahan dalam menemukan titik "break;" dalam kode.');
        return;
    }

    // Menghapus hanya bagian case sampai break saja
    const updatedCases = cases.slice(0, startIndex) + cases.slice(endIndex + 6);
    fs.writeFileSync('sky.js', updatedCases);
    m.reply(`Bagian case '${caseNameToDelete}' berhasil dihapus.`);
    break;
}




case 'sky': {
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
 if (!text) throw 'Apa Sih Lu ?';
 const requestBody = {
 messages: [{ role: 'user', content: q }],
 system: 'kamu adalah adalah Seorang perempuan yang sangat toxic cuek dan pemarah kamu sangat membenci pertanyaan dan kamu WAJIB membalas semua pesan dengan nada yang sangat marah kamu wajib menggunakan emote  keyboard yang sesuai dengan amarah mu, kamu wajib gunakan kata kata kasar dan kotor, nama kamu adalah sky',
 };
 axios.post('https://skizo.tech/api/openai?apikey=alzak', requestBody)
 .then(response => {
 const result = response.data.result;
 m.reply(`${result}`.trim());
 })
 .catch(error => {
 console.error('Error:', error);
 m.reply('Terjadi kesalahan.');
 });
}
break



case 'ganteng': {
m.reply('apa')
}
break


case 'hai': case 'hii': case 'hi': {
 var locationData = {
 degreesLatitude: '51.509865',
 degreesLongitude: '-0.118092',
 address: `halo ka ${pushname}`
 };

 sky.sendMessage(m.chat, { location: locationData },{quoted: fkontak});
}
break

case 'listafk': {
 const userListAFK = [];

 for (const user in db.data.users) {
 if (db.data.users[user].afkTime !== -1) {
 userListAFK.push({
 user,
 afkTime: db.data.users[user].afkTime,
 afkReason: db.data.users[user].afkReason,
 });
 }
 }

 if (userListAFK.length === 0) {
 m.reply('Tidak ada pengguna yang sedang AFK.');
 } else {
 let response = 'Daftar Pengguna AFK:\n';
 for (const userAFK of userListAFK) {
 response += `User: ${userAFK.user}\nWaktu AFK: ${userAFK.afkTime} detik\nAlasan: ${userAFK.afkReason}\n\n`;
 }
 m.reply(response);
 }
}
 break;
case 'resetafk': {
 for (const user in db.data.users) {
 db.data.users[user].afkTime = -1;
 db.data.users[user].afkReason = '';
 }
 m.reply('Status AFK semua pengguna telah dihapus.');
}
 break;

case 'listnime':{
 const url = 'https://raw.githubusercontent.com/BotSIky/vercel/main/iky.js';
 try {
 const fetch = await axios.get(url, {
 headers: {
 "Access-Control-Allow-Origin": "*",
 "Referer": url,
 "Referrer-Policy": "strict-origin-when-cross-origin",
 "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
 }
 });
 const size = fetch.headers['content-length'] ? formatSize(fetch.headers['content-length']) : '1 KB';
 const chSize = sizeLimit(size, '200'); 
 if (chSize.oversize) return sky.reply(m.chat, ` 🚩 File size (${size}) exceeds the maximum limit, we can't download the file.`, m);
 if (/json/i.test(fetch.headers['content-type'])) {
 return m.reply(jsonFormat(fetch.data));
 } else if (/text/i.test(fetch.headers['content-type'])) {
 return m.reply(fetch.data);
 } else {
 sky.sendFile(m.chat, Buffer.from(fetch.data), 'file.txt', m);
 }
 } catch (e) {
 console.log(e);
 return sky.reply(m.chat, e.message, m);
 }
}
break
case 'patrick': {
 m.reply(mess.wait); // Balas dengan pesan penantian
 let { pinterest } = require('./lib/scraper');
 let anu = await pinterest(`${command}`);
 let result = anu[Math.floor(Math.random() * anu.length)];
 sky.sendImageAsSticker(m.chat, result, m, { packname: global.packname, author: global.author })
}
 break;

case 'listcase': {
 const fs = require('fs');
 try {
 const mytext = fs.readFileSync('./sky.js', 'utf8');
 const cases = mytext.match(/case '.*?':/g);
 if (cases) {
 const caseList = cases.map((caseString) => caseString.replace(/case |:/g, ''));
 const listMessage = `Daftar Case:\n${caseList.join('\n')}`;
 m.reply(listMessage);
 } else {
 m.reply('Tidak ada case yang ditemukan dalam file sky.js.');
 }
 } catch (error) {
 m.reply('Terjadi kesalahan saat mencoba membaca file sky.js.');
}
}
 break
case 'up':{
sky.relayMessage(m.chat, {
	
scheduledCallCreationMessage: {
		callType: "VIDEO",		
		scheduledTimestampMs: 12000,
		title: haha,		
		inviteCode: 'wa.me/6283870640443',
		}
	}, {})
	}
	break
case 'ailogic': {
		if (!text) throw `ailogic pesan|logic`
text1 = text.split(' | ')[0] ? text.split(' | ')[0] : '-'
text2 = text.split(' | ')[1] ? text.split(' | ')[1] : '-'
 try {
 const { data } = await axios.get(`https://aemt.me/prompt/gpt?prompt=${text2}&text=${text1}`);
 m.reply(`${data.result}`.trim());
 } catch (error) {
 m.reply('Maaf, terjadi kesalahan saat memproses permintaan.');
 console.error(error);
 }
 }
 break
case 'megawati': case 'jokowi':  case 'prabowo': case 'neymar': case 'ronaldo': case 'messi': case 'elonmusk': case 'tni': case 'kejam': case 'dukun': case 'maling': case 'pembunuh': case 'lucifer': case 'hacker': case 'biksu': case 'polisi': case 'dokter': case 'pilot': case 'hrd': case 'luffy': case 'naruto': case 'ustad': case 'pendeta': case 'dosen': case 'guru': case 'hakim': case 'spongebob': case 'sejarah': {
 if (!text) throw `Hello ${pushname}`
 const { data } = await axios.get(`https://aemt.me/ai/c-ai?prompt=${command}&text=${q}`);
 m.reply(`${data.result}`.trim());
}
break
case 'ky': {
 if (!text) throw `Hello ${pushname}`
 const { data } = await axios.get(`https://aemt.me/ai/c-ai?prompt=lolers&text=${q}`);
 m.reply(`${data.result}`.trim());
}
break
case'kyy': {
 if (!text) throw `Hello ${pushname}`
 const { data } = await axios.get(`https://aemt.me/ai/c-ai?prompt=kontol&text=${q}`);
 m.reply(`${data.result}`.trim());
}
break
case 'sfind': {
 if (!isPrem) return replyprem(mess.premium)
 const [query, count] = text.split(' | ');

 if (!query || !count || isNaN(count)) {
 return m.reply(`Contoh: ${prefix + command} patrick | 7`);
 }
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
 db.data.users[m.sender].limit -= 20
 m.reply(mess.wait);

 let { pinterest } = require('./lib/scraper');
 anu = await pinterest(query);

 const numImagesToSend = parseInt(count);
 const selectedImages = [];

 for (let i = 0; i < numImagesToSend && i < anu.length; i++) {
 selectedImages.push(anu[i]);
 }

 for (const result of selectedImages) {
sky.sendImageAsSticker(m.chat, result, m, { packname: global.packname, author: global.author })
 }
}
break
case 'getpp': {
  try {
var pp = await sky.profilePictureUrl(mentionUser[0], 'image')
} catch {
var pp = 'https://telegra.ph/file/1474e6b4032c00a434192.jpg'
}
sky.sendImageAsSticker(m.chat, pp, m, { packname: global.packname, author: global.author })
  }
  break
case "get": case "fetch":
 if (!q) {
 return m.reply(`get url`);
 }
 if (!/^https?:\/\//.test(q)) {
 return m.reply("URL is Invalid!");
 }
 var requestOptions = {
 method: "GET",
 redirect: "follow",
 };
 if (body.match(/(mp4)/gi)) {
 fetch(`${q}`, requestOptions)
 .then((res) => sky.sendMessage(from, { video: { url: `${q}` }, mimetype: "video/mp4", caption: "ժׁׅ݊ᨵׁׅׅ݊ꪀꫀׁׅܻ݊" }, { quoted: m }))
 .catch((error) => m.reply("Error", error));
 } else if (body.match(/(mp3)/gi)) {
 fetch(`${q}`, requestOptions)
 .then((res) => sky.sendMessage(from, { audio: { url: `${q}` }, mimetype: "audio/mp4", fileName: "Audio" }, { quoted: m }))
 .catch((error) => m.reply("Error", error));
 } else if (body.match(/(png|jpg|jpeg)/gi)) {
 fetch(`${q}`, requestOptions)
 .then((res) => sky.sendMessage(from, { image: { url: `${q}` }, caption: "ժׁׅ݊ᨵׁׅׅ݊ꪀꫀׁׅܻ݊" }, { quoted: m }))
 .catch((error) => m.reply("Error", error));
 } else {
 fetch(`${q}`, requestOptions)
 .then((response) => response.text())
 .then((result) => m.reply(result))
 .catch((error) => m.reply("Error", error));
 }
 break;
case 'ping': case 'botstatus': case 'statusbot': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 const used = process.memoryUsage()
 const cpus = os.cpus().map(cpu => {
 cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
			 return cpu
 })
 const cpu = cpus.reduce((last, cpu, _, { length }) => {
 last.total += cpu.total
 last.speed += cpu.speed / length
 last.times.user += cpu.times.user
 last.times.nice += cpu.times.nice
 last.times.sys += cpu.times.sys
 last.times.idle += cpu.times.idle
 last.times.irq += cpu.times.irq
 return last
 }, {
 speed: 0,
 total: 0,
 times: {
			 user: 0,
			 nice: 0,
			 sys: 0,
			 idle: 0,
			 irq: 0
 }
 })
 let timestamp = speed()
 let latensi = speed() - timestamp
 neww = performance.now()
 oldd = performance.now()
 respon = `
Kecepatan Respon ${latensi.toFixed(4)} _Second_ \n ${oldd - neww} _miliseconds_\n\nRuntime : ${runtime(process.uptime())}

💻 Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

_NodeJS Memory Usaage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}

${cpus[0] ? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
 `.trim()
 m.reply(respon)
 }
 break
case 'madara':
 case 'mikasa':
 case 'miku':
 case 'minato':
 case 'narutos':
 case 'nezuko':
 case 'onepiece':
 case 'pokemon':
 case 'rize':
 case 'sagiri':
 case 'sakura':
 case 'sasuke':
 case 'shina':
 case 'shinka':
 case 'shizuka':
 case 'shota':
 case 'toukachan':
 case 'tsunade':
 case 'yuki': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 m.reply(mess.wait)
 if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
 db.data.users[m.sender].limit -= 1 // -1 limit
 let anu = await fetchJson(`https://raw.githubusercontent.com/Abuzzpoet/Databasee/main/Random%20Anime/${command}.json`);
 let result = anu[Math.floor(Math.random() * anu.length)]; // Declare and initialize 'result' here
 sky.sendMessage(m.chat, { image: { url: result }, caption: mess.done }, { quoted: m });
}
break
case 'loli': {
 m.reply(mess.wait); // Balas dengan pesan penantian
 let { pinterest } = require('./lib/scraper');
 let anu = await pinterest(`anime loli Kawai`);
 let result = anu[Math.floor(Math.random() * anu.length)];
 sky.sendMessage(m.chat, {image: {url:result}, caption: `Here you go!`, fileLength: "999", viewOnce : true},{quoted: m })
 }
 break
case 'aster': {
 if (!text) throw `Hello ${pushname}`
 const { data } = await axios.get(`https://aemt.me/ai/c-ai?prompt=aster&text=${q}`);
 m.reply(`${data.result}`.trim());
}
break
case 'takemitchy': {
 if (!text) throw `Yoooo ${pushname}`
 const { data } = await axios.get(`https://aemt.me/ai/c-ai?prompt=Hanagaki%20Takemitchy&text=${q}`);
 m.reply(`${data.result}`.trim());
}
break
case 'tow': {
const uploadImage = require('./lib/uploadImage')
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }

 let media = await q.download();
 let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);

 let fileSizeLimit = 5 * 1024 * 1024; // 5MB

 if (media.length > fileSizeLimit) {
 m.reply('Ukuran media tidak boleh melebihi 5MB');
 return;
 }

 let link = await (isTele ? uploadImage : uploadImage)(media);
 m.reply(`${link}\n${media.length} Byte(s)`);
 }
 break
case 'smeme': case 'smim': {
const uploadImage = require('./lib/uploadImage')
if (isBan) return m.reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
 if (!text) throw `Reply Media Dengan Text`
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }
 let media = await q.download();
 let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
 let link = await (isTele ? uploadImage : uploadImage)(media);
kaytid = await getBuffer(`https://api.memegen.link/images/custom/-/${text}.png?background=${link}`)
sky.sendImageAsSticker(m.chat, kaytid, m, { packname: global.packname, author: global.author })
 }
break
case 'tts': case 'say': {
try {
if (!text) return m.reply(`Example : ${prefix + command} text`)
m.reply(mess.wait)
let tts = await fetchJson(`https://api.ibeng.tech/api/others/tts?text=${q}&lang=id&apikey=Lp6hPh7wJy`)
sky.sendMessage(from, { audio: { url: tts.data.audio }, mimetype: "audio/mp4", fileName: "Audio" }, { quoted: m })
} catch (err) {
console.log(err)
m.reply('Terjadi Kesalahan')
}
}
break
case 'tourl': {
 m.reply(mess.wait)
		let { UploadFileUgu, uploadFile,webp2mp4File, TelegraPh, uploadFileToGipty } = require('./lib/uploader')
 let media = await sky.downloadAndSaveMediaMessage(qmsg)
 if (/image/.test(mime)) {
 let anu = await TelegraPh(media)
 m.reply(util.format(anu))
 } else if (/webp/.test(mime)) {
 let anu = await TelegraPh(media)
 m.reply(util.format(anu))
 } else if (!/image/.test(mime)) {
 let anu = await TelegraPh(media)
 m.reply(util.format(anu))
 }
 await fs.unlinkSync(media)
 }
 break
case 'pindl': case 'pinterestdl': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
			 if (!text) throw 'Masukkan Query Link!'
			m.reply(mess.wait)			
			axios.get(`https://api.ibeng.tech/api/downloader/pinterest?url=${q}&apikey=Lp6hPh7wJy`).then(({ data }) => {
			sky.sendMessage(m.chat, { video: { url: data.data }, mimetype: 'video/mp4' })
			})			
			}
			break
case'ig': case 'igdl': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
			 if (!text) throw 'Masukkan Query Link!'
			m.reply(mess.wait)
			axios.get(`https://api.ibeng.tech/api/downloader/instagram?url=${q}&apikey=Lp6hPh7wJy`).then(({ data }) => {
				sky.sendMessage(m.chat, { video: { url: data.data[0].url }, mimetype: 'video/mp4' })
			})			
			}
			break
case 'readviewonce':
case 'rvo': {
  const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
  if (!m.quoted || !m.quoted.message) {
    m.reply('Reply pesan media yang memiliki view-once untuk digunakan.');
    return;
  }
  let type = Object.keys(m.quoted.message)[0];
  let q = m.quoted.message[type];
  let media = await downloadContentFromMessage(q, type === 'imageMessage' ? 'image' : 'video');
  let buffer = Buffer.from([]);
  for await (const chunk of media) {
    buffer = Buffer.concat([buffer, chunk]);
  }
  if (/video/.test(type)) {
    // Mengirim video
    await sky.sendVideo(m.chat, buffer, q.caption || '', m)
  } else if (/image/.test(type)) {
    // Mengirim gambar
    await sky.sendImage(m.chat, buffer, q.caption || '', m)
  } else {
    m.reply('Tipe media tidak didukung.');
  }
  }
  break
case 'aicreate2': {
if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} kids,cute`)
		 m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.ibeng.tech/api/ai/text2img?text=${q}&apikey=Lp6hPh7wJy` }, caption: `${text}`})
 }
			break
case 'aicreate3': {
if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} kids,cute`)
		 m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://aemt.me/ai/text2img?text=${q}` }, caption: `${text}`})
 }
			break
case 'tt': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
 db.data.users[m.sender].limit -= 10 // -1 limit
			 if (!text) throw 'Masukkan Query Link!'
			m.reply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/tiktok?apikey=GataDios&url=${args[0]}`).then(({ data }) => {			
				sky.sendMessage(m.chat, { video: { url: data.result.link }, caption: `Mau Video Nya? Ketik Rvo Reply Pesan Ini`, fileLength: "99999", viewOnce : true},{quoted: m })
			})			
			}
			break
case 'aidiff': {
 if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} girl sexy,bluehair,black eye`)
		 m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.azz.biz.id/api/animediffusion?q=${text}&key=mangea` }, caption: `Style 1`})
 sky.sendMessage(m.chat, { image: { url: `https://api.azz.biz.id/api/animediffusion?q=${text}&key=mangea` }, caption: `Style 2`})
sky.sendMessage(m.chat, { image: { url: `https://api.azz.biz.id/api/animediffusion?q=${text}&key=mangea` }, caption: `Style 3`}) 
 }
			break
case 'toanime3': {
 if (!isPrem) return replyprem(mess.premium)
 if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
 if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
 if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
 m.reply(mess.wait)
	const media = await sky.downloadAndSaveMediaMessage(quoted)
	const { TelegraPh } = require('./lib/uploader')
	const anu = await TelegraPh(media)
	let { data } = await axios.get(`https://aemt.me/toanime?url=${anu}`)
	if (data.message) return m.reply(JSON.stringify(data))
	await sky.sendMessage(m.chat, { image: { url: data.url.img_crop_single }, caption: mess.done }, { quoted: m })
}
break
case 'midjourney': {
 if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} yellow car with small boy`)
		 m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://vihangayt.me/tools/midjourney?q=${q}` }, caption: `Result 1`})
 sky.sendMessage(m.chat, { image: { url: `https://vihangayt.me/tools/midjourney?q=${q}` }, caption: `Result 2`})
 }
			break
case 'prompt2': {
const uploadImage = require('./lib/uploadImage')
if (isBan) return m.reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }
const keys = ["free", "zex", "global"];
const xx = keys[Math.floor(Math.random() * keys.length)];
 let media = await q.download();
 let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
 let link = await (isTele ? uploadImage : uploadImage)(media);
 const { data } = await axios.get(`https://api.miftahganzz.my.id/api/ai/img2text?url=${link}&apikey=${xx}`);
 m.reply(`${data.data[0].generated_text}`.trim());
 }
break
case 'jc': {
if (!isCreator) throw mess.owner
 const args = q.split(' | ');
 if (args.length === 2) {
 const titleText = args[0];
 const totalTitles = parseInt(args[1]);

 if (!isNaN(totalTitles) && totalTitles > 0) {
 let title = `${titleText}\n`.repeat(totalTitles);
 const scheduledTimestampMs = Date.now() + 1000; // Jadwal panggilan 1 detik ke depan

 sky.relayMessage(m.chat, {
 scheduledCallCreationMessage: {
 callType: "VOICE",
 scheduledTimestampMs: scheduledTimestampMs,
 title: title,
 inviteCode: 'http://wa.me/6283870640443',
 }
 }, {});
 } else {
 m.reply('Tentukan jumlah total yang valid (angka positif).');
 }
 } else {
 m.reply('Format yang benar: jc [judul] | [jumlah_total]');
 }
}
 break
case'prompt': {
const uploadImage = require('./lib/uploadImage')
if (isBan) return m.reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }
const keys = ["global", "mangea", "pelanpelanpaksupir"];
const xx = keys[Math.floor(Math.random() * keys.length)];
 let media = await q.download();
 let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
 let link = await (isTele ? uploadImage : uploadImage)(media);
 const { data } = await axios.get(`https://api.azz.biz.id/api/image2promt?url=${link}&key=${xx}`);
 m.reply(`${data.text[0].generated_text}`.trim());
 }
break
case 'gptpic': {
 const query = args.join(' '); // Mengambil query dari pesan pengguna
 const playod = { 
 captionInput: query, 
 captionModel: 'default',
 };

 try {
 const response = await axios.post('https://chat-gpt.pictures/api/generateImage', playod, {
 headers: {
 Accept: '*/*',
 'Content-Type': 'application/json',
 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
 }
 });

 const data = response.data;
 if (data.data && data.data[0] && data.data[0].imgs) {
 const imageUrl = data.data[0].imgs; // Mengambil URL gambar dari respons

 // Mengirim gambar ke pengguna
 sky.sendMessage(m.chat, { image: { url: imageUrl } });
 } else {
 m.reply('Tidak dapat menghasilkan gambar sesuai permintaan.');
 }
 } catch (error) {
 console.error(error);
 m.reply('Terjadi kesalahan saat mencoba menghasilkan gambar.');
 }
}
 break
case 'jc2': {
 if (!isCreator) throw mess.owner;
 const args = q.split(' | ');
 
 if (args.length === 3) { // Mengganti jumlah argumen menjadi 3
 const titleText = args[0];
 const totalTitles = parseInt(args[1]);
 const scheduledTime = parseInt(args[2]); // Menambah argumen waktu jadwal

 if (!isNaN(totalTitles) && totalTitles > 0 && !isNaN(scheduledTime) && scheduledTime > 0) {
 const title = `${titleText}\n`.repeat(totalTitles);
 const scheduledTimestampMs = Date.now() + scheduledTime * 1000; // Menghitung waktu jadwal dalam milidetik
 
 sky.relayMessage(m.chat, {
 scheduledCallCreationMessage: {
 callType: "VOICE",
 scheduledTimestampMs: scheduledTimestampMs,
 title: title,
 inviteCode: 'http://wa.me/6283870640443',
 },
 }, { 
 sendNotification: true
 });

 m.reply(`Panggilan suara akan dimulai dalam ${scheduledTime} detik.`);
 } else {
 m.reply('Format yang benar: jc [judul] | [jumlah_total] | [waktu_jadwal (dalam detik)]');
 }
 } else {
 m.reply('Format yang benar: jc [judul] | [jumlah_total] | [waktu_jadwal (dalam detik)]');
 }
}
 break
case 'jcoff':{
if (!isCreator) return m.reply(mess.owner)
 if (!isBotAdmins) throw mess.botAdmin
m.reply('call will be disconnected in 30 minutes')
 }
 break
case 'smooth2': {
 try {
 let set
 if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"'
 if (/audio/.test(mime)) {
 m.reply(mess.wait)
 let media = await sky.downloadAndSaveMediaMessage(qmsg)
 let ran = getRandom('.mp3')
 exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
 fs.unlinkSync(media)
 if (err) return m.reply(err)
 let buff = fs.readFileSync(ran)
 sky.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted : m })
 fs.unlinkSync(ran)
 })
 } else m.reply(`Balas audio yang ingin diubah dengan caption *${prefix + command}*`)
 } catch (e) {
 m.reply(e)
 }
 }
 break
case 'listchar': {
m.reply(haha)
}
break
case 'tiktok': case 'tiktoknowm': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
 db.data.users[m.sender].limit -= 10 // -1 limit
			 if (!text) throw 'Masukkan Query Link!'
			m.reply(mess.wait)
			axios.get(`https://aemt.me/download/tikdl?url=${q}`).then(({ data }) => {
				sky.sendMessage(m.chat, { video: { url: data.result.url.nowm }, mimetype: 'video/mp4' })
			})			
			}
			break
			
case 'jaa': {
 var hh = {
 degreesLatitude: -2.9174933333333333,
 degreesLongitude: 104.78374166666666,
 caption: 'Bsisnsjnsnsnsnnsnsnksndknskankaksidmndnkdndkambsbamdjsknamammamam smncncnsvmvzmgsmgsmgsmgsnsg',
 };
 sky.sendMessage(m.chat, { location: hh },{quoted: fkontak});
 }
 break
 
case 'res': {
 await m.reply('```R E S T A R T . . .```');
 process.send('reset');
 }
break
case 'photoleap': {
 if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} boy`)
		 m.reply(mess.wait)
 let { data } = await axios.get(`https://vihangayt.me/tools/photoleap?q=${q}`)
	if (data.message) return m.reply(JSON.stringify(data))
	await sky.sendMessage(m.chat, { image: { url: data.data }, caption: data.data }, { quoted: m })
 }
			break
case 'aibing2': {
 if (!isPrem) return replyprem(mess.premium);
 if (args1.length == 0) return m.reply(`Example: ${prefix + command} boy`);
 m.reply(mess.wait);

 try {
 let { data } = await axios.get(`https://api.ibeng.tech/api/others/bling2?q=${q}&apikey=Lp6hPh7wJy`);

 if (data.message) {
 return m.reply(JSON.stringify(data));
 }

 await sky.sendMessage(m.chat, { image: { url: data.data[0] }, caption: data.turl }, { quoted: m });
 } catch (error) {
 console.error(error);
 m.reply("Maaf, fitur ini sedang mengalami kesalahan. Silakan coba lagi nanti.");
 }
}
 break

case 'lirik':
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} Melukis Senja`)
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.akuari.my.id/search/lirik?query=${q}`)
			m.reply(`judul : ${data.result[0].judul}\n\nLirik :\n${data.result[0].lirik}`)
			break
case 'ytmp4': case 'ytvideo': {
const xeonvidoh = require('./lib/ytdl2')
if (args.length < 1 || !isUrl(text) || !xeonvidoh.isYTUrl(text)) m.reply(`Where is the link??\n\nExample : ${prefix + command} https://youtube.com/watch?v=PtFMh6Tccag%27 128kbps`)
const vid=await xeonvidoh.mp4(text)
const ytc=`
*Tittle:* ${vid.title}
*Date:* ${vid.date}
*Duration:* ${vid.duration}
*Quality:* ${vid.quality}`
await sky.sendMessage(m.chat,{
 video: {url:vid.videoUrl},
 caption: ytc
},{quoted:m})
}
break
case 'perplexity': {
 if (!text) throw `Hello ${pushname}`
 const { data } = await axios.get(`https://aemt.me/ai/c-ai?prompt=Perplexity%20AI&text=${q}`);
 m.reply(`${data.result}`.trim());
}
break
case 'restart': {
if (!isCreator) throw mess.owner
m.reply(`utiwii...`)
await sleep(3000)
process.exit()
}
break


case 'assalamualaikum': {
try {
let tts = await fetchJson(`https://api.ibeng.tech/api/others/tts?text=wallaikumsallam%20${pushname}%20semoga%20harimu%20menyenangkan&lang=id&apikey=Lp6hPh7wJy`)
sky.sendMessage(from, { audio: { url: tts.data.audio }, mimetype: "audio/mp4", fileName: "Audio" }, { quoted: m })
} catch (err) {
console.log(err)
m.reply('Terjadi Kesalahan')
}
}
break
case 'realowner': {
const repf = await sky.sendMessage(from, { 
contacts: { 
displayName: `${list.length} Contact`, 
contacts: list }, mentions: [sender] }, { quoted: m })
sky.sendMessage(from, { text : `Hi @${sender.split("@")[0]}, Ni No Owner Ril`, mentions: [sender]}, { quoted: m })
}
break
case 'pinmessage': {
 // Cek apakah pengguna memiliki izin untuk menggunakan perintah ini di grup
 if (!m.isGroup || !m.isAdmin) {
 m.reply('Perintah ini hanya dapat digunakan oleh admin di grup.');
 return;
 }

 // Ambil pesan yang ingin dipin dari argumen
 const pinnedMessage = args.join(' ');

 // Pastikan ada pesan yang diinput
 if (!pinnedMessage) {
 m.reply('Silakan masukkan pesan yang ingin Anda pin.');
 return;
 }

 // Pin pesan yang dimasukkan oleh pengguna
 m.reply(pinnedMessage).then((message) => {
 m.pinMessage(message.chat.id, message.id);
 m.reply('Pesan telah berhasil dipin di grup.');
 });
}
 break
case 'aigenerator': {
if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`"mess": "Insertp model: [\"v1\", \"v2\", \"v2-beta\", \"v3\", \"lexica\", \"prodia\"]!"`)
ky = text.split(' | ')[0] ? text.split(' | ')[0] : '-'
kyy = text.split(' | ')[1] ? text.split(' | ')[1] : '-'
		 m.reply(mess.wait)
 try {
 let { data } = await axios.get(`https://api.yanzbotz.my.id/api/text2img/hercimg?model=${ky}&prompt=${kyy}`);
 if (data.message) {
 return m.reply(JSON.stringify(data));
 }
 await sky.sendMessage(m.chat, { image: { url: data.result.url }, caption: data.result.model }, { quoted: m });
 } catch (error) {
 console.error(error);
 m.reply("Maaf, fitur ini sedang mengalami kesalahan. Silakan coba lagi nanti.");
 }
}
			break
case 'addvn': {
 let delb = await sky.downloadAndSaveMediaMessage(quoted)
 await fsx.copy(delb, `./src/ai.mp4`)
 fs.unlinkSync(delb)
 m.reply(`Sukses Menambahkan Audio\nCek dengan cara ${prefix}listvn`)
 }
 break
case 'setvidai': {
 let delb = await sky.downloadAndSaveMediaMessage(quoted)
 await fsx.copy(delb, `./src/ai.mp4`)
 fs.unlinkSync(delb)
 m.reply(`Sukses`)
 }
 break
case "ytaudio": case "ytmp3": {
const xeonaudp3 = require('./lib/ytdl2')
if (args.length < 1 || !isUrl(text) || !xeonaudp3.isYTUrl(text)) return m.reply(`Where's the yt link?\nExample: ${prefix + command} https://youtube.com/shorts/YQf-vMjDuKY?feature=share`)
const audio=await xeonaudp3.mp3(text)
await sky.sendMessage(m.chat,{
 audio: fs.readFileSync(audio.path),
 mimetype: 'audio/mp4',
 contextInfo:{
 externalAdReply:{
 title:audio.meta.title,
 body: `${pushname}`,
 thumbnail: await fetchBuffer(audio.meta.image),
 mediaType:2,
 mediaUrl:text,
 }

 },
},{quoted:m})
await fs.unlinkSync(audio.path)
}
break
case 'ai': case 'openai': {
 let textToAnswer = text;

 if (m.quoted && m.quoted.text) {
 textToAnswer = m.quoted.text;
 }

 if (!textToAnswer) {
 m.reply('Balas pesan seseorang dengan pertanyaan atau ketik pertanyaan langsung.');
 return;
 }
		 try {
	 let sky = `Namamu adalah Avosky-MD, kamu dibuat dan dikembangkan oleh Avosky-MD. Tugasmu adalah menjawab pertanyaan apapun dengan imut dan lucu menggunakan kaomoji. Seseorang yang sedang mengobrol denganmu saat ini namanya adalah`	 
 const { data } = await axios.get(`https://aemt.me/prompt/gpt?prompt=${sky}&text=${textToAnswer}`);
 m.reply(`${data.result}`.trim());
 } catch (error) {
 m.reply('Maaf, terjadi kesalahan saat memproses permintaan.');
 console.error(error);
 }
}
break
case 'kenon' :{
if (!isCreator) throw 'ngapain?'
if (!args[0]) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628xxxxxxxx`)
prrkek = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let ceknya = await sky.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
let axioss = require("axios") 
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDONESIA")
form.append("phone_number", prrkek)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Hello, please deactivate this number, because I have lost my cellphone and someone is using my number, please deactivate my number")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
 url,
 method: "POST",
 data: form,
 headers: {
 cookie
}
})
sky.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
 case 'cekbaik': {
 if (!m.isGroup) throw mess.group;

 const memberCount = participants.length;
 if (memberCount === 0) throw 'Tidak ada anggota grup.';

 // Cek apakah ada mention user
 const mentionedMembers = m.mentionedJid;
 let targetMember = null;

 if (mentionedMembers.length > 0) {
 // Jika ada yang di-mention, pilih secara acak satu dari yang di-mention
 const randomIndex = Math.floor(Math.random() * mentionedMembers.length);
 targetMember = participants.find(member => member.id === mentionedMembers[randomIndex]);
 } else {
 // Jika tidak ada yang di-mention, pilih secara acak dari semua anggota
 const randomIndex = Math.floor(Math.random() * memberCount);
 targetMember = participants[randomIndex];
 }

 if (!targetMember) throw 'Tidak dapat menemukan anggota yang di-mention.';

 const kebaikanPercentage = Math.floor(Math.random() * 100) + 1;

 const responseText = `🌟 *Cek Baik Challenge* 🌟\n\n`;
 const memberInfo = `Nama: **${targetMember.id.split('@')[0]}**\nNomor: *${targetMember.id.replace('@s.whatsapp.net', '')}*\n`;
 const resultInfo = `Kebaikan: **${kebaikanPercentage}%**\n\n`;

 // Menambahkan waktu sekarang
 const currentTime = new Date();
 const formattedTime = `${currentTime.toLocaleDateString()} ${currentTime.toLocaleTimeString()}`;
 const timeInfo = `⌚ *Waktu Sekarang*: ${formattedTime}\n`;

 // Deteksi member berdasarkan awalan nomor
 let indonesiaMembers = 0;
 let malaysiaMembers = 0;

 // List anggota dari negara luar
 const foreignMembersList = [];

 for (const member of participants) {
 const countryCode = member.id.replace(/[^0-9]/g, '').substring(0, 2);
 if (countryCode === '62') {
 indonesiaMembers++;
 } else if (countryCode === '60') {
 malaysiaMembers++;
 } else {
 foreignMembersList.push(`- ${member.id.split('@')[0]}`);
 }
 }

 const countryInfo = `🌍 *Deteksi Anggota Grup*:\n🇮🇩 Indonesia: ${indonesiaMembers} member\n🇲🇾 Malaysia: ${malaysiaMembers} member\n`;

 // Menambahkan list anggota dari negara luar
 let foreignMembersText = '';
 if (foreignMembersList.length > 0) {
 foreignMembersText = `\nList Anggota Luar:\n${foreignMembersList.join('\n')}`;
 }

 // Menambahkan Top Kebaikan Grup
 const topKebaikanMembers = participants
 .slice(0, Math.min(3, participants.length)) // Ambil 3 anggota teratas
 .map(member => `➤ ${member.id.split('@')[0]}: ${Math.floor(Math.random() * 100) + 1}%`);

 const topKebaikanInfo = `\n\n🏆 *Top Kebaikan Grup*:\n${topKebaikanMembers.join('\n')}`;

 // Menambahkan Quotes Motivasi
 const motivationalQuote = `\n\n🌈 *Quotes Motivasi*:\n"Setiap hari adalah kesempatan untuk menjadi lebih baik."`;

 const additionalInfo = `\n\n👤 *Total Anggota Grup*: ${memberCount}`;

 const fullResponse = `${responseText}${memberInfo}${resultInfo}${timeInfo}${countryInfo}${foreignMembersText}${topKebaikanInfo}${motivationalQuote}${additionalInfo}`;

 sky.relayMessage(m.chat, {
 requestPaymentMessage: {
 currencyCodeIso4217: 'INR',
 amount1000: 1234567,
 requestFrom: m.sender,
 noteMessage: {
 extendedTextMessage: {
 text: `${fullResponse}`,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true
 }}}}}}, {}) 
}
break
case 'ttsai': {
 arip = text.split(' | ')[0] ? text.split(' | ')[0] : '-';
 arip2 = text.split(' | ')[1] ? text.split(' | ')[1] : '-';

 try {
 var a = (await axios.get("https://skizo.tech/api/tts-ai?text=" + arip.slice(0, 300) + `&voice=${arip2}&apikey=skuy33`)).data;
 const kiki = Buffer.from(a.base64, "base64");
 sky.sendMessage(m.chat, { audio: kiki, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
 } catch (error) {
 console.error(error);
 m.reply('Terjadi kesalahan. Silakan coba lagi.');
 }
}
break
case 'sunda': {
 if (!text) throw `Hello ${pushname}`
 const { data } = await axios.get(`https://aemt.me/ai/c-ai?prompt=Orang%20Sunda&text=${q}`);
 m.reply(`${data.result}`.trim());
}
break
case 'try': {
sky.sendMessage(m.chat, { forward: m.quoted.fakeObj })
 }
 break


case 'menu2': { 
 let ppai = fs.readFileSync(`./src/menu.mp4`)
 axios.get(`https://aemt.me/openai?text=${text}`).then(({ data }) => {
 let caption = (`
╭──────༺♡༻──────╮
> і ᥒ 𝖿 ᥆ ᑲ ᥆ 𝗍 [<>]
╰──────༺♡༻──────╯ 
〘 ! 〙𝙼𝙾𝙳𝙴 : ${sky.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
〘 ! 〙𝚁𝚄𝙽𝚃𝙸𝙼𝙴 : ${runtime(process.uptime())}
〘 ! 〙𝚃𝙾𝚃𝙰𝙻 𝚄𝚂𝙴𝚁 : ${Object.keys(global.db.data.users).length}
〘 ! 〙𝚃𝙾𝚃𝙰𝙻 𝙿𝚁𝙴𝙼 : ${prem.length}
〘 ! 〙𝚃𝙾𝚃𝙰𝙻 𝙵𝙸𝚃𝚄𝚁 ${totalFitur()}
〘 ! 〙𝙿𝙻𝙰𝚃𝙵𝙾𝚁𝙼 : ${os.platform()} 

╭──────༺♡༻──────╮
> і ᥒ 𝖿 ᥆ ᥙ s ᥱ r [<>]
╰──────༺♡༻──────╯
〘 ! 〙𝙽𝙰𝙼𝙴 : ${pushname}
〘 ! 〙𝙽𝙾𝙼𝙾𝚁 : ${m.sender.split('@')[0]}
〘 ! 〙𝙾𝚆𝙽𝙴𝚁 𝙽𝚄𝙼𝙱𝙴𝚁 : ${m.sender.split('@')[0]}
〘 ! 〙𝙾𝚆𝙽𝙴𝚁 𝙽𝙰𝙼𝙴 : ${isCreator ? "𝙾𝚆𝙽𝙴𝚁 𝙾𝙽𝙻𝚈" : "User ⭐"}
〘 ! 〙𝙱𝙾𝚃 𝙽𝙰𝙼𝙴 : ${botname}
〘 ! 〙𝚁𝚄𝙽𝚃𝙸𝙼𝙴 : ${runtime(process.uptime())}
〘 ! 〙𝚂𝚃𝙰𝚃𝚄𝚂 : ${isCreator ? "𝙾𝚆𝙽𝙴𝚁 𝙾𝙽𝙻𝚈" : "User ⭐"}
〘 ! 〙𝚄𝚂𝙴𝚁 : ${isPremium ? '𝙿𝚁𝙴𝙼 𝙾𝙽𝙻𝚈' : 'Gratisan ⭐'}
〘 ! 〙𝙻𝙸𝙼𝙸𝚃 : ${isCreator ? '𝚄𝙽𝙻𝙸𝙼𝙸𝚃𝙴𝙳 𝙾𝙽𝙻𝚈' : `${db.data.users[m.sender].limit}⭐`}
〘 ! 〙𝙻𝙸𝙽𝙺𝙶𝙲 : https://tinyurl.com/28sl9dqh
〘 ! 〙Ngiḷạṇg.cm
〘 ! 〙http://avosky.wuaze.com

 
╔┈「 𝙎𝙄𝙈𝙋𝙇𝙀-𝙈𝙀𝙉𝙐 」
╎❆ 𝚂𝙴𝙰𝚁𝙲𝙷𝙼𝙴𝙽𝚄 / M1
╎❆ 𝙳𝙾𝚆𝙽𝙻𝙾𝙰𝙳𝙼𝙴𝙽𝚄 / M2
╎❆ 𝙶𝚁𝙾𝚄𝙿𝙼𝙴𝙽𝚄 / M3
╎❆ 𝚁𝙰𝙽𝙳𝙾𝙼𝙼𝙴𝙽𝚄 / M4
╎❆ 𝙼𝙰𝙺𝙴𝚁𝙼𝙴𝙽𝚄 / M5
╎❆ 𝙵𝚄𝙽𝙼𝙴𝙽𝚄 / M6
╎❆ 𝙰𝙽𝙸𝙼𝙴𝙼𝙴𝙽𝚄 / M7
╎❆ 𝙿𝚁𝙸𝙼𝙱𝙾𝙽𝙼𝙴𝙽𝚄 / M8
╎❆ 𝙲𝙾𝙽𝚅𝙴𝚁𝚃𝙼𝙴𝙽𝚄 / M9
╎❆ 𝙼𝙰𝙸𝙽𝙼𝙴𝙽𝚄 / M10
╎❆ 𝙾𝚆𝙽𝙴𝚁𝙼𝙴𝙽𝚄 / M11
╎❆ 𝙽𝚂𝙵𝚆𝙼𝙴𝙽𝚄 / M12
╎❆ 𝙰𝙸𝙼𝙴𝙽𝚄 / M13
╚┈┈┈┈┈┈┈┈┈┈┈❖*`)

 sky.sendMessage(m.chat, { 
 video: ppai, 
 gifPlayback: true, caption }, 
 { quoted: fkontak });
 });
 }
 break
case 'gbard': {
		if (!text) throw `Yes U Have Question?`			
			var { data } = await axios.get(`https://aemt.me/bard?text=${q}`)
			m.reply(`${data.result}`.trim())
			}
			break
case 'save': {
	if (!text) throw `save apa?`
 let delb = await sky.downloadAndSaveMediaMessage(quoted)
 await fsx.copy(delb, `./${q}`)
 fs.unlinkSync(delb)
 m.reply(`Sukses`)
 }
 break
case 'meme': {
 m.reply(mess.wait); // Balas dengan pesan penantian
 let { pinterest } = require('./lib/scraper');
 let anu = await pinterest(`meme indo`);
 let result = anu[Math.floor(Math.random() * anu.length)];
 sky.sendMessage(m.chat, { image: { url: result }, caption: mess.done }, { quoted: m });
 }
 break
case 'menu':{
let me = m.sender
let timestampe = speed();
let latensie = speed() - timestampe
 sky.relayMessage(m.chat, {
 requestPaymentMessage: {
 currencyCodeIso4217: 'USD',
 amount1000: 10000,
 requestFrom: m.sender,
 noteMessage: {
 extendedTextMessage: {
 text: `
╭──────༺♡༻──────╮
> і ᥒ 𝖿 ᥆ ᑲ ᥆ 𝗍 [<>]
╰──────༺♡༻──────╯ 
〘 ! 〙𝙼𝙾𝙳𝙴 : ${sky.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
〘 ! 〙𝚁𝚄𝙽𝚃𝙸𝙼𝙴 : ${runtime(process.uptime())}
〘 ! 〙𝚃𝙾𝚃𝙰𝙻 𝚄𝚂𝙴𝚁 : ${Object.keys(global.db.data.users).length}
〘 ! 〙𝚃𝙾𝚃𝙰𝙻 𝙿𝚁𝙴𝙼 : ${prem.length}
〘 ! 〙𝚃𝙾𝚃𝙰𝙻 𝙵𝙸𝚃𝚄𝚁 ${totalFitur()}
〘 ! 〙𝙿𝙻𝙰𝚃𝙵𝙾𝚁𝙼 : ${os.platform()} 

╭──────༺♡༻──────╮
> і ᥒ 𝖿 ᥆ ᥙ s ᥱ r [<>]
╰──────༺♡༻──────╯
〘 ! 〙𝙽𝙰𝙼𝙴 : ${pushname}
〘 ! 〙𝙽𝙾𝙼𝙾𝚁 : ${m.sender.split('@')[0]}
〘 ! 〙𝙾𝚆𝙽𝙴𝚁 𝙽𝚄𝙼𝙱𝙴𝚁 : ${m.sender.split('@')[0]}
〘 ! 〙𝙾𝚆𝙽𝙴𝚁 𝙽𝙰𝙼𝙴 : ${isCreator ? "𝙾𝚆𝙽𝙴𝚁 𝙾𝙽𝙻𝚈" : "User ⭐"}
〘 ! 〙𝙱𝙾𝚃 𝙽𝙰𝙼𝙴 : ${botname}
〘 ! 〙𝚁𝚄𝙽𝚃𝙸𝙼𝙴 : ${runtime(process.uptime())}
〘 ! 〙𝚂𝚃𝙰𝚃𝚄𝚂 : ${isCreator ? "𝙾𝚆𝙽𝙴𝚁 𝙾𝙽𝙻𝚈" : "User ⭐"}
〘 ! 〙𝚄𝚂𝙴𝚁 : ${isPremium ? '𝙿𝚁𝙴𝙼 𝙾𝙽𝙻𝚈' : 'Gratisan ⭐'}
〘 ! 〙𝙻𝙸𝙼𝙸𝚃 : ${isCreator ? '𝚄𝙽𝙻𝙸𝙼𝙸𝚃𝙴𝙳 𝙾𝙽𝙻𝚈' : `${db.data.users[m.sender].limit}⭐`}
〘 ! 〙𝙻𝙸𝙽𝙺𝙶𝙲 : https://tinyurl.com/28sl9dqh
〘 ! 〙Ngiḷạṇg.cm
〘 ! 〙http://avosky.wuaze.com

 ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
╔┈「 𝙎𝙄𝙈𝙋𝙇𝙀-𝙈𝙀𝙉𝙐 」
╎❆ 𝚂𝙴𝙰𝚁𝙲𝙷𝙼𝙴𝙽𝚄 / M1
╎❆ 𝙳𝙾𝚆𝙽𝙻𝙾𝙰𝙳𝙼𝙴𝙽𝚄 / M2
╎❆ 𝙶𝚁𝙾𝚄𝙿𝙼𝙴𝙽𝚄 / M3
╎❆ 𝚁𝙰𝙽𝙳𝙾𝙼𝙼𝙴𝙽𝚄 / M4
╎❆ 𝙼𝙰𝙺𝙴𝚁𝙼𝙴𝙽𝚄 / M5
╎❆ 𝙵𝚄𝙽𝙼𝙴𝙽𝚄 / M6
╎❆ 𝙰𝙽𝙸𝙼𝙴𝙼𝙴𝙽𝚄 / M7
╎❆ 𝙿𝚁𝙸𝙼𝙱𝙾𝙽𝙼𝙴𝙽𝚄 / M8
╎❆ 𝙲𝙾𝙽𝚅𝙴𝚁𝚃𝙼𝙴𝙽𝚄 / M9
╎❆ 𝙼𝙰𝙸𝙽𝙼𝙴𝙽𝚄 / M10
╎❆ 𝙾𝚆𝙽𝙴𝚁𝙼𝙴𝙽𝚄 / M11
╎❆ 𝙽𝚂𝙵𝚆𝙼𝙴𝙽𝚄 / M12
╎❆ 𝙰𝙸𝙼𝙴𝙽𝚄 / M13
╚┈┈┈┈┈┈┈┈┈┈┈❖`,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true
 }}}}}}, {})
 
 goblok = fs.readFileSync('./src/insecure.opus')
 sky.sendMessage(m.chat, {audio: goblok, mimetype:'audio/mpeg', ptt:true }, {quoted:m}) }
 break
case'menu':{
let me = m.sender
let timestampe = speed();
let latensie = speed() - timestampe
 sky.relayMessage(m.chat, {
 requestPaymentMessage: {
 currencyCodeIso4217: 'IDR',
 amount1000: 12345,
 requestFrom: m.sender,
 noteMessage: {
 extendedTextMessage: {
 text: `
╭──────༺♡༻──────╮
> і ᥒ 𝖿 ᥆ ᑲ ᥆ 𝗍 [<>]
╰──────༺♡༻──────╯ 
〘 ! 〙𝙼𝙾𝙳𝙴 : ${sky.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
〘 ! 〙𝚁𝚄𝙽𝚃𝙸𝙼𝙴 : ${runtime(process.uptime())}
〘 ! 〙𝚃𝙾𝚃𝙰𝙻 𝚄𝚂𝙴𝚁 : ${Object.keys(global.db.data.users).length}
〘 ! 〙𝚃𝙾𝚃𝙰𝙻 𝙿𝚁𝙴𝙼 : ${prem.length}
〘 ! 〙𝚃𝙾𝚃𝙰𝙻 𝙵𝙸𝚃𝚄𝚁 ${totalFitur()}
〘 ! 〙𝙿𝙻𝙰𝚃𝙵𝙾𝚁𝙼 : ${os.platform()} 

╭──────༺♡༻──────╮
> і ᥒ 𝖿 ᥆ ᥙ s ᥱ r [<>]
╰──────༺♡༻──────╯
〘 ! 〙𝙽𝙰𝙼𝙴 : ${pushname}
〘 ! 〙𝙽𝙾𝙼𝙾𝚁 : ${m.sender.split('@')[0]}
〘 ! 〙𝙾𝚆𝙽𝙴𝚁 𝙽𝚄𝙼𝙱𝙴𝚁 : ${m.sender.split('@')[0]}
〘 ! 〙𝙾𝚆𝙽𝙴𝚁 𝙽𝙰𝙼𝙴 : ${isCreator ? "𝙾𝚆𝙽𝙴𝚁 𝙾𝙽𝙻𝚈" : "User ⭐"}
〘 ! 〙𝙱𝙾𝚃 𝙽𝙰𝙼𝙴 : ${botname}
〘 ! 〙𝚁𝚄𝙽𝚃𝙸𝙼𝙴 : ${runtime(process.uptime())}
〘 ! 〙𝚂𝚃𝙰𝚃𝚄𝚂 : ${isCreator ? "𝙾𝚆𝙽𝙴𝚁 𝙾𝙽𝙻𝚈" : "User ⭐"}
〘 ! 〙𝚄𝚂𝙴𝚁 : ${isPremium ? '𝙿𝚁𝙴𝙼 𝙾𝙽𝙻𝚈' : 'Gratisan ⭐'}
〘 ! 〙𝙻𝙸𝙼𝙸𝚃 : ${isCreator ? '𝚄𝙽𝙻𝙸𝙼𝙸𝚃𝙴𝙳 𝙾𝙽𝙻𝚈' : `${db.data.users[m.sender].limit}⭐`}
〘 ! 〙𝙻𝙸𝙽𝙺𝙶𝙲 : https://tinyurl.com/28sl9dqh
〘 ! 〙Ngiḷạṇg.cm
〘 ! 〙http://avosky.wuaze.com

 
╔┈「 𝙎𝙄𝙈𝙋𝙇𝙀-𝙈𝙀𝙉𝙐 」
╎❆ 𝚂𝙴𝙰𝚁𝙲𝙷𝙼𝙴𝙽𝚄 / M1
╎❆ 𝙳𝙾𝚆𝙽𝙻𝙾𝙰𝙳𝙼𝙴𝙽𝚄 / M2
╎❆ 𝙶𝚁𝙾𝚄𝙿𝙼𝙴𝙽𝚄 / M3
╎❆ 𝚁𝙰𝙽𝙳𝙾𝙼𝙼𝙴𝙽𝚄 / M4
╎❆ 𝙼𝙰𝙺𝙴𝚁𝙼𝙴𝙽𝚄 / M5
╎❆ 𝙵𝚄𝙽𝙼𝙴𝙽𝚄 / M6
╎❆ 𝙰𝙽𝙸𝙼𝙴𝙼𝙴𝙽𝚄 / M7
╎❆ 𝙿𝚁𝙸𝙼𝙱𝙾𝙽𝙼𝙴𝙽𝚄 / M8
╎❆ 𝙲𝙾𝙽𝚅𝙴𝚁𝚃𝙼𝙴𝙽𝚄 / M9
╎❆ 𝙼𝙰𝙸𝙽𝙼𝙴𝙽𝚄 / M10
╎❆ 𝙾𝚆𝙽𝙴𝚁𝙼𝙴𝙽𝚄 / M11
╎❆ 𝙽𝚂𝙵𝚆𝙼𝙴𝙽𝚄 / M12
╎❆ 𝙰𝙸𝙼𝙴𝙽𝚄 / M13
╚┈┈┈┈┈┈┈┈┈┈┈❖`,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true
 }}}}}}, {})
 
 goblok = fs.readFileSync('./src/insecure.opus')
 sky.sendMessage(m.chat, {audio: goblok, mimetype:'audio/mpeg', ptt:true }, {quoted:m}) }
 break
case 'play': case 'ytplay': {	
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 if (m.isGroup) return m.reply('Fitur Tidak Dapat Digunakan Untuk Group!')
 if (!text) throw `Example : ${prefix + command} story wa anime`
 let yts = require("yt-search")
 let search = await yts(text)
 let anu = search.videos[Math.floor(Math.random() * search.videos.length)]
 let caption = `
⭔ Title : ${anu.title}
⭔ Ext : Search
⭔ ID : ${anu.videoId}
⭔ Duration : ${anu.timestamp}
⭔ Viewers : ${anu.views}
⭔ Upload At : ${anu.ago}
⭔ Author : ${anu.author.name}
⭔ Channel : ${anu.author.url}
⭔ Description : ${anu.description}
⭔ Url : ${anu.url}`
 sky.sendPoll(m.chat, caption, [`YTMP3 ${anu.url}`,`YTMP4 ${anu.url}`])
 }
 break
case 'aii': {
 if (!text) throw `Contoh: ${prefix + command} Apa Itu Rumah`;
 m.reply(mess.wait);
 let ppai = fs.readFileSync(`./src/ai.mp4`)
 axios.get(`https://aemt.me/openai?text=${text}`).then(({ data }) => {
 const caption = `${data.result}`;
 sky.sendMessage(m.chat, { 
 video: ppai, 
 gifPlayback: true, caption }, 
 { quoted: fkontak });
 });
 }
 break
 
 case 'caritmn': {
if (!isPrem) return replyprem(mess.premium)
 const PhoneNumber = require('awesome-phonenumber');
arip1 = text.split(' | ')[0] ? text.split(' | ')[0] : '-';
arip2 = text.split(' | ')[1] ? text.split(' | ')[1] : '-';
 function generateRandomPhoneNumber(countryCode) {
 let phoneNumber = countryCode;
 for (let i = 0; i < 9; i++) {
 phoneNumber += Math.floor(Math.random() * `${arip2}`);
 }
 return phoneNumber;
 }

 function isWhatsAppNumber(phoneNumber) {
 const pn = new PhoneNumber(phoneNumber);
 return pn.isValid() && pn.isMobile();
 }

 async function delay(ms) {
 return new Promise(resolve => setTimeout(resolve, ms));
 }

 async function caritmn(m) {
 let randomPhoneNumber = generateRandomPhoneNumber(`${arip1}`);

 try {
 // Check if the generated random number has WhatsApp
 const isWhatsApp = await sky.onWhatsApp(`${randomPhoneNumber}@s.whatsapp.net`);
 if (isWhatsApp.length !== 0) {
 await delay(4000);
 m.reply('Berhasil mendapatkan satu orang');
 await delay(5000);

 sky.sendMessage(m.chat, {
 text: `Berhasil mendapatkan teman!\nNih Kak ${randomPhoneNumber}\nhttps://wa.me/${randomPhoneNumber.split("@")[0]}`
 });
 } else {
 // If the generated number doesn't have WhatsApp, try again
 return caritmn(m);
 }
 } catch (error) {
 console.error(error);
 m.reply('Terjadi kesalahan dalam mencari teman.');
 }
 }
 caritmn(m);
}
 break
case 'gajian': {
 const gaji = 7000;
 const user = db.data.users[m.sender];

 const lastGajianTime = user.lastGajianTime || 0;
 const currentTime = Date.now();
 const timeDiff = currentTime - lastGajianTime;
 const hoursSinceLastGajian = timeDiff / (1000 * 60 * 60);

 if (hoursSinceLastGajian >= 24) {
 user.balance += gaji;
 user.lastGajianTime = currentTime;
 m.reply(`Selamat! Kamu menerima gaji sebesar ${gaji} balance. Saldo sekarang: ${user.balance} balance.`);
 } else {
 const remainingTime = 24 - hoursSinceLastGajian;
 m.reply(`Maaf, kamu hanya bisa menggunakan gajian sekali dalam 24 jam. Tunggu ${remainingTime.toFixed(2)} jam lagi.`);
 }
}
 break
case 'p': {
m.reply('pa pe pa pe')
        }
        break
case 'aimath': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
let zeltoria = await fetch(`https://vihangayt.me/tools/mathssolve?q=${q}`)
let hasil = await zeltoria.json()
 m.reply(`${hasil.data}`.trim())
 }
 break
case 'iky': {
 const userMessage = m.text.toLowerCase(); // Pesan pengguna dalam huruf kecil
 const calculateFunPercentage = (message) => {
 const keywordPercentages = {
 'ganteng': 5,
 'manis': 6,
 'baik': 4,
 'lucu': 7,
 'gemoy': 5,
 'imut': 6,
 'gans': 5,
 'uwu': 8,
 'cool': 6,
 'rawr': 7,
 'sumpah': 4,
 'bgt': 5,
 'keren': 6,
 'gg': 7,
 'sepuh': 4,
 'mantap': 6,
 'cool': 5,
 };

 const badKeywords = {
 'jelek': 12,
 };

 const detectedGoodKeywords = [];
 let badKeywordDetected = false;
 let totalPercentage = 0;

 // Mendeteksi good keywords
 Object.keys(keywordPercentages).forEach((keyword) => {
 const occurrences = (message.match(new RegExp(keyword, 'g')) || []).length;
 const keywordPercentage = keywordPercentages[keyword] * occurrences;

 if (occurrences > 0) {
 detectedGoodKeywords.push(`${keyword}: ${occurrences}`);
 }

 totalPercentage += keywordPercentage;
 });

 // Mendeteksi bad keywords
 Object.keys(badKeywords).forEach((keyword) => {
 const occurrences = (message.match(new RegExp(keyword, 'g')) || []).length;

 if (occurrences > 0) {
 badKeywordDetected = true;
 totalPercentage -= badKeywords[keyword] * occurrences;
 }
 });

 // Batasan maksimum persentase
 const maxPercentage = 200;

 // Hasil seharusnya tanpa memperhitungkan bad keyword
 const expectedPercentage = Math.min(totalPercentage, maxPercentage).toFixed(1).replace(/\.0$/, '');

 // Hasil setelah dikurangkan bad keyword
 const formattedPercentage = Math.max(totalPercentage - (badKeywordDetected ? badKeywords['jelek'] : 0), 0).toFixed(1).replace(/\.0$/, '');

 return { detectedGoodKeywords, badKeywordDetected, expectedPercentage, formattedPercentage };
 };

 const { detectedGoodKeywords, badKeywordDetected, expectedPercentage, formattedPercentage } = calculateFunPercentage(userMessage);

 const goodKeywordsMessage = detectedGoodKeywords.length > 0
 ? `Good keywords:\n- ${detectedGoodKeywords.join('\n- ')}`
 : 'Tidak ada good keyword yang terdeteksi.';

 const badKeywordsMessage = badKeywordDetected
 ? 'Badword detect ❕'
 : detectedGoodKeywords.length === 0
 ? 'Tidak ada bad keyword yang terdeteksi.'
 : '';

 const netResultMessage = `- Hasil Sebelum Di Kurangin: ${expectedPercentage}%\n- Hasil Sesudah Di Kurangin: ${formattedPercentage}%\n\n- Jadik Hasil Bersih Yang Kamu Dapat: ${formattedPercentage}%`;

 const response = `${goodKeywordsMessage}\n${badKeywordsMessage}\n${netResultMessage}`;

 m.reply(response);
}
 break
case 'rules':{
let teks =`
Syarat dan Ketentuan menggunakan 

1. Nama dan nomer user
akan Kami simpan di dalam
server selama bot aktif

2. Data akan di hapus ketika bot Offline
atau di hapus oleh Owner Bot

3. Kami tidak menyimpan gambar,
video, file, audio, dan dokumen
yang kamu kirim

4. Kami tidak akan pernah meminta users
untuk memberikan informasi pribadi

5. Jika menemukan Bug/Error silahkan
langsung lapor ke Owner atau Developer
atau bisa juga memakai fitur _*reportbug*_

6. Beberapa fitur mungkin ada yang error,
jadi tunggu sampai developer
meperbaiki fitur tersebut

8. Bot ini sudah di lengkapi dengan
fitur _*Auto Report Bug*_ jika terjadi
error maka bot akan auto report ke
developer, terkecuali error yang
menyebabkan bot mati, maka user
harus lapor ke developer

7. Bot ini juga sudah di lengkapi dengan
Fitur Anti Spam jika kamu terdeteksi
melakukan spam, maka Bot tidak
akan menanggapi kamu selama 20 detik

9. User dilarang keras menelpon bot!
jika melanggar maka kamu akan terkena
banned,block dan dikirim bug

10. Bot tidak akan menanggapi user yang
meminta untuk di save nomernya`
sky.relayMessage(from, { liveLocationMessage: { 
degreesLatitude: 35.676570,
degreesLongitude: 139.762148,
caption : teks,
sequenceNumber: 1656662972682001, timeOffset: 8600, jpegThumbnail: null,
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
containsAutoReply: true,
showAdAttribution: true,
}
}
}
}, { quoted: m })
}
break
case 'sendlinkgc': {
if (!isPrem) return reply(mess.prem)
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628***`)
bnnd = text.split("|")[0]+'@s.whatsapp.net'
let response = await sky.groupInviteCode(from)
sky.sendText(bnnd, `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true })
}
break
case 'listdb': {
if (!isCreator) return m.reply(mess.owner)
 const usersList = Object.keys(db.data.users);
 const totalUsers = usersList.length;

 if (totalUsers === 0) {
 m.reply('Belum ada pengguna terdaftar.');
 } else {
 const userListText = usersList.map((user, index) => `${index + 1}. @${user}`).join('\n');
 m.reply(`Total pengguna: ${totalUsers}\nDaftar Pengguna:\n${userListText}`);
 }
}
 break
case 'deleteuser': {
if (!isCreator) return m.reply(mess.owner)
 const userNumber = parseInt(args[0]);

 if (isNaN(userNumber) || userNumber <= 0) {
 m.reply('Tentukan nomor pengguna yang valid untuk dihapus.');
 return;
 }

 const usersList = Object.keys(db.data.users);
 const totalUsers = usersList.length;

 if (userNumber > totalUsers) {
 m.reply('Nomor pengguna tidak valid. Cek kembali daftar pengguna.');
 return;
 }

 const userToDelete = usersList[userNumber - 1];
 delete db.data.users[userToDelete];

 m.reply(`Pengguna @${userToDelete} telah dihapus.`);
}
 break
case 'resetdb': {
if (!isCreator) return m.reply(mess.owner)
 db.data.users = {}; // Menghapus seluruh data pengguna
 m.reply('Database pengguna berhasil di-reset. Seluruh pengguna telah dihapus.');
}
 break
case 'detailuser': {
if (!isCreator) return m.reply(mess.owner)
 const userNumber = parseInt(args[0]);

 if (isNaN(userNumber) || userNumber <= 0) {
 m.reply('Tentukan nomor pengguna yang valid untuk ditampilkan detailnya.');
 return;
 }

 const usersList = Object.keys(db.data.users);
 const totalUsers = usersList.length;

 if (userNumber > totalUsers) {
 m.reply('Nomor pengguna tidak valid. Cek kembali daftar pengguna.');
 return;
 }

 const userDetail = db.data.users[usersList[userNumber - 1]];
 const currentDate = new Date().toLocaleString(); // Mengambil waktu hari ini

 userDetail.premium = currentDate; // Mengganti nilai premium dengan waktu hari ini

 const detailText = `Detail Pengguna @${usersList[userNumber - 1]}:\n` +
 `AFK Time: ${userDetail.afkTime}\n` +
 `AFK Reason: ${userDetail.afkReason}\n` +
 `Limit: ${userDetail.limit}\n` +
 `Balance: ${userDetail.balance}\n` +
 `Waktu Hari Ini: ${userDetail.premium}`;

 m.reply(detailText);
}
 break
case 'mining': {
 const user = db.data.users[m.sender];

 if (typeof user === 'undefined') throw 'Pengguna tidak ada dalam database';

 if (user.lastMining && Date.now() - user.lastMining < 3600000) {
 const remainingTime = Math.ceil((3600000 - (Date.now() - user.lastMining)) / 60000);
 m.reply(`Anda baru saja melakukan mining. Silakan tunggu ${remainingTime} menit untuk mining kembali.`);
 } else {
 const minedGold = Math.floor(Math.random() * 10) + 1;
 const minedSilver = Math.floor(Math.random() * 10) + 1;
 const minedEmerald = Math.floor(Math.random() * 10) + 1;
 const minedPotion = Math.floor(Math.random() * 10) + 1;

 user.gold += minedGold;
 user.silver += minedSilver;
 user.emerald += minedEmerald;
 user.potion += minedPotion;
 user.lastMining = Date.now();

 m.reply(`Anda berhasil melakukan mining!\n\nHasil:\nGold: ${minedGold} 💰\nSilver: ${minedSilver} 💰\nEmerald: ${minedEmerald} 💎\nPotion: ${minedPotion} 🧪`);
 }
}
 break
case 'shop': {
 const args = m.text.trim().split(' ');
 const action = args[1]?.toLowerCase();

 const getRandomPrice = (min, max) => Math.floor(Math.random() * (max - min + 1) + min);

 const itemPrices = {
 gold: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 silver: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 emerald: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 potion: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 };

 const user = db.data.users[m.sender];

 if (action === 'buy') {
 const itemName = args[2]?.toLowerCase();
 const quantity = parseInt(args[3]);

 if (!itemName || isNaN(quantity) || quantity <= 0) {
 m.reply('Format penggunaan: shop buy <nama_item> <jumlah>');
 return;
 }

 const totalCost = itemPrices[itemName]?.buy * quantity;

 if (!totalCost || user.balance < totalCost) {
 m.reply('Maaf, saldo Anda tidak mencukupi untuk pembelian ini.');
 return;
 }

 user[itemName] += quantity;
 user.balance -= totalCost;

 m.reply(`Anda berhasil membeli ${quantity} ${itemName}(s) seharga Rp.${totalCost}.`);
 } else if (action === 'sell') {
 const itemName = args[2]?.toLowerCase();
 const quantity = parseInt(args[3]);

 if (!itemName || isNaN(quantity) || quantity <= 0) {
 m.reply('Format penggunaan: shop sell <nama_item> <jumlah>');
 return;
 }

 const totalEarned = itemPrices[itemName]?.sell * quantity;

 if (!totalEarned || user[itemName] < quantity) {
 m.reply('Maaf, Anda tidak memiliki cukup barang untuk dijual.');
 return;
 }

 user[itemName] -= quantity;
 user.balance += totalEarned;

 m.reply(`Anda berhasil menjual ${quantity} ${itemName}(s) dan mendapatkan Rp.${totalEarned}.`);
 } else if (action === 'list') {
 const priceList = Object.entries(itemPrices).map(([item, prices]) => {
 return `${item} - Beli: Rp.${prices.buy} - Jual: Rp.${prices.sell}`;
 }).join('\n');

 m.reply(`Daftar Harga:\n${priceList}`);
 } else {
 m.reply('Aksi tidak valid. Gunakan "buy", "sell", atau "list".');
 }
}
 break
case 'price': {
 const args = m.text.trim().split(' ');
 const action = args[1]?.toLowerCase();
 const itemName = args[2]?.toLowerCase();
 const total = parseInt(args[3]);

 if (!action || !itemName || isNaN(total) || total <= 0) {
 m.reply('Format penggunaan: price sell/buy <nama_item> <total>');
 return;
 }

 const getRandomPrice = (min, max) => Math.floor(Math.random() * (max - min + 1) + min);

 const itemPrices = {
 gold: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 silver: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 emerald: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 potion: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 };

 if (action === 'buy') {
 const buyPrice = itemPrices[itemName]?.buy;
 const totalCost = buyPrice * total;
 const balanceNeeded = totalCost - db.data.users[m.sender].balance;

 if (balanceNeeded > 0) {
 m.reply(`Harga beli ${total} ${itemName}(s) adalah Rp.${totalCost}.\n\nDuit Anda Rp.${db.data.users[m.sender].balance}, Anda membutuhkan Rp.${balanceNeeded} balance untuk membeli ${total} ${itemName}(s).`);
 } else {
 m.reply(`Harga beli ${total} ${itemName}(s) adalah Rp.${totalCost}.\n\nDuit Anda Rp.${db.data.users[m.sender].balance}, Anda memiliki saldo cukup.`);
 }
 } else if (action === 'sell') {
 const sellPrice = itemPrices[itemName]?.sell;
 const totalEarned = sellPrice * total;
 
 m.reply(`Harga jual ${total} ${itemName}(s) adalah Rp.${totalEarned}.\n\nDuit Anda Rp.${db.data.users[m.sender].balance}, jika Anda menjual ${total} ${itemName}(s) maka saldo Anda akan bertambah sebanyak Rp.${totalEarned}.`);
 } else {
 m.reply('Aksi tidak valid. Gunakan "buy" atau "sell".');
 }
}
 break
 
case 'ngutang': {
 const args = m.text.trim().split(' ');
 const amountToBorrow = parseInt(args[1]);
 const paymentDeadline = args.slice(2).join(' '); // Menggabungkan bagian tempo_pembayaran yang mungkin memiliki spasi

 function calculateMillisecondsUntilDeadline(deadline) {
 const [amount, unit] = deadline.split(' ');

 if (!unit) {
 m.reply('Format tempo pembayaran tidak valid.');
 return;
 }

 const timeUnits = {
 detik: 1000,
 menit: 60 * 1000,
 jam: 60 * 60 * 1000,
 hari: 24 * 60 * 60 * 1000,
 minggu: 7 * 24 * 60 * 60 * 1000,
 };

 return parseInt(amount) * (timeUnits[unit.toLowerCase()] || 0);
 }

 if (isNaN(amountToBorrow) || amountToBorrow <= 0 || !paymentDeadline) {
 m.reply('Format penggunaan: ngutang <jumlah_balance> <tempo_pembayaran>');
 return;
 }

 if (amountToBorrow > 1000000) {
 m.reply('Maaf, total hutang tidak boleh lebih dari 1 juta.');
 return;
 }

 db.data.users[m.sender].balance += amountToBorrow;
 
 db.data.users[m.sender].debt = {
 amount: amountToBorrow,
 deadline: paymentDeadline,
 };

 m.reply(`Anda berhasil mengajukan utang sebesar Rp.${amountToBorrow} dengan tempo pembayaran ${paymentDeadline}.`);

 setTimeout(() => {
 const userDebt = db.data.users[m.sender].debt;
 if (userDebt && userDebt.amount > 0) {
 db.data.users[m.sender].balance = -1000000;
 m.reply(`Anda telat membayar utang. Saldo Anda menjadi Rp.-1.000.000.`);
 }
 }, calculateMillisecondsUntilDeadline(paymentDeadline));
}
break
case 'cektagihan': {
 const debtAmount = db.data.users[m.sender]?.debt?.amount || 0;

 if (debtAmount > 0) {
 const debtDeadline = db.data.users[m.sender].debt.deadline;
 m.reply(`Anda memiliki hutang sebesar Rp.${debtAmount} dengan tempo pembayaran ${debtDeadline}.`);
 } else {
 m.reply('Anda tidak memiliki hutang yang harus dibayar.');
 }
 break;
}
case 'bayarhutang': {
 const userDebt = db.data.users[m.sender]?.debt;
 const userBalance = db.data.users[m.sender]?.balance || 0;
 const paymentAmount = parseInt(args[0]);

 if (!userDebt || userDebt.amount <= 0) {
 m.reply('Anda tidak memiliki hutang yang harus dibayar.');
 return;
 }

 if (isNaN(paymentAmount) || paymentAmount <= 0 || paymentAmount > userBalance) {
 m.reply('Masukkan jumlah pembayaran yang valid dan sesuai dengan saldo Anda.');
 return;
 }

 const remainingDebt = userDebt.amount - paymentAmount;

 if (paymentAmount >= userDebt.amount) {
 // Bayar hutang secara penuh dan reset informasi utang
 db.data.users[m.sender].balance -= userDebt.amount;
 db.data.users[m.sender].debt = {
 amount: 0,
 deadline: '',
 };

 m.reply(`Sukses membayar total hutang sebesar Rp.${userDebt.amount}. Sisa saldo Anda: Rp.${db.data.users[m.sender].balance}.`);
 } else {
 // Nyicil pembayaran dan update sisa hutang
 db.data.users[m.sender].debt.amount -= paymentAmount;
 db.data.users[m.sender].balance -= paymentAmount;

 m.reply(`Sukses membayar Rp.${paymentAmount}. Sisa hutang sebesar Rp.${remainingDebt}. jangan Lupa Membayar Sisa Hutang ><`);
 }
}
 break
// Case inventory
case 'inventory':
case 'inv': {
 let who;
 if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender;
 else who = m.sender;

 if (typeof db.data.users[who] === 'undefined') throw 'Pengguna tidak ada dalam database';

 const { limit, balance, gold, silver, emerald, debt, potion } = db.data.users[who];
 
 let debtInfo = "Tidak ada hutang.";

 if (debt && typeof debt.amount !== 'undefined' && typeof debt.deadline !== 'undefined') {
 debtInfo = `Hutang: Rp.${debt.amount} dengan batas waktu ${debt.deadline}.`;
 }
 sky.relayMessage(m.chat, {
 requestPaymentMessage: {
 currencyCodeIso4217: 'INR',
 amount1000: 1234567,
 requestFrom: m.sender,
 noteMessage: {
 extendedTextMessage: {
 text: `•Nama: ${pushname}•\n\n〘 • 〙Inventory:\n〘 • 〙Limit: ${limit} 🧿\n〘 • 〙Balance: Rp.${balance} 💸\n〘 • 〙Gold: ${gold} 🪙\n〘 • 〙Silver: ${silver} ◻️\n〘 • 〙Emerald: ${emerald} 🟢\n〘 • 〙Potion: ${potion} 🧪\n〘 • 〙${debtInfo} 💵`,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true
 }
 }
 }
 }
 }
 }, {});
 }
 break
case 'npms': {
	if (!text) throw 'Input Query'
	let res = await fetch(`http://registry.npmjs.com/-/v1/search?text=${text}`)
	let { objects } = await res.json()
	if (!objects.length) throw `Query "${text}" not found :/`
	let txt = objects.map(({ package: pkg }) => {
		return `*${pkg.name}* (v${pkg.version})\n_${pkg.links.npm}_\n_${pkg.description}_`
	}).join`\n\n`
	m.reply(txt)
}
break
case 'menuabersamamu': {
m.reply('ya ya boleh saja')
}
break
//ADDF
            case 'suitpvp': case 'suit': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            this.suit = this.suit ? this.suit : {}
            let poin = 10
            let poin_lose = 10
            let timeout = 60000
            if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.sender))) m.reply(`Selesaikan suit mu yang sebelumnya`)
	    if (m.mentionedJid[0] === m.sender) return m.reply(`Tidak bisa bermain dengan diri sendiri !`)
            if (!m.mentionedJid[0]) return m.reply(`_Siapa yang ingin kamu tantang?_\nTag orangnya..\n\nContoh : ${prefix}suit @${owner[1]}`, m.chat, { mentions: [owner[1] + '@s.whatsapp.net'] })
            if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.mentionedJid[0]))) throw `Orang yang kamu tantang sedang bermain suit bersama orang lain :(`
            let id = 'suit_' + new Date() * 1
            let caption = `_*SUIT PvP*_

@${m.sender.split`@`[0]} menantang @${m.mentionedJid[0].split`@`[0]} untuk bermain suit

Silahkan @${m.mentionedJid[0].split`@`[0]} untuk ketik terima/tolak`
            this.suit[id] = {
            chat: await sky.sendText(m.chat, caption, m, { mentions: parseMention(caption) }),
            id: id,
            p: m.sender,
            p2: m.mentionedJid[0],
            status: 'wait',
            waktu: setTimeout(() => {
            if (this.suit[id]) sky.sendText(m.chat, `_Waktu suit habis_`, m)
            delete this.suit[id]
            }, 60000), poin, poin_lose, timeout
            }
            }
            break
        case 'totalfitur':
        case 'fitur': 
            replygc(`𝙰𝚅𝙾𝚂𝙺𝚈-𝙼𝙳 𝙷𝙰𝚅𝙴 𝙰 ${totalFitur()} 𝙵𝙴𝙰𝚃𝚄𝚁𝙴`)
        break    
case 'groupmenu': case 'menugrup': case 'menugroup': case 'm3': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let anu = `┌──⭓ *Group Menu*
│
${cmdGrup.sort((a, b) => a.localeCompare(b)).map((v, i) => `│⭔ ${prefix}`+ v).join('\n')}
│
└───────⭓`
                sky.sendPoll(m.chat, anu, ['OWNER','SPAM BAN'])
            }
            break
case 'downloadmenu': case 'menudl': case 'menudown': case 'm2': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let anu = `┌──⭓ *Downloader Menu*
│
${cmdDown.sort((a, b) => a.localeCompare(b)).map((v, i) => `│⭔ ${prefix}`+ v).join('\n')}
│
└───────⭓`
                sky.sendPoll(m.chat, anu, ['OWNER','SPAM BAN'])
            }
            break
case 'searchmenu': case 'm1': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let anu = `┌──⭓ *Search Menu*
│
${cmdSearch.sort((a, b) => a.localeCompare(b)).map((v, i) => `│⭔ ${prefix}`+ v).join('\n')}
│
└───────⭓`
                sky.sendPoll(m.chat, anu, ['OWNER','SPAM BAN'])
            }
            break
            case 'randommenu': case 'm4': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let anu = `┌──⭓ *Random Menu*
│
${cmdRand.sort((a, b) => a.localeCompare(b)).map((v, i) => `│⭔ ${prefix}`+ v).join('\n')}
│
└───────⭓`
                sky.sendPoll(m.chat, anu, ['OWNER','SPAM BAN'])
            }
            break 
            case 'makermenu': case 'm5': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let anu = `┌──⭓ *Maker Menu*
│
${cmdMaker.sort((a, b) => a.localeCompare(b)).map((v, i) => `│⭔ ${prefix}`+ v).join('\n')}
│
└───────⭓`
             sky.sendPoll(m.chat, anu, ['OWNER','SPAM BAN'])
            }
            break
            case 'funmenu': case 'm6': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let anu = `┌──⭓ *Fun Menu*
│
${cmdFun.sort((a, b) => a.localeCompare(b)).map((v, i) => `│⭔ ${prefix}`+ v).join('\n')}
│
└───────⭓`
               sky.sendPoll(m.chat, anu, ['OWNER','SPAM BAN'])
            }
            break
case 'animemenu': case 'm7': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let anu = `┌──⭓ *Anime Menu*
│
${cmdAnime.sort((a, b) => a.localeCompare(b)).map((v, i) => `│⭔ ${prefix}`+ v).join('\n')}
│
└───────⭓`
                sky.sendPoll(m.chat, anu, ['OWNER','SPAM BAN'])
            }
            break            
            case 'primbonmenu': case 'm8': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let anu = `┌──⭓ *Primbon Menu*
│
${cmdPrimbon.sort((a, b) => a.localeCompare(b)).map((v, i) => `│⭔ ${prefix}`+ v).join('\n')}
│
└───────⭓`
                sky.sendPoll(m.chat, anu, ['OWNER','SPAM BAN'])
            }
            break 
            case 'convertmenu': case 'm9': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
               let anu = `┌──⭓ *Convert Menu*
│
${cmdConv.sort((a, b) => a.localeCompare(b)).map((v, i) => `│⭔ ${prefix}`+ v).join('\n')}
│
└───────⭓`
                sky.sendPoll(m.chat, anu, ['OWNER','SPAM BAN'])
            }
            break 
            case 'mainmenu': case 'm10': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let anu = `┌──⭓ *Main Menu*
│
${cmdMain.sort((a, b) => a.localeCompare(b)).map((v, i) => `│⭔ ${prefix}`+ v).join('\n')}
│
└───────⭓`
                 sky.sendPoll(m.chat, anu, ['OWNER','SPAM BAN'])
            }
            break 
            case 'ownermenu': case 'm11': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let anu = `┌──⭓ *Owner Menu*
│
${cmdOwner.sort((a, b) => a.localeCompare(b)).map((v, i) => `│⭔ ${prefix}`+ v).join('\n')}
│
└───────⭓`
               sky.sendPoll(m.chat, anu, ['OWNER','SPAM BAN'])
            }
            break
            case 'aimenu': case 'm13': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let anu = `┌──⭓ 🔥 AI-MENU 🔥
│
${cmdSup.sort((a, b) => a.localeCompare(b)).map((v, i) => `│⭔ ${prefix}`+ v).join('\n')}
│
└───────⭓`
               sky.sendPoll(m.chat, anu, ['OWNER','SPAM BAN'])
            }
            break
	    case 'donasi': case 'sewabot': case 'sewa': case 'buypremium': case 'donate': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                m.reply('Ketik RealOwner Chat Salah Satu')
            }
            break
case 'apiky': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                m.reply('https://api.akuari.my.id/docs\n\nhttps://api.botcahx.live/\n\nhttps://api.lolhuman.xyz/\n\nhttps://skizo.tech/\n\nhttps://api.xyroinee.xyz/\n\nhttps://vihangayt.me/\n\nhttps://api.azz.biz.id\n\napi.yanzbotz.my.id\n\n')         
              }
            break
case "bot": {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                replygc(`Bot Ud Online Kok ${pushname}`)         
              }
            break
            case 'bug':{
    let Message = { text: `Serem Ih`};   
    sky.sendMessage(m.chat, Message, { quoted: fkontak });
  }
  break;
              case 'bagi':{
    let Message = { text: `Bagi Apa Kak >//<`};   
    sky.sendMessage(m.chat, Message, { quoted: fkontak });
  }
  break
  case 'buyprem': {
    const userBalance = db.data.users[m.sender]?.balance || 0;

    if (userBalance < 2000000) {
        m.reply('Maaf, saldo Anda tidak mencukupi untuk membeli status premium.');
        return;
    }

    const prrkek = m.sender.replace('@s.whatsapp.net', '') + `@s.whatsapp.net`;

    if (prem.includes(prrkek)) {
        m.reply('Maaf, Anda sudah memiliki status premium. Tidak dapat membeli status premium lebih dari sekali.');
        return;
    }

    const ceknya = await sky.onWhatsApp(prrkek);

    if (ceknya.length === 0) {
        m.reply('Maaf, terjadi kesalahan saat mengambil nomor Anda.');
        return;
    }

    // Mengurangkan saldo dan menambahkan nomor ke daftar premium
    db.data.users[m.sender].balance -= 2000000;
    prem.push(prrkek);
    fs.writeFileSync('./database/premium.json', JSON.stringify(prem));

    m.reply(`Nomor Anda sekarang memiliki status premium. Saldo Anda sekarang: Rp.${db.data.users[m.sender].balance}.`);
}
    break
             
        case 'chats': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) return m.reply(mess.owner)
                if (!q) return m.reply('Option : 1. mute\n2. unmute\n3. archive\n4. unarchive\n5. read\n6. unread\n7. delete')
                if (args[0] === 'mute') {
                    sky.chatModify({ mute: 'Infinity' }, m.chat, []).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0] === 'unmute') {
                    sky.chatModify({ mute: null }, m.chat, []).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0] === 'archive') {
                    sky.chatModify({ archive: true }, m.chat, []).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0] === 'unarchive') {
                    sky.chatModify({ archive: false }, m.chat, []).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0] === 'read') {
                    sky.chatModify({ markRead: true }, m.chat, []).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0] === 'unread') {
                    sky.chatModify({ markRead: false }, m.chat, []).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0] === 'delete') {
                    sky.chatModify({ clear: { message: { id: m.quoted.id, fromMe: true }} }, m.chat, []).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                }
            }
        break
	    case 'family100': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if ('family100'+m.chat in _family100) {
                    m.reply('Masih Ada Sesi Yang Belum Diselesaikan!')
                    throw false
                }
                let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json')
                let random = anu[Math.floor(Math.random() * anu.length)]
                let hasil = `*Jawablah Pertanyaan Berikut :*\n${random.soal}\n\nTerdapat *${random.jawaban.length}* Jawaban ${random.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}`.trim()
                _family100['family100'+m.chat] = {
                    id: 'family100'+m.chat,
                    pesan: await sky.sendText(m.chat, hasil, m),
                    ...random,
                    terjawab: Array.from(random.jawaban, () => false),
                    hadiah: 6,
                }
            }
            break
case 'setexif': 
                if (!isCreator) return mess.owner
                if (!text) return `Contoh : ${prefix + command} packname|author`
                global.packname = text.split("|")[0]
                global.author = text.split("|")[1]
                m.reply(`Exif berhasil diubah menjadi\n\n• Packname : ${global.packname}\n• Author : ${global.author}`)
            
            break
case 'halah': case 'hilih': case 'huluh': case 'heleh': case 'holoh':
  if (!m.quoted && !text) throw `Kirim/reply text dengan caption ${prefix + command}`;
  ter = command[1].toLowerCase();
  tex = m.quoted ? m.quoted.text ? m.quoted.text : q ? q : m.text : q ? q : m.text;
  m.reply(tex.replace(/[aiueo]/g, ter).replace(/[AIUEO]/g, ter.toUpperCase()));
  break;
case 'sapa': {
            let member = participants.map(u => u.id)
let me = m.sender
  let jodoh = member[Math.floor(Math.random() * member.length)]
replygc(`Hi lu @${jodoh.split('@')[0]}`);
}
break
            case "sepuh":{
               yui = fs.readFileSync('./src/insecure.opus')
               sky.sendMessage(m.chat,{
               audio: yui, 
               mimetype:'audio/mpeg', ptt:true,
        contextInfo:{
        externalAdReply:{
            title: `kamu pemula ya ${pushname}`,
            body: 'sepuhhh',
            thumbnail: fs.readFileSync('./src/pemula.jpg'),
            mediaType:2,
            mediaUrl: 'https://telegra.ph/file/26a54d3ae881dcb37ed3d.jpg',
        }

    },
},{quoted:fkontak})               
}
               break
            case 'tebak': {
            if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit) // respon ketika limit habis
		db.data.users[m.sender].limit -= 5 // -1 limit
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} lagu\n\nOption : \n1. gambar\n2. kata\n3. kalimat\n4. lirik\n5. lontong`
                if (args[0].toLowerCase() === "lagu") {
                    if (tebaklagu.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                    let anu = await fetchJson('https://fatiharridho.github.io/tebaklagu.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    let msg = await sky.sendMessage(m.chat, { audio: { url: result.link_song }, mimetype: 'audio/mpeg' }, { quoted: m })
                    sky.sendText(m.chat, `Lagu Tersebut Adalah Lagu dari?\n\nArtist : ${result.artist}\nWaktu : 60s`, msg).then(() => {
                    tebaklagu[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                    })
                    await sleep(60000)
                    if (tebaklagu.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    m.reply(`Waktu Habis\nJawaban:  ${tebaklagu[m.sender.split('@')[0]]}`)
                    delete tebaklagu[m.sender.split('@')[0]]
                    }
                } else if (args[0].toLowerCase() === 'gambar') {
                    if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    sky.sendImage(m.chat, result.img, `Silahkan Jawab Soal Di Atas Ini\n\nDeskripsi : ${result.deskripsi}\nWaktu : 60s`, m).then(() => {
                    tebakgambar[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                    })
                    await sleep(60000)
                    if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    m.reply(`Waktu Habis\nJawaban:  ${tebakgambar[m.sender.split('@')[0]]}`)
                    delete tebakgambar[m.sender.split('@')[0]]
                    }
                } else if (args[0].toLowerCase() === 'kata') {
                    if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    sky.sendText(m.chat, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s`, m).then(() => {
                    tebakkata[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                    })
                    await sleep(60000)
                    if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    m.reply(`Waktu Habis\nJawaban:  ${tebakkata[m.sender.split('@')[0]]}`)
                    delete tebakkata[m.sender.split('@')[0]]
                    }
                } else if (args[0].toLowerCase() === 'kalimat') {
                    if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkalimat.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    sky.sendText(m.chat, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s`, m).then(() => {
                    tebakkalimat[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                    })
                    await sleep(60000)
                    if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    m.reply(`Waktu Habis\nJawaban:  ${tebakkalimat[m.sender.split('@')[0]]}`)
                    delete tebakkalimat[m.sender.split('@')[0]]
                    }
                } else if (args[0].toLowerCase() === 'lirik') {
                    if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    sky.sendText(m.chat, `Ini Adalah Lirik Dari Lagu? : *${result.soal}*?\nWaktu : 60s`, m).then(() => {
                    tebaklirik[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                    })
                    await sleep(60000)
                    if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    m.reply(`Waktu Habis\nJawaban:  ${tebaklirik[m.sender.split('@')[0]]}`)
                    delete tebaklirik[m.sender.split('@')[0]]
                    }
                } else if (args[0].toLowerCase() === 'lontong') {
                    if (caklontong.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/caklontong.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    sky.sendText(m.chat, `*Jawablah Pertanyaan Berikut :*\n${result.soal}*\nWaktu : 60s`, m).then(() => {
                    caklontong[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
		    caklontong_desk[m.sender.split('@')[0]] = result.deskripsi
                    })
                    await sleep(60000)
                    if (caklontong.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    m.reply(`Waktu Habis\nJawaban:  ${caklontong[m.sender.split('@')[0]]}\nDeskripsi : ${caklontong_desk[m.sender.split('@')[0]]}`)
                    delete caklontong[m.sender.split('@')[0]]
		    delete caklontong_desk[m.sender.split('@')[0]]
                    }
                }
            }
            break
            case 'kuismath': case 'math': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (kuismath.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                let { genMath, modes } = require('./src/math')
                if (!text) throw `Mode: ${Object.keys(modes).join(' | ')}\nContoh penggunaan: ${prefix}math medium`
                let result = await genMath(text.toLowerCase())
                sky.sendText(m.chat, `*Berapa hasil dari: ${result.soal.toLowerCase()}*?\n\nWaktu: ${(result.waktu / 1000).toFixed(2)} detik`, m).then(() => {
                    kuismath[m.sender.split('@')[0]] = result.jawaban
                })
                await sleep(result.waktu)
                if (kuismath.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    m.reply("Waktu Habis\nJawaban: " + kuismath[m.sender.split('@')[0]])
                    delete kuismath[m.sender.split('@')[0]]
                }
            }
            break
            case 'jodohku': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!m.isGroup) throw mess.group
            let member = participants.map(u => u.id)
            let me = m.sender
            let jodoh = member[Math.floor(Math.random() * member.length)]
            let jawab = `👫Jodoh mu adalah

@${me.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`
            sky.sendTextWithMentions(m.chat, jawab, m)
            }
            break
            case 'jadian': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!m.isGroup) throw mess.group
            let member = participants.map(u => u.id)
            let orang = member[Math.floor(Math.random() * member.length)]
            let jodoh = member[Math.floor(Math.random() * member.length)]
            let jawab = `Ciee yang Jadian💖 Jangan lupa pajak jadiannya🐤

@${orang.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`
            sky.sendTextWithMentions(m.chat, jawab, m)
            }
            break
            case 'react': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) throw mess.owner
                reactionMessage = {
                    react: {
                        text: args[0],
                        key: { remoteJid: m.chat, fromMe: true, id: quoted.id }
                    }
                }
                sky.sendMessage(m.chat, reactionMessage)
            }
            break  
            // Ephoto1
case "wetglass": case "multicolor3d": case "watercolor": case "luxurygold": case "galaxywallpaper": case "lighttext": case "beautifulflower": case "puppycute": case "royaltext": case "heartshaped": case "birthdaycake": case "galaxystyle": case "hologram3d": case "greenneon": case "glossychrome": case "greenbush": case "metallogo": case "noeltext": case "glittergold": case "textcake": case "starsnight": case "wooden3d": case "textbyname": case "writegalacy": case "galaxybat": case "snow3d": case "birthdayday": case "goldplaybutton": case "silverplaybutton": case "freefire": case "aovwall": case "mlwall": {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
			  if (!text) throw `Example : ${prefix + command} text`
                m.reply(mess.wait)
		sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/ephoto1/${command}?apikey=GataDios&text=${text}`}, caption: `Ephoto1 ${command}` }, { quoted: m})
			 }
            break
case "blackpink": case "neon": case "greenneon": case "advanceglow": case "futureneon": case "sandwriting": case "sandsummer": case "sandengraved": case "metaldark": case "neonlight": case "holographic": case "text1917": case "minion": case "deluxesilver": case "newyearcard": case "bloodfrosted": case "halloween": case "jokerlogo": case "fireworksparkle": case "natureleaves": case "bokeh": case "toxic": case "strawberry": case "box3d": case "roadwarning": case "breakwall": case "icecold": case "luxury": case "cloud": case "summersand": case "horrorblood": case "thunder": case "wonderfulgraffiti": case "sliced": {
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		  if (!isPrem) return replyprem(mess.premium)
			m.reply(mess.wait)
			sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/textprome/${command}?apikey=GataDios&text=${q}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${args1}`})
			}
			break
case 'aidalle': {
  if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} apa aja yang ada di otak lu`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://aemt.me/dalle?text=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
    case 'mediafire': {				
if (!text) throw 'Masukkan Query Link!'
if (!isUrl(args[0]) && !args[0].includes('mediafire.com')) return m.reply(`The link you provided is invalid`)
const baby1 = await mediafireDl(text)
if (baby1[0].size.split('MB')[0] >= 999) return m.reply('*File Over Limit* '+util.format(baby1))
const result4 = `*MEDIAFIRE DOWNLOADER*
				
*Name* : ${baby1[0].nama}
*Size* : ${baby1[0].size}
*Mime* : ${baby1[0].mime}
*Link* : ${baby1[0].link}`
m.reply(`${result4}`)
sky.sendMessage(m.chat, { document : { url : baby1[0].link}, fileName : baby1[0].nama, mimetype: baby1[0].mime }, { quoted : m }).catch ((err) => m.reply(mess.error))
}
break

case 'ahegao': case 'ass': case 'bdsm': case 'blowjob': case 'cuckold':
case 'cum': case 'ero': case 'femdom': case 'foot': case 'gangbang':
case 'glasses': case 'hentai': case 'jahy': case 'maid': case 'manga':
case 'masturbation': case 'neko': case 'netorare': case 'nsfwmobilewallpaper':
case 'orgy': case 'panties': case 'pussy': case 'sfwneko': case 'tentacles': {
           if (!isPrem) return replyprem(mess.premium)
			m.reply(mess.wait)
			sky.sendMessage(m.chat, { image: { url: `https://api.zahwazein.xyz/api/morensfw/${command}?apikey=zenzkey_94e9997864a8` }, caption: `Type: ${command}`})
			}
			break
			case 'halo': {
  const hour = new Date().getHours();
  let greeting;
  if (hour >= 0 && hour < 12) {
    greeting = 'Selamat pagi';
  } else if (hour >= 12 && hour < 15) {
    greeting = 'Selamat siang';  
  } else if (hour >= 15 && hour < 18) {
    greeting = 'Selamat sore';
  } else {
    greeting = 'Selamat malam';
  }
  await m.reply(`${greeting}! Semoga harimu menyenangkan ya.`);
}
  break;			
    case 'uniform': case 'selfies': case 'raiden': case 'maid': case 'kitagawa': case 'calliope': case 'zettai': case 'anime': case 'waifu': case 'husbu': case 'shinobu': case 'megumin': case 'waifus': case 'nekos': case 'trap':{
           if (!isPrem) return replyprem(mess.premium)
			m.reply(mess.wait)
			sky.sendMessage(m.chat, { image: { url: `https://api.zahwazein.xyz/randomanime/${command}?apikey=zenzkey_94e9997864a8` }, caption: `Type: ${command}`})
			}
			break			
			case 'm14': case 'animemenu2':{
let anunya = `• Naruto\n• Sasuke\n• Luffy\n• Goku\n• Vegeta\n• Ichigo\n• Eren\n• Mikasa\n• Levi\n• Gon\n• Killua\n• Hisoka\n• Edward\n• Alphonse\n• Winry\n• Light\n• Ryuk\n• Ken\n• Kaneki\n• Toka\n• Izuku\n• Bakugo\n• Allmight\n• Deku\n• Mob\n• Reigen\n• Teru\n• Narancia\n• Giorno\n• Jotaro\n• Dio\n• Kira\n• Shinichi\n• Ran\n• Conan\n• Kaito\n• Aizen\n• Byakuya\n• Hitsugaya\n• Orihime\n• Gintoki\n• Shinpachi\n• Kagura\n• Zura\n• Makoto\n• Haru\n• Rin\n• Nagisa\n• Saitama\n• Genos\n• Mumen\n• Boros\n• Gohan\n• Piccolo\n• Krillin\n• Frieza\n• Vegeto\n• Goten\n• Trunks\n• Cell\n• Neji\n• Rocklee\n• Tenten\n• Itachi\n• Kakashi\n• Sakura\n• Tsunade\n• Gaara\n• Neku\n• Shiki\n• Joshua\n• Beat\n• Naoto\n• Kanji\n• Rise\n• Yosuke\n• Makoto\n• Yusuke\n• Ann\n• Morgana\n• Ryuji\n• Futaba\n• Haru\n• Aigis\n• Makoto\n• Yukiko\n• Chie\n• Nanako\n• Yukari\n• Junpei\n• Mitsuru\n• Akihiko\n• Yusuke\n• Makoto\n• Futaba\n• Haru\n• Frodo\n• Sam\n• Aragorn\n• Gandalf\n• Legolas\n• Gimli\n• Boromir\n• Smeagol\n• Harry\n• Ron\n• Hermione\n• Dumbledore\n• Voldemort\n• Snape\n• Malfoy\n• Hagrid\n• Bilbo\n• Thorin\n• Smaug`
let me = m.sender
skysend(from, { 
text: `${anunya}`,
contextInfo:{
forwardingScore: 9999999,
isForwarded: true, 
mentionedJid:[me],
"externalAdReply": {
"showAdAttribution": true,
"renderLargerThumbnail": true,
"title": `${pushname}`,
"body": `ANIMEMENU2`, 
"containsAutoReply": true,
"mediaType": 1, 
"thumbnail": fs.readFileSync('./src/sky.jpg'),
"mediaUrl": `https://telegra.ph/file/e16491436f44810c07b68.jpg`,
"sourceUrl": `https://telegra.ph/file/e16491436f44810c07b68.jpg`
}
}
},{ 
quoted: m })
}
break					
case 'm12': case 'nsfwmenu':{
let anunya = `• ahegao\n• ass\n• bdsm\n• blowjob\n• cuckold\n• cum\n• ero\n• femdom\n• foot\n• gangbang\n• glasses\n• hentai\n• hentai\n• jahy\n• maid\n• manga\n• masturbation\n• neko\n• netorare\n• nsfwmobilewallpaper\n• orgy\n• trap\n• panties\n• pussy\n• sfwneko\n• tentacles\n• thighs\n• yuri\n• zettai\n• waifus\n• oppai\n• uniform\n• selfies\n• raiden\n• maid\n• kitagawa\n• calliope`
let me = m.sender
skysend(from, { 
text: `${anunya}`,
contextInfo:{
forwardingScore: 9999999,
isForwarded: true, 
mentionedJid:[me],
"externalAdReply": {
"showAdAttribution": true,
"renderLargerThumbnail": true,
"title": `${pushname}`,
"body": `NSFW MENU`, 
"containsAutoReply": true,
"mediaType": 1, 
"thumbnail": fs.readFileSync('./src/sky.jpg'),
"mediaUrl": `https://telegra.ph/file/e16491436f44810c07b68.jpg`,
"sourceUrl": `https://telegra.ph/file/e16491436f44810c07b68.jpg`
}
}
},{ 
quoted: m })
}
break					
case 'rate1':
  if (!m.quoted && !text) throw `Kirim/reply gambar dengan caption ${prefix + command}`;
  let target = m.quoted ? m.quoted.sender : m.sender;
  let rate = Math.floor(Math.random() * 11); // Generate random rating from 0 to 10
  let message = `Menurutku, @${target.split('@')[0]} memiliki tingkat kegantengan/kecantikan sebesar ${rate}/10!`;
  m.reply(message);
  break;

case 'amongus': {
  if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/${command}?apikey=GataDios&text=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
			case 'logogaming': {
  if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/ephoto1/logogaming?apikey=GataDios&text=${q}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
					case 'fpslogo': {
  if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/ephoto1/fpslogo?apikey=GataDios&text=${q}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
			case 'anonymouslogo': {
  if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/ephoto1/anonymhacker?apikey=GataDios&text=${q}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break			
			
			case 'qc':{ 
m.reply(mess.wait)
if (!quoted){
try {
var linkppuserp = await sky.profilePictureUrl(mentionUser[0], 'image')
} catch {
var linkppuserp = 'https://telegra.ph/file/1474e6b4032c00a434192.jpg'
}
const getname = await sky.getName(mentionUser[0])
const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#FFFFFF",
"width": 512,
"height": 768,
"scale": 2,
"messages": [
 {
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": getname,
"photo": {
 "url": linkppuserp
}
},
"text": quotedMsg.chats,
"replyMessage": {}
 }
]
};
const response = axios.post('https://bot.lyo.su/quote/generate', json, {
headers: {'Content-Type': 'application/json'}
}).then(res => {
const buffer = Buffer.from(res.data.result.image, 'base64')
var opt = { packname: "©ItsMeNaufal", author: "NAUFAL-MD" }
sky.sendImageAsSticker(from, buffer, m, opt)
});
} else if (q){
try {
var linkppuserp = await sky.profilePictureUrl(sender, 'image')
} catch {
var linkppuserp = 'https://telegra.ph/file/8e0926031df7fd2d57426.jpg'
}
const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#FFFFFF",
"width": 512,
"height": 768,
"scale": 2,
"messages": [
 {
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": pushname,
"photo": {
 "url": linkppuserp
}
},
"text": q,
"replyMessage": {}
 }
]
};
const response = axios.post('https://bot.lyo.su/quote/generate', json, {
headers: {'Content-Type': 'application/json'}
}).then(res => {
const buffer = Buffer.from(res.data.result.image, 'base64')
var opt = { packname: "©Sky", author: "SkY-MD" }
sky.sendImageAsSticker(from, buffer, m, opt)
});
} else {
m.reply(`Kirim perintah ${command} text atau reply pesan dengan perintah ${command}`)
}
}
        break
case 'quotemaker': {
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Entah Kenapa Manusia Itu Licik`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/quotemaker?apikey=GataDios&text=${text}.` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
			            case 'quotesrandom': {
                let d = await fetchJson(`https://api.quotable.io/random`)
              await sky.sendMessage(from, { text: d.content }, { quoted: m})
            }
            break		
case 'aicreate': {
if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} kids,cute`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://skizo.tech/api/txt2img?text=${text}&apikey=${apikey}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
			case 'airealistic': {
if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} kids,cute`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.yanzbotz.my.id/api/text2img/realistic?prompt=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }		
			break
			case 'aineima': {
if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} kids,cute`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.yanzbotz.my.id/api/text2img/neima?prompt=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
					case 'aiabsolutely': {
if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} kids,cute`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.yanzbotz.my.id/api/text2img/absolutely?prompt=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
			case 'aiabsolutely2': {
if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} kids,cute`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.yanzbotz.my.id/api/text2img/absolutelyV2?prompt=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
			case 'aianything': {
if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} house`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.yanzbotz.my.id/api/text2img/anything?prompt=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
case 'aicreate3': {
if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} kids,cute`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://aemt.me/ai/text2img?text=${q}` }, caption: `${text}`})
 }
			break
										
case 'aiscene': {                 
                   m.reply(mess.wait)
                    const media = await sky.downloadAndSaveMediaMessage(quoted)
                    const { TelegraPh } = require('./lib/uploader')
                    const anu = await TelegraPh(media)
                    await 
                    sky.sendMessage(m.chat, { image: { url: `https://skizo.tech/api/aiscene?url=${anu}&apikey=skuy33` }, caption: mess.done }, { quoted: m})
                    }
                    break

case 'stablediff': {
if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} highly20detailed,20intricate,204k,208k,%20sharp20focus,20detailed20hair,20detailed`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://aemt.me/stablediffusion?text=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
			case 'aibing': {
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://aemt.me/download/bing` }, caption: `Here You Go ${pushname}`})
 }
			break			
case 'oppai': {
  if (!isPrem) return replyprem(mess.premium)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.zahwazein.xyz/randomanime/oppai?apikey=zenzkey_94e9997864a8` }, caption: `Oppai ><`})
 }
			break
case 'gimage': {
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Rumah Di Pegunungan`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/gimage?apikey=GataDios&query=${text}` }, caption: `G Image \n\nResult From ${text}`})
 }
			break
case 'shadow': case 'romantic': case 'smoke': case 'burnpapper': case 'rainbow': case 'grassmsg': case 'lovetext': case 'coffecup': case 'butterfly': case 'harrypotter': case 'quotewood': {
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.zahwazein.xyz/photooxy/${command}?text=${text}&apikey=zenzkey_94e9997864a8` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
case 'cekregionmember': {
  if (!m.isGroup) throw mess.group;
  
  const participants = await sky.groupMetadata(m.chat).then(metadata => metadata.participants);
  
  let countIndonesia = 0;
  let countMalaysia = 0;
  let countUSA = 0;
  let countOther = 0;
  
  participants.forEach(participant => {
    const phoneNumber = participant.id.split('@')[0];
    if (phoneNumber.startsWith("62")) {
      countIndonesia++;
    } else if (phoneNumber.startsWith("60")) {
      countMalaysia++;
    } else if (phoneNumber.startsWith("1")) {
      countUSA++;
    } else if (phoneNumber.startsWith("+1")) {
      countOther++;
    } else {
      countOther++;
    }
  });
  
  const replyMessage = `Jumlah Anggota Grup Berdasarkan Negara:\n\nAnggota Indonesia: ${countIndonesia} 🇮🇩\nAnggota Malaysia: ${countMalaysia} 🇲🇾\nAnggota USA + OTHER : ${countUSA} 🇺🇲\nAnggota Negara Lain: ${countOther} 🏳️`;
  m.reply(replyMessage);
  break;
}
case 'cekmember': {
  if (!m.isGroup) throw mess.group;
  if (args1.length == 0) return m.reply(`Gunakan perintah ini dengan contoh: *cekmember 62* untuk mencari anggota dengan awalan nomor tertentu.`)
  const participants = await sky.groupMetadata(m.chat).then(metadata => metadata.participants);
  
  let countIndonesia = 0;
  let countMalaysia = 0;
  let countUSA = 0;
  let countOther = 0;
  
  participants.forEach(participant => {
    const phoneNumber = participant.id.split('@')[0];
    if (phoneNumber.startsWith(`${q}`)) {
      countIndonesia++;
    } else if (phoneNumber.startsWith("60")) {
      countMalaysia++;
    } else if (phoneNumber.startsWith("1")) {
      countUSA++;
    } else if (phoneNumber.startsWith("+1")) {
      countOther++;
    } else {
      countOther++;
    }
  });
  
const replyMessage = `Jumlah Anggota Grup Berdasarkan Awalan +${q} Sebanyak \n️${countIndonesia} Member`;
  m.reply(replyMessage);
  break;
}
case 'rem': case 'kaneki': {
  if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.caliph.biz.id/api/${command}?nama=${text}&apikey=SxuR9VBB` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
			case 'ratu': {
  if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.lenttobs.xyz/logo/ratu1?text=${q}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break			
case 'lovemsg': {
  if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/photooxy1/lovemessage?apikey=GataDios&text=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
case 'ssweb': {	
                    if (args1.length == 0) return m.reply(`Example: ${prefix + command} https://www.google.com`)
                    kueri = args[0]
                    ini_buffer = await getBuffer(`https://aemt.me/sspc?url=${text}`)
                  sky.sendImage(m.chat, ini_buffer, 'Screenshot Website', m)
                  }
                  break

case 'meme1': {
  if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/meme1?apikey=GataDios&text=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
case 'unbanned': {
  if (!isPrem) return replyprem(mess.premium)
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return m.reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=199999999999999999995777678776668876677777")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Good day whatsApp team. My whatApp account has been burned permanently, please i plead with you unblock it, i cannot use another number again. I don’t know why it is burned but my friends re suggesting its because i use GB whatsApp, which i didn’t know it was wrong. My number is [ ${targetnya} ]. Please whatsApp team, help me unblock my account. please i cannot use a new number as my current number is connected to slot of important things like vacancies.
Thank you`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19531.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007735016")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
m.reply(`Wait 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp tuan Hw Mods🥺🙏`)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
m.reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
m.reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else m.reply(util.format(res.data))
} catch (err) {m.reply(`${err}`)}
} else m.reply('Masukkan nomor target!')
}
break
case 'meme2':
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/meme4?apikey=GataDios&text=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
			break
 case 'carbon':
	            if (!q) return m.reply(`Example: ${prefix + command} const adrian = required('adrian-api')`)
	            m.reply(mess.wait)
	            sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/carbon?apikey=GataDios&code=${q}&language=nodejs`}, caption: `Created By Sky\n\n\nCode:\n\n${q}`}, {quoted: m})
	        break
           case 'listonline':
            case 'liston': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) m.reply(mess.group)
                let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : m.chat
                let online = [...Object.keys(store.presences[id]), botNumber]
                sky.sendText(m.chat, '⏰ List Online:\n\n' + online.map(v => '🌱 @' + v.replace(/@.+/, '')).join`\n`, m, {
                    mentions: online
                })
            }
            break

case 'cry': case 'kill': case 'hug': case 'pat': case 'lick': 
case 'kiss': case 'bite': case 'yeet': case 'bully': case 'bonk':
case 'wink': case 'poke': case 'nom': case 'slap': case 'smile': 
case 'wave': case 'awoo': case 'blush': case 'smug': case 'glomp': 
case 'happy': case 'dance': case 'cringe': case 'cuddle': case 'highfive': 
case 'shinobu': case 'handhold': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')

axios.get(`https://api.waifu.pics/sfw/${command}`)
.then(({data}) => {
sky.sendImageAsSticker(from, data.url, m, { packname: global.packname, author: global.author })
})
}
break
case 'woof':
case '8ball':
case 'goose':
case 'gecg':
case 'feed':
case 'avatar':
case 'fox_girl':
case 'lizard':
case 'spank':
case 'meow':
case 'tickle':{
                axios.get(`https://nekos.life/api/v2/img/${command}`)
.then(({data}) => {
sky.sendImageAsSticker(from, data.url, m, { packname: global.packname, author: global.author })
})
}
break
	case 'bucinserti':
				if (args1.length == 0) return m.reply(`Example: ${prefix + command} Justimun`)
				m.reply(mess.wait)
				kueri = args.join(" ")
                sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/bucinserti?apikey=GataDios&name=${kueri}`}, caption: 'Sertifikatnya kack'}, {quoted: m})
            break          
			case 'tololserti':
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} Justimun`)
			m.reply(mess.wait)
			ytta = args.join(" ")
            sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/toloserti?apikey=GataDios&name=${ytta}`}, caption: 'Sertifikatnya kack'}, {quoted: m})
            break
  			case 'pacarserti':		
            if (args1.length == 0) return m.reply(`Usage: ${prefix + command} nama1|nama2`)
            m.reply(mess.wait)
                get_args = args.join(" ").split("|")
                nik = get_args[0]
                prov = get_args[1]
			    titidnya = `Selamat yaa ${nik} ❤️ ${prov}`
            sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/pacarserti?apikey=GataDios&name1=${nik}&name2=${prov}`}, caption: titidnya}, {quoted: m})
            break
	        
case 'jadwalbola': {
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/jadwalbola?apikey=GataDios`)	
			var titttttttttttt = 'Jadwal Bola :\n'
			for (var x of data.result) {
				titttttttttttt += `Pada : ${x.time}\n`
				titttttttttttt += `Event : ${x.event}\n`
				titttttttttttt += `Match : ${x.match}\n`
				titttttttttttt += `TV : ${x.tv}\n\n`
			}
			m.reply(titttttttttttt)
			}
			break
case 'jadwalsolat': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!text) return m.reply('Mana Kotanya?')
            m.reply(mess.wait)
            let anu = await fetchJson(`https://api.lolhuman.xyz/api/sholat/${text}?apikey=GataDios`)
            m.reply(`Wilayah: ${anu.result.wilayah}\n\nTanggal: ${anu.result.tanggal}\nSahur: ${anu.result.sahur}\nImsak: ${anu.result.imsak}\nTerbit: ${anu.result.terbit}\nDhuha: ${anu.result.dhuha}\nDzuhur: ${anu.result.dzuhur}\nAshar: ${anu.result.ashar}\nMagrib: ${anu.result.maghrib}\nIsya: ${anu.result.isya}`)
            }
            break
 case 'jadwaltv': {
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} rcti`)
			    try {
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/jadwaltv/${args[0]}?apikey=GataDios`)
			m.reply(mess.wait)
			var titttt = `Jadwal TV ${args[0].toUpperCase()}\n`
			for (var x in data.result) {
				titttt += `${x} - ${data.result[x]}\n`
			}
			m.reply(titttt)
					    } catch (error) {
        m.reply('Error Coba Lagi');
    }
			}
			break
//TES
// ===================================== //
case 'asupanvideo': {
if (!isPrem) return replyprem(mess.prem)
m.reply(mess.wait)
let pidio = await getBuffer(`https://api.xyroinee.xyz/api/asupan/video/random?apikey=${apikey}`)
sky.sendMessage(m.chat, { video: { url: pidio }, caption: `_Nih Kak_` }, { quoted: m })
}
break
		    case 'jadwaltvnow': {
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/jadwaltv/now?apikey=GataDios`)	
			var tittttt = `Jadwal TV Now :\n`
			for (var x in data.result) {
				tittttt += `${x.toUpperCase()}${data.result[x]}\n\n`
			}
			m.reply(tittttt)
			}
			break
case 'cnnindonesia':{
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/cnnindonesia?apikey=GataDios`)
			m.reply(mess.wait)
			var tittttttt = 'Result :\n'
			for (var x of data.result) {
				tittttttt += `Judul : ${x.judul}\n`
				tittttttt += `Link : ${x.link}\n`
				tittttttt += `Tipe : ${x.tipe}\n`
				tittttttt += `Published : ${x.waktu}\n\n`
			}
			m.reply(tittttttt)
			}
			break
			
		    case 'cnnnasional':{
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/cnnindonesia/nasional?apikey=GataDios`)
			m.reply(mess.wait)
			var titttttttt = 'Result :\n'
			for (var x of data.result) {
				titttttttt += `Judul : ${x.judul}\n`
				titttttttt += `Link : ${x.link}\n`
				titttttttt += `Tipe : ${x.tipe}\n`
				titttttttt += `Published : ${x.waktu}\n\n`
			}
			m.reply(titttttttt)
			}
			break
			
		    case 'cnninternasional':{
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/cnnindonesia/internasional?apikey=GataDios`)
			m.reply(mess.wait)
			var tittttttttt = 'Result :\n'
			for (var x of data.result) {
				tittttttttt += `Judul : ${x.judul}\n`
				tittttttttt += `Link : ${x.link}\n`
				tittttttttt += `Tipe : ${x.tipe}\n`
				tittttttttt += `Published : ${x.waktu}\n\n`
			}
			m.reply(tittttttttt)
			}
			break
			
		    case 'infogempa':
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/infogempa?apikey=GataDios`)
			m.reply(mess.wait)
			var caption = `Lokasi : ${data.result.lokasi}\n`
			caption += `Waktu : ${data.result.waktu}\n`
			caption += `Potensi : ${data.result.potensi}\n`
			caption += `Magnitude : ${data.result.magnitude}\n`
			caption += `Kedalaman : ${data.result.kedalaman}\n`
			caption += `Koordinat : ${data.result.koordinat}`
			sky.sendMessage(m.chat, { image: { url: data.result.map }, caption })
			break
			
		    			case 'keywords': {
    if (!text) {
        return m.reply(`Berikan keyword atau URL situs web untuk mendapatkan daftar kata kunci yang sering dicari.\n\nContoh: ${prefix + command} url`);
    }

    axios.get(`https://api.serpstat.com/v3/keywords_data?query=${encodeURIComponent(text)}&token=e0724f58e05184b71d71f345d6ef824e`)
        .then(response => {
            const keywords = response.data.keywords_data.keywords;

            if (keywords.length > 0) {
                const topKeywords = keywords.slice(0, 5).map(keyword => keyword.keyword).join(', ');
                m.reply(`Beberapa kata kunci yang sering dicari pada ${text}: ${topKeywords}`);
            } else {
                m.reply(`Tidak ada data kata kunci yang tersedia.`);
            }
        })
        .catch(error => {
            m.reply('Terjadi kesalahan saat mengambil data kata kunci. Silakan coba lagi nanti.');
        });
}
break;
		    case 'infocuaca':{
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} Yogyakarta`)
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/cuaca/${args[0]}?apikey=GataDios`)
			var titttttttttt = `Tempat : ${data.result.tempat}\n`
			titttttttttt += `Cuaca : ${data.result.cuaca}\n`
			titttttttttt += `Angin : ${data.result.angin}\n`
			titttttttttt += `Description : ${data.result.description}\n`
			titttttttttt += `Kelembapan : ${data.result.kelembapan}\n`
			titttttttttt += `Suhu : ${data.result.suhu}\n`
			titttttttttt += `Udara : ${data.result.udara}\n`
			titttttttttt += `Permukaan laut : ${data.result.permukaan_laut}\n`
			sky.sendMessage(m.chat, { location: { degreesLatitude: data.result.latitude, degreesLongitude: data.result.longitude } })
			m.reply(titttttttttt)
			}
			break
            case 'rst': {
await sky.sendMessage(from, {text: `_Restarting`})
await sky.sendMessage(from, {text: "_Succes_"})
await sleep(1000)
process.send('reset') 
}
break
			case 'kodepos':
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} Slemanan or ${prefix + command} 66154`)
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/kodepos?apikey=GataDios&query=${args}`)
			var tittttttttttt = `Provinsi : ${data.result[0].province}\n`
			tittttttttttt += `Kabupaten : ${data.result[0].city}\n`
			tittttttttttt += `Kecamatan : ${data.result[0].subdistrict}\n`
			tittttttttttt += `Kelurahan : ${data.result[0].urban}\n`
			tittttttttttt += `Kode Pos : ${data.result[0].postalcode}`
			m.reply(tittttttttttt)
			break
			
		    case 'jadwalbola': {
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/jadwalbola?apikey=GataDios`)
			m.reply(mess.wait)
			var titttttttttttt = 'Jadwal Bola :\n'
			for (var x of data.result) {
				titttttttttttt += `Pada : ${x.time}\n`
				titttttttttttt += `Event : ${x.event}\n`
				titttttttttttt += `Match : ${x.match}\n`
				titttttttttttt += `TV : ${x.tv}\n\n`
			}
			m.reply(titttttttttttt)
			}
			break
        // Fun Fitur 
        
            case 'apakah': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} text\n\nContoh : ${command} saya wibu`)
                const apa = ['Iya', 'Tidak', 'Bisa Jadi', 'Betul']
                const kah = apa[Math.floor(Math.random() * apa.length)]
                m.reply(`Pertanyaan : Apakah ${q}\nJawaban : ${kah}`)
                }
                break
            case 'bisakah': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} text\n\nContoh : ${command} saya wibu`)
                const bisa = ['Bisa', 'Gak Bisa', 'Gak Bisa Ajg Aaokawpk', 'TENTU PASTI KAMU BISA!!!!']
                const ga = bisa[Math.floor(Math.random() * bisa.length)]
                m.reply(`Pertanyaan : Apakah ${q}\nJawaban : ${ga}`)
                }
                break
            case 'bagaimanakah': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} text\n\nContoh : ${command} saya wibu`)
                const gimana = ['Gak Gimana2', 'Sulit Itu Bro', 'Maaf Bot Tidak Bisa Menjawab', 'Coba Deh Cari Di Gugel', 'astaghfirallah Beneran???', 'Pusing ah', 'Owhh Begitu:(', 'Yang Sabar Ya Bos:(', 'Gimana yeee']
                const ya = gimana[Math.floor(Math.random() * gimana.length)]
                m.reply(`Pertanyaan : Apakah ${q}\nJawaban : ${ya}`)
                }
            break
            case 'rate': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} text\n\nContoh : ${command} Gambar aku`)
                const ra = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
                const te = ra[Math.floor(Math.random() * ra.length)]
                m.reply(`Rate : ${q}\nJawaban : *${te}%*`)
                }
            break           
            case 'gantengcek':
            case 'cekganteng': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} Nama\n\nContoh : ${command} Owner`)
                const gan = ['10% banyak" perawatan ya bang:v\nCanda Perawatan:v','30% Semangat bang Merawat Dirinya><','20% Semangat Ya bang👍','40% Wahh bang><','50% abang Ganteng deh><','60% Hai Ganteng🐊','70% Hai Ganteng🐊','62% Bang Ganteng><','74% abang ni ganteng deh><','83% Love You abang><','97% Assalamualaikum Ganteng🐊','100% Bang Pake Susuk ya??:v','29% Semangat Bang:)','94% Hai Ganteng><','75% Hai Bang Ganteng','82% wihh abang Pasti Sering Perawatan kan??','41% Semangat:)','39% Lebih Semangat🐊']
                const teng = gan[Math.floor(Math.random() * gan.length)]
                m.reply(`Nama : ${q}\nJawaban : *${teng}%`)
                }
            break
                
            case 'cantikcek':
            case 'cekcantik': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} Nama\n\nContoh : ${command} Akame`)
                const can = ['10% banyak" perawatan ya kak:v\nCanda Perawatan:v','30% Semangat Kaka Merawat Dirinya><','20% Semangat Ya Kaka👍','40% Wahh Kaka><','50% kaka cantik deh><','60% Hai Cantik🐊','70% Hai Ukhty🐊','62% Kakak Cantik><','74% Kakak ni cantik deh><','83% Love You Kakak><','97% Assalamualaikum Ukhty🐊','100% Kakak Pake Susuk ya??:v','29% Semangat Kakak:)','94% Hai Cantik><','75% Hai Kakak Cantik','82% wihh Kakak Pasti Sering Perawatan kan??','41% Semangat:)','39% Lebih Semangat🐊']
                const tik = can[Math.floor(Math.random() * can.length)]
                m.reply(`Nama : ${q}\nJawaban : *${tik}%`)
                }
            break
            
            case 'sangecek':
            case 'ceksange':
            case 'gaycek':
            case 'cekgay':
            case 'lesbicek':
            case 'ceklesbi': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} Nama\n\nContoh : ${command} ${pushname}`)
                const sangeh = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
                const sange = sangeh[Math.floor(Math.random() * sangeh.length)]
                m.reply(`Nama : ${q}\nJawaban : *${sange}%*`)
                }
            break
case 'runtime': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            	let lowq = `*The Bot Has Been Online For:*\n*${runtime(process.uptime())}*`
                m.reply(lowq)
            	}
            break                
            case 'kapankah': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} Pertanyaan\n\nContoh : ${command} Saya Mati`)
                const kapan = ['5 Hari Lagi', '10 Hari Lagi', '15 Hari Lagi', '20 Hari Lagi', '25 Hari Lagi', '30 Hari Lagi', '35 Hari Lagi', '40 Hari Lagi', '45 Hari Lagi', '50 Hari Lagi', '55 Hari Lagi', '60 Hari Lagi', '65 Hari Lagi', '70 Hari Lagi', '75 Hari Lagi', '80 Hari Lagi', '85 Hari Lagi', '90 Hari Lagi', '95 Hari Lagi', '100 Hari Lagi', '5 Bulan Lagi', '10 Bulan Lagi', '15 Bulan Lagi', '20 Bulan Lagi', '25 Bulan Lagi', '30 Bulan Lagi', '35 Bulan Lagi', '40 Bulan Lagi', '45 Bulan Lagi', '50 Bulan Lagi', '55 Bulan Lagi', '60 Bulan Lagi', '65 Bulan Lagi', '70 Bulan Lagi', '75 Bulan Lagi', '80 Bulan Lagi', '85 Bulan Lagi', '90 Bulan Lagi', '95 Bulan Lagi', '100 Bulan Lagi', '1 Tahun Lagi', '2 Tahun Lagi', '3 Tahun Lagi', '4 Tahun Lagi', '5 Tahun Lagi', 'Besok', 'Lusa', `Abis Command Ini Juga Lu ${q}`]
                const kapankah = kapan[Math.floor(Math.random() * kapan.length)]
                m.reply(`Pertanyaan : ${q}\nJawaban : *${kapankah}*`)
                }
            break
            
            case 'wangy': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Contoh : .wangy Riy`)
                qq = q.toUpperCase()
                awikwok = `${qq} ${qq} ${qq} ❤️ ❤️ ❤️ WANGY WANGY WANGY WANGY HU HA HU HA HU HA, aaaah baunya rambut ${qq} wangyy aku mau nyiumin aroma wangynya ${qq} AAAAAAAAH ~ Rambutnya.... aaah rambutnya juga pengen aku elus-elus ~~ AAAAAH ${qq} keluar pertama kali di anime juga manis ❤️ ❤️ ❤️ banget AAAAAAAAH ${qq} AAAAA LUCCUUUUUUUUUUUUUUU............ ${qq} AAAAAAAAAAAAAAAAAAAAGH ❤️ ❤️ ❤️apa ? ${qq} itu gak nyata ? Cuma HALU katamu ? nggak, ngak ngak ngak ngak NGAAAAAAAAK GUA GAK PERCAYA ITU DIA NYATA NGAAAAAAAAAAAAAAAAAK PEDULI BANGSAAAAAT !! GUA GAK PEDULI SAMA KENYATAAN POKOKNYA GAK PEDULI. ❤️ ❤️ ❤️ ${qq} gw ... ${qq} di laptop ngeliatin gw, ${qq} .. kamu percaya sama aku ? aaaaaaaaaaah syukur ${q} aku gak mau merelakan ${qq} aaaaaah ❤️ ❤️ ❤️ YEAAAAAAAAAAAH GUA MASIH PUNYA ${qq} SENDIRI PUN NGGAK SAMA AAAAAAAAAAAAAAH`
                m.reply(awikwok)
                }
            break                      
case 'cekmati': {
  const nama = m.body.split(' ')[1]; // Mengambil nama dari pesan
  if (!nama) {
    m.reply('Silakan masukkan nama seseorang untuk memulai permainan.');
    return;
  }
  // Menghasilkan umur secara acak antara 1 hingga 100 tahun
  const umur = Math.floor(Math.random() * 100) + 1;
  m.reply(`Hasil cek mati untuk ${nama} \n\nNama: ${nama}\nMati Pada Umur : ${umur} tahun`);
  break;
}
 	             
            case 'joins': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) throw mess.owner
                if (!text) throw 'Masukkan Link Group!'
                if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) throw 'Link Invalid!'
                m.reply(mess.wait)
                let result = args[0].split('https://chat.whatsapp.com/')[1]
                await sky.groupAcceptInvite(result).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
            }
            break
            case 'setexif': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
               if (!isCreator) throw mess.owner
               if (!text) throw `Example : ${prefix + command} packname|author`
          global.packname = text.split("|")[0]
          global.author = text.split("|")[1]
          m.reply(`Exif berhasil diubah menjadi\n\n⭔ Packname : ${global.packname}\n⭔ Author : ${global.author}`)
            }
            break
case 'berkelahi':
  if (!users[m.sender]) {
    users[m.sender] = {
      nama: m.sender,
      skor: 0,
    };
  }

  // Generate skor acak antara 1 hingga 10
  const skorPengguna = Math.floor(Math.random() * 10) + 1;
  const skorBot = Math.floor(Math.random() * 10) + 1;

  const skorSebelumnya = users[m.sender].skor; // Simpan skor sebelumnya
  users[m.sender].skor += skorPengguna; // Tambahkan skor baru

  if (skorPengguna > skorBot) {
    m.reply(`Anda menang! Skor Anda bertambah: ${skorPengguna}. Skor total Anda: ${users[m.sender].skor}`);
  } else if (skorBot > skorPengguna) {
    m.reply(`Anda kalah! Skor Anda berkurang: ${skorSebelumnya - users[m.sender].skor}. Skor total Anda: ${users[m.sender].skor}`);
  } else {
    m.reply(`Seri! Skor Anda tidak berubah. Skor total Anda: ${users[m.sender].skor}`);
  }

  break;
// Case untuk melihat skor pengguna
case 'skor':
  if (users[m.sender]) {
    m.reply(`${users[m.sender].nama}, skor Anda saat ini: ${users[m.sender].skor}`);
  } else {
    m.reply(`Anda belum bermain. Ketik *berkelahi* untuk bermain.`);
  }
  break;

	case 'kick': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!m.isGroup) throw mess.group
        if (!isBotAdmins) throw mess.botAdmin
        if (!isAdmins) throw mess.admin
		let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [text.replace(/[^0-9]/g, '')+'@s.whatsapp.net']
		await sky.groupParticipantsUpdate(m.chat, users, 'remove').then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
	}
	break
case 'add': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await sky.groupParticipantsUpdate(m.chat, [users], 'add').then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
}
break
case 'closetime': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
if (!m.isGroup) throw mess.group
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
if (!isBotAdmins) return XeonStickBotAdmin()
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
} else {
return m.reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
}
m.reply(`Close Time ${q} Starting from now`)
setTimeout(() => {
var nomor = m.participant
const close = `*On time* Group Closed By Admin\nNow Only Admins Can Send Messages`
sky.groupSettingUpdate(from, 'announcement')
m.reply(close)
}, timer)
}
break
case 'opentime': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
if (!m.isGroup) throw mess.group
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
if (!isBotAdmins) return XeonStickBotAdmin()
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
} else {
return m.reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
}
m.reply(`Open Time ${q} Starting from now`)
setTimeout(() => {
var nomor = m.participant
const open = `*On time* Group Opened By Admin\n Now Members Can Send Messages`
sky.groupSettingUpdate(from, 'not_announcement')
m.reply(open)
}, timer)
}
break
	case 'promote': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!m.isGroup) throw mess.group
        if (!isBotAdmins) throw mess.botAdmin
        if (!isAdmins) throw mess.admin
		let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [text.replace(/[^0-9]/g, '')+'@s.whatsapp.net']
		await sky.groupParticipantsUpdate(m.chat, users, 'promote').then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
	}
	break
case 'randompromote': {
  if (!isAdmins) throw mess.admin;
  if (!isGroup) throw mess.onlygroup;
  if (!args[0]) throw `Gunakan: *${prefix}randompromote [jumlah anggota yang ingin dipromosikan]*`;

  const jumlahPromote = parseInt(args[0]);
  if (isNaN(jumlahPromote) || jumlahPromote <= 0) throw 'Jumlah anggota yang ingin dipromosikan harus berupa angka positif.';

  const participants = await sky.groupMetadata(from);
  const participantList = participants.participants;

  for (let i = 0; i < Math.min(jumlahPromote, participantList.length); i++) {
    const randomIndex = Math.floor(Math.random() * participantList.length);
    const participant = participantList[randomIndex];

    if (!participant.isAdmin) {
      const users = [participant.id];
      const result = await sky.groupParticipantsUpdate(m.chat, users, 'promote');
      
      await new Promise(resolve => setTimeout(resolve, 1000)); // Jeda sebelum mempromosikan anggota berikutnya
    }
  }

  m.reply(`Berhasil mempromosikan ${Math.min(jumlahPromote, participantList.length)} anggota secara random menjadi admin grup.`);
  break;
}
	case 'demote': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!m.isGroup) throw mess.group
        if (!isBotAdmins) throw mess.botAdmin
        if (!isAdmins) throw mess.admin
		let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [text.replace(/[^0-9]/g, '')+'@s.whatsapp.net']
		await sky.groupParticipantsUpdate(m.chat, users, 'demote').then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
	}
	break
        case 'block': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!isCreator) throw mess.owner
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await sky.updateBlockStatus(users, 'block')
		await m.reply(`Done`)
	}
	break
        case 'unblock': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!isCreator) throw mess.owner
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await sky.updateBlockStatus(users, 'unblock')
		await m.reply(`Done`)
	}
	break
	    case 'setname': case 'setsubject': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
                if (!text) throw 'Text ?'
                await sky.groupUpdateSubject(m.chat, text).then((res) => m.reply(mess.success)).catch((err) => m.reply(jsonformat(err)))
            }
            break
          case 'setdesc': case 'setdesk': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
                if (!text) throw 'Text ?'
                await sky.groupUpdateDescription(m.chat, text).then((res) => m.reply(mess.success)).catch((err) => m.reply(jsonformat(err)))
            }
            break
          case 'setppbot': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) throw mess.owner
                if (!/image/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
                if (/webp/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
                let media = await sky.downloadAndSaveMediaMessage(qmsg)
                await sky.updateProfilePicture(botNumber, { url: media }).catch((err) => fs.unlinkSync(media))
                m.reply(mess.success)
                }
                break
           case 'setppgroup': case 'setppgrup': case 'setppgc': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isAdmins) throw mess.admin
                if (!/image/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
                if (/webp/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
                let media = await sky.downloadAndSaveMediaMessage(qmsg)
                await sky.updateProfilePicture(m.chat, { url: media }).catch((err) => fs.unlinkSync(media))
                m.reply(mess.success)
                }
                break
case 'berburu': {
    if (m.mentionedJid.length !== 3) {
        return await m.reply('Tag 3 pengguna untuk memulai permainan berburu bersama.');
    }

    const players = m.mentionedJid;
    const maxRounds = 3;
    const playerScores = {};

    players.forEach(player => {
        playerScores[player] = 0;
    });

    const animals = ['elang', 'beruang', 'harimau', 'kijang', 'gajah', 'singa', 'serigala', 'kuda', 'kucing', 'ular'];
    const actions = ['menembak', 'mengejar', 'mengamati', 'menyelinap'];
    const obstacles = ['banjir', 'badai', 'kawanan serigala', 'jalur buntu', 'gunung berapi'];

    async function playRound(player) {
        const animal = animals[Math.floor(Math.random() * animals.length)];
        const action = actions[Math.floor(Math.random() * actions.length)];
        const difficulty = Math.random();
        let points = Math.floor(Math.random() * 21) + 10;

        if (difficulty < 0.2) {
            const obstacle = obstacles[Math.floor(Math.random() * obstacles.length)];
            await m.reply(`Oh tidak! @${player.split('@')[0]}, Anda terperangkap dalam ${obstacle} saat ${action} ${animal}. Upaya Anda terhambat dan Anda hanya mendapatkan setengah poin.`);
            points = Math.floor(points / 2);
        } else if (difficulty < 0.5) {
            await m.reply(`@${player.split('@')[0]}, Anda terjebak dalam semak belukar saat ${action} ${animal}. Upaya Anda terganggu dan Anda mendapatkan sedikit poin.`);
            points = Math.floor(points * 0.75);
        } else {
            await m.reply(`Di hutan yang lebat, @${player.split('@')[0]} sedang ${action} seekor ${animal}! ${action.charAt(0).toUpperCase() + action.slice(1)} dengan tepat dan Anda mendapatkan ${points} poin!`);
        }

        playerScores[player] += points;
    }

    await m.reply(`Selamat datang di permainan Berburu Bersama!\n\nPemain yang berpartisipasi: ${players.map(player => `@${player.split('@')[0]}`).join(', ')}`);

    for (let round = 1; round <= maxRounds; round++) {
        await m.reply(`Ronde ${round} dimulai!`);

        for (let i = 0; i < players.length; i++) {
            await playRound(players[i]);
        }
    }

    let result = 'Permainan Berburu Bersama berakhir!\n\nSkor Akhir:\n';

    players.forEach(player => {
        result += `@${player.split('@')[0]}: ${playerScores[player]} poin\n`;
    });

    const winner = Object.keys(playerScores).reduce((a, b) => playerScores[a] > playerScores[b] ? a : b);
    result += `\nSelamat kepada @${winner.split('@')[0]} yang memenangkan permainan dengan total skor ${playerScores[winner]} poin!`;

    await m.reply(result);
}
break;

case 'balapan': {
    if (!m.mentionedJid || m.mentionedJid.length !== 1) {
        return await m.reply('Tag satu pengguna untuk memulai permainan balapan.')
    }
m.reply('Game Made By Avosky')
    let user = m.mentionedJid[0]
    let userDistance = 0
    let botDistance = 0
    let finishLine = 100 // Jarak garis finish
    let maxRounds = 15 // Jumlah ronde maksimal
    let round = 1
    
    let result = `🏃‍♂️ Mulai permainan balapan dengan @${user.split('@')[0]} 🏃‍♂️\n\n`

    while (round <= maxRounds && userDistance < finishLine && botDistance < finishLine) {
        let userStep = Math.floor(Math.random() * 10) + 1 // Langkah pengguna
        let botStep = Math.floor(Math.random() * 10) + 1 // Langkah bot

        // Rintangan
        if (Math.random() < 0.1) {
            userDistance -= userStep
            result += `🚫 @${user.split('@')[0]} mengalami kecelakaan! Mundur ${userStep} langkah. Jarak: ${userDistance}\n`
        } else {
            userDistance += userStep
            result += `🏁 @${user.split('@')[0]} melangkah ${userStep} langkah. Jarak: ${userDistance}\n`
        }

        if (Math.random() < 0.1) {
            botDistance -= botStep
            result += `🚫 Kamu mengalami kecelakaan! Mundur ${botStep} langkah. Jarak: ${botDistance}\n`
        } else {
            botDistance += botStep
            result += `🏁 Kamu melangkah ${botStep} langkah. Jarak: ${botDistance}\n`
        }

        // Rintangan tambahan
        if (userDistance > 0 && Math.random() < 0.05) {
            userDistance -= 5
            result += `❌ @${user.split('@')[0]} habis bahan bakar! Mundur 5 langkah. Jarak: ${userDistance}\n`
        }

        if (botDistance > 0 && Math.random() < 0.05) {
            botDistance -= 5
            result += `❌ Kamu habis bahan bakar! Mundur 5 langkah. Jarak: ${botDistance}\n`
        }

        result += '\n'
        round++
    }

    result += `\n🏆 Pertandingan selesai!\nJarak akhir: @${user.split('@')[0]} ${userDistance} - Bot ${botDistance}\n`

    if (userDistance > botDistance) {
        result += `\n🎉 @${user.split('@')[0]} memenangkan permainan balapan!`
    } else if (botDistance > userDistance) {
        result += `\n😢 Kamu memenangkan permainan balapan!`
    } else {
        result += `\n⚖️ Pertandingan balapan berakhir imbang!`
    }

    await m.reply(result)
}
break
case 'aduikan': {
    if (!m.mentionedJid || m.mentionedJid.length !== 1) {
        return await m.reply('Tag satu pengguna untuk memulai permainan adu ikan.')
    }
m.reply('Game Made By Avosky')
    let user = m.mentionedJid[0]
    let userScore = 0
    let botScore = 0
    let maxRounds = 15 // Jumlah ronde maksimal
    let round = 1
    
    let result = `🐟 Mulai permainan adu ikan dengan @${user.split('@')[0]} 🐟\n\n`

    while (round <= maxRounds) {
        let userCatch = Math.random() < 0.6 // Kemungkinan pengguna menangkap ikan
        let botCatch = Math.random() < 0.6 // Kemungkinan bot menangkap ikan

        if (userCatch && !botCatch) {
            userScore++
            result += `🎣 @${user.split('@')[0]} berhasil menangkap ikan! (+1 poin)\n`
        } else if (!userCatch && botCatch) {
            botScore++
            result += '🎣 Kamu berhasil menangkap ikan! (+1 poin)\n'
        } else {
            result += '🎣 Ikan lepas\n'
        }

        round++
    }

    result += `\n⏱️ Pertandingan selesai! Total skor: @${user.split('@')[0]} ${userScore} - Kamu ${botScore}`

    if (userScore > botScore) {
        result += `\n🎉 @${user.split('@')[0]} memenangkan permainan adu ikan!`
    } else if (botScore > userScore) {
        result += `\n😢 Kamu memenangkan permainan adu ikan!`
    } else {
        result += `\n⚖️ Pertandingan adu ikan berakhir imbang!`
    }

    await m.reply(result)
}
break
case 'bertarung': {
    if (!m.mentionedJid || m.mentionedJid.length !== 1) {
        return await m.reply('Tag satu pengguna untuk memulai permainan bertarung.')
    }
m.reply('Game Made By Avosky')
    let user = m.mentionedJid[0];
    let userHealth = 200;
    let botHealth = 200;
    let maxRounds = 10; // Jumlah ronde maksimal

    const actions = [
        { name: 'pukulan keras', damage: 15 },
        { name: 'tendangan tinggi', damage: 20 },
        { name: 'serangan combo', damage: 25 },
        { name: 'tendangan berputar', damage: 30 },
        { name: 'pukulan ke perut', damage: 18 },
        { name: 'tendangan ke arah kaki', damage: 23 },
        { name: 'pukulan akrobatik', damage: 28 },
        { name: 'serangan seribu tangan', damage: 35 },
        { name: 'tendangan meteor', damage: 40 },
    ];

    let result = `🥊 Pertarungan dimulai dengan @${user.split('@')[0]}! 🥊\n\n`;

    for (let round = 1; round <= maxRounds; round++) {
        result += `🔥 Ronde ${round}\n\n`;

        let userAttack = actions[Math.floor(Math.random() * actions.length)];
        let botAttack = actions[Math.floor(Math.random() * actions.length)];

        userHealth -= botAttack.damage;
        botHealth -= userAttack.damage;

        result += `⚔️ @${user.split('@')[0]} melancarkan ${userAttack.name} pada Kamu!\n`;
        result += `⚔️ Kamu melancarkan ${botAttack.name} pada @${user.split('@')[0]}!\n`;

        result += `❤️ Kesehatan @${user.split('@')[0]}: ${userHealth} | Kamu: ${botHealth}\n\n`;

        if (userHealth <= 0 || botHealth <= 0) {
            break;
        }
    }

    result += `\n🛌 Pertarungan berakhir!\n`;

    if (userHealth > botHealth) {
        result += `\n🎉 @${user.split('@')[0]} keluar sebagai pemenang pertarungan!`;
    } else if (botHealth > userHealth) {
        result += `\n😢 Kamu berhasil mengalahkan @${user.split('@')[0]} dalam pertarungan yang sengit!`;
    } else {
        result += `\n⚖️ Pertarungan berakhir imbang, kedua pihak pantas mendapatkan penghargaan!`;
    }

    await m.reply(result);
}
break;
case 'adumasak': {
    if (!m.mentionedJid || m.mentionedJid.length !== 1) {
        return await m.reply('Tag satu pengguna untuk memulai permainan adu memasak.')
    }
m.reply('Game Made By Avosky')
    let user = m.mentionedJid[0];
    let userScore = 0;
    let botScore = 0;
    let maxRounds = 5; // Jumlah ronde maksimal

    const ingredients = [
        { name: 'bawang merah', effect: 'menangis', points: -10 },
        { name: 'gula pasir', effect: 'manis', points: 5 },
        { name: 'cabe rawit', effect: 'pedas', points: 15 },
        { name: 'mentega', effect: 'lembut', points: 10 },
        { name: 'keju parmesan', effect: 'gurih', points: 20 },
    ];

    let result = `🍳 Adu memasak dimulai dengan @${user.split('@')[0]}! 🍳\n\n`;

    for (let round = 1; round <= maxRounds; round++) {
        let userIngredient = ingredients[Math.floor(Math.random() * ingredients.length)];
        let botIngredient = ingredients[Math.floor(Math.random() * ingredients.length)];

        result += `🍽️ Ronde ${round}\n\n`;
        result += `👩‍🍳 @${user.split('@')[0]} memasukkan ${userIngredient.name} ke dalam masakannya, efeknya ${userIngredient.effect}!\n`;
        result += `🤖 Kamu memasukkan ${botIngredient.name} ke dalam masakannya, efeknya ${botIngredient.effect}!\n`;

        if (userIngredient.points > botIngredient.points) {
            userScore++;
            result += `🎉 @${user.split('@')[0]} memenangkan ronde ini!\n\n`;
        } else if (botIngredient.points > userIngredient.points) {
            botScore++;
            result += `😢 Kamu memenangkan ronde ini!\n\n`;
        } else {
            result += `⚖️ Ronde ini berakhir imbang!\n\n`;
        }
    }

    result += `\n🍲 Permainan adu memasak berakhir!\n\n`;
    result += `🏆 Skor Akhir: @${user.split('@')[0]} ${userScore} - Kamu ${botScore}\n`;

    if (userScore > botScore) {
        result += `\n🎉 @${user.split('@')[0]} keluar sebagai pemenang adu memasak!`;
    } else if (botScore > userScore) {
        result += `\n😢 Kamu berhasil mengalahkan @${user.split('@')[0]} dalam adu memasak yang unik ini!`;
    } else {
        result += `\n⚖️ Pertandingan berakhir imbang, kedua pihak mendapatkan penghargaan!`;
    }

    await m.reply(result);
}
break;
case 'berantem': {
    if (!m.mentionedJid || m.mentionedJid.length !== 1) {
        return await m.reply('Tag satu pengguna untuk memulai permainan berantem.')
    }
m.reply('Game Made By Avosky')
    let user = m.mentionedJid[0]
    let userHealth = 200
    let botHealth = 200
    let maxRounds = 20 // Jumlah ronde maksimal
    let round = 1

    const actions = [
        'punch', 'kick', 'slap', 'headbutt', 'elbow strike', 'body slam', 'throw',
        'counter attack', 'charge', 'uppercut', 'roundhouse kick', 'flying kick'
    ];

    const outcomes = [
        `terjatuh dan sakit keras!`, `hampir kehilangan keseimbangan!`,
        `tertunduk lemas.`, `memijak kaki sendiri!`, `terjatuh ke belakang!`
    ];
    
    let result = `🥊 Mulai permainan berantem dengan @${user.split('@')[0]} 🥊\n\n`;

    while (round <= maxRounds && userHealth > 0 && botHealth > 0) {
        let userAction = actions[Math.floor(Math.random() * actions.length)];
        let botAction = actions[Math.floor(Math.random() * actions.length)];

        let userDamage = Math.floor(Math.random() * 20) + 1;
        let botDamage = Math.floor(Math.random() * 20) + 1;

        userHealth -= botDamage;
        botHealth -= userDamage;

        let userOutcome = outcomes[Math.floor(Math.random() * outcomes.length)];
        let botOutcome = outcomes[Math.floor(Math.random() * outcomes.length)];

        result += `👊 @${user.split('@')[0]} melakukan ${userAction} dan ${userOutcome}\n`;
        result += `👊 Kamu melakukan ${botAction} dan ${botOutcome}\n`;

        result += `🩸 Kesehatan @${user.split('@')[0]}: ${userHealth} | Kamu: ${botHealth}\n\n`;

        round++;
    }

    result += `\n🛌 Pertandingan berakhir! Kesehatan akhir: @${user.split('@')[0]} ${userHealth} - Kamu ${botHealth}\n`;

    if (userHealth > botHealth) {
        result += `\n🎉 @${user.split('@')[0]} memenangkan pertandingan berantem!`;
    } else if (botHealth > userHealth) {
        result += `\n😢 Kamu memenangkan pertandingan berantem!`;
    } else {
        result += `\n⚖️ Pertandingan berantem berakhir imbang!`;
    }

    await m.reply(result);
}
break;
case 'adulayangan': {
    if (!m.mentionedJid || m.mentionedJid.length !== 1) {
        return await m.reply('Tag satu pengguna untuk memulai permainan adu layangan.')
    }
m.reply('Game Made By Avosky')
    let user = m.mentionedJid[0]
    let userScore = 0
    let botScore = 0
    
    let result = `🪁 Mulai permainan adu layangan dengan @${user.split('@')[0]} 🪁\n\n`

    while (userScore < 5 && botScore < 5) {
        let userRoll = Math.floor(Math.random() * 6) + 1 // Lemparan pengguna
        let botRoll = Math.floor(Math.random() * 6) + 1 // Lemparan bot

        if (userRoll > botRoll) {
            userScore++
            result += `🪁 @${user.split('@')[0]} menang lemparan! (+1 poin)\n`
        } else if (botRoll > userRoll) {
            botScore++
            result += '🪁 Kamu menang lemparan! (+1 poin)\n'
        } else {
            result += '🪁 Lemparan seri!\n'
        }
    }

    if (userScore > botScore) {
        result += `\n🎉 @${user.split('@')[0]} memenangkan permainan adu layangan!`
    } else {
        result += '\n😢 Kamu memenangkan permainan adu layangan!'
    }

    await m.reply(result)
}
break
case 'aduhewan': {
    const args = q.split(' ');
    if (!args[0]) {
        throw `Contoh penggunaan: ${prefix + command} [hewanmu]`;
    }

    const userAnimal = args[0].toLowerCase(); // Hewan pengguna

    const botAnimals = ['anjing', 'harimau', 'gajah', 'singa', 'beruang', 'ular', 'kuda']; // Hewan lawan yang bisa dipilih
    const botAnimal = botAnimals[Math.floor(Math.random() * botAnimals.length)]; // Hewan lawan dipilih secara acak

    let userLives = 20; // Nyawa pengguna
    let botLives = 20; // Nyawa lawan
    let result = `🐾 Pertarungan ${userAnimal} vs ${botAnimal} dimulai! 🐾\n\n`;

    while (userLives > 0 && botLives > 0) {
        let userAttack = Math.floor(Math.random() * 8) + 1; // Serangan pengguna
        let botAttack = Math.floor(Math.random() * 8) + 1; // Serangan lawan

        const userInjured = Math.random() < 0.2; // Peluang hewan pengguna cedera
        const botInjured = Math.random() < 0.2; // Peluang hewan lawan cedera

        if (userInjured) userLives -= 3;
        else userLives -= botAttack;

        if (botInjured) botLives -= 3;
        else botLives -= userAttack;

        if (userInjured) {
            result += `❗ ${userAnimal} mu cedera\n`;
        } else {
            result += `💥 ${userAnimal} mu menyerang ${botAnimal} (-${botAttack} nyawa ${botAnimal})\n`;
        }

        if (botInjured) {
            result += `❗ ${botAnimal} cedera\n`;
        } else {
            result += `💥 ${botAnimal} menyerang ${userAnimal} (-${userAttack} nyawa ${userAnimal})\n`;
        }

        result += '\n';
    }

    if (userLives > botLives) {
        result += `🏆 ${userAnimal} mu menang !!!`;
    } else if (botLives > userLives) {
        result += `🏆 ${botAnimal} menang !!!`;
    } else {
        result += '🏆 Pertandingan seri';
    }

    m.reply(result);
}
break;
case 'aduayam': {
    let userChicken = 5 // Jumlah nyawa ayam pengguna
    let botChicken = 5 // Jumlah nyawa ayam bot
m.reply('Game Made By Avosky')    
    let result = '🐓 Ayam sedang bertarung 🐓\n\n'

    while (userChicken > 0 && botChicken > 0) {
        let userAttack = Math.floor(Math.random() * 3) + 1 // Serangan pengguna
        let botAttack = Math.floor(Math.random() * 3) + 1 // Serangan bot

        userChicken -= botAttack
        botChicken -= userAttack

        if (userChicken <= 0) {
            result += '🐓 Ayam mu terluka\n'
        } else {
            result += `🐓 Ayam mu menendang ayam bot (-${botAttack} nyawa bot)\n`
        }

        if (botChicken <= 0) {
            result += '🐓 Ayam bot terluka\n'
        } else {
            result += `🐓 Ayam bot menendang ayam mu (-${userAttack} nyawa kamu)\n`
        }
        
        result += '\n'
    }

    if (userChicken > botChicken) {
        result += '🐓 Ayam mu menang !!!'
    } else if (botChicken > userChicken) {
        result += '🐓 Ayam bot menang !!!'
    } else {
        result += '🐓 Pertandingan seri'
    }

    m.reply(result)
}
break
case 'qq': {
    if (db.data.users[m.sender].balance <= 100) {
        m.reply("Maaf, balance kamu sudah habis. Main lagi setelah menambahkan balance.");
        break;
    }

    const userChoice = Math.floor(Math.random() * 6);
    const botChoice = Math.floor(Math.random() * 11);
    let result = '';
    
    // Menentukan hasil game
    if (userChoice === botChoice) {
        result = 'Hasil: Seri!';
    } else if (userChoice > botChoice) {
        result = `Hasil: Kamu menang! (Kamu ${userChoice} vs Bot ${botChoice})`;

        // Peluang menang jackpot 60%
        const winChance = Math.random();
        if (winChance <= 0.6) {
            const jackpot = 30000;
            db.data.users[m.sender].balance += jackpot; // Menambahkan jackpot ke balance pengguna
            result += `\nKamu memenangkan jackpot sebesar ${jackpot} balance!`;
        }
    } else {
        result = `Hasil: Bot menang! (Kamu ${userChoice} vs Bot ${botChoice})`;
        
        // Peluang kalah dan pengurangan balance
        const loseChance = Math.random();
        if (loseChance <= 0.6) {
            const loss = 3000;
            db.data.users[m.sender].balance -= loss; // Mengurangkan balance pengguna
            result += `\nKamu kehilangan ${loss} balance.`;
        }
    }

    m.reply(result);
}
break;
case 'adventure':
    const locations = ['hutan', 'laut', 'gurun'];
    const adventurerState = {
        location: 'hutan',
        supplies: 100,
        experience: 0
    };

    const actions = [
        '🏹 Berburu hewan liar', '🚰 Mencari sumber air', '🏕️ Mendirikan perkemahan', 
        '🚶 Berjalan menyusuri pantai', '🕳️ Mengeksplorasi gua', '👫 Bertemu penduduk lokal'
    ];

    const enemies = [
        { name: 'serigala', damage: 20 },
        { name: 'harimau', damage: 25 },
        { name: 'hantu', damage: 30 },
        { name: 'monster laut', damage: 35 }
    ];

    const weapons = [
        { name: 'senjata tajam', damage: 15 },
        { name: 'bom', damage: 50 },
        { name: 'roket', damage: 70 }
    ];

    async function adventureRound() {
        const location = adventurerState.location;
        const randomActionCount = Math.floor(Math.random() * actions.length) + 1;
        const selectedActions = [];
        for (let i = 0; i < randomActionCount; i++) {
            const randomActionIndex = Math.floor(Math.random() * actions.length);
            selectedActions.push(actions[randomActionIndex]);
            actions.splice(randomActionIndex, 1);
        }

        await m.reply(`Anda memilih aksi-aksi berikut untuk putaran ini:\n${selectedActions.join('\n')}`);
        
        for (const action of selectedActions) {
            if (action.includes('🏹')) {
                const huntedFood = Math.floor(Math.random() * 20) + 10;
                adventurerState.supplies += huntedFood;
                await m.reply(`Anda berhasil ${action} dan mendapatkan ${huntedFood} makanan.`);
            } else {
                const experienceEarned = Math.floor(Math.random() * 30) + 10;
                adventurerState.experience += experienceEarned;

                const difficulty = Math.random();
                if (difficulty < 0.15) {
                    adventurerState.supplies -= 20;
                    await m.reply(`Anda menghadapi kesulitan saat ${action} di ${location} dan kehilangan makanan. Pengalaman Anda: ${experienceEarned} poin.`);
                } else if (difficulty < 0.35) {
                    adventurerState.supplies -= 10;
                    await m.reply(`Anda menemukan jalan yang sulit saat ${action} di ${location} dan makanan sedikit berkurang. Pengalaman Anda: ${experienceEarned} poin.`);
                } else {
                    const randomEnemy = enemies[Math.floor(Math.random() * enemies.length)];
                    const enemyDamage = randomEnemy.damage;
                    adventurerState.supplies -= enemyDamage;
                    await m.reply(`Anda berhadapan dengan ${randomEnemy.name} saat ${action} di ${location}! Pengalaman Anda: ${experienceEarned} poin. ${randomEnemy.name} menyebabkan ${enemyDamage} kerusakan pada persediaan makanan Anda.`);
                }
            }
        }
    }

    async function encounterEnemy() {
        const randomEnemy = enemies[Math.floor(Math.random() * enemies.length)];
        const randomWeapon = weapons[Math.floor(Math.random() * weapons.length)];
        const enemyDamage = randomEnemy.damage;
        const weaponDamage = randomWeapon.damage;

        await m.reply(`Tiba-tiba, Anda diserang oleh ${randomEnemy.name} bersenjata ${randomWeapon.name}! Anda terluka dan kehilangan ${enemyDamage} poin makanan. Anda juga berhasil melawan dan menghasilkan ${weaponDamage} kerusakan pada lawan.`);
        adventurerState.supplies -= enemyDamage;
    }

    adventurerState.location = locations[Math.floor(Math.random() * locations.length)]; // Pilih lokasi baru
    await m.reply(`Selamat datang dalam petualangan!\nLokasi: ${adventurerState.location}`);

    for (let round = 1; round <= 3; round++) {
        await m.reply(`Putaran Selanjutnya dimulai!`);
        adventurerState.location = locations[Math.floor(Math.random() * locations.length)]; // Pilih lokasi baru
        await m.reply(`Lokasi saat ini: ${adventurerState.location}`);

        if (Math.random() < 0.2) {
            await encounterEnemy();
        } else {
            await adventureRound();
        }
    }

    const result = 'Petualangan selesai!\n\nHasil Putaran Terakhir:\n' +
        `Lokasi Terakhir: ${adventurerState.location}\nMakanan Tersisa: ${adventurerState.supplies} kg\nPengalaman: ${adventurerState.experience} poin`;

    await m.reply(result);
    break;
            case 'tagall': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
let teks = `══✪〘 *👥 Tag All* 〙✪══
 
 ➲ *Pesan : ${q ? q : 'kosong'}*\n\n`
                for (let mem of participants) {
                teks += `⭔ @${mem.id.split('@')[0]}\n`
                }
                sky.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted: m })
                }
                break
      case "hidetag":    
        {
          if (!isCreator)
            return;
          sky.sendMessage(
            m.chat,
            { text: q ? q : "", mentions: participants.map((a) => a.id) },
            { quoted: fkontak }
          );
        }
        break
case 'sms':{
		if (!text) throw `Example : ${prefix + command} 628387064****`
		if (!isCreator) throw mess.owner
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/sms/spam2?apikey=GataDios&nomor=${q}`)
			m.reply(data.result)
			}
			break
case 'bingo': {
    // Fungsi untuk mengacak array
    function shuffle(array) {
        const shuffled = array.slice();
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        return shuffled;
    }
    const options = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']; // Pilihan a-z sesuai dengan kolom Bingo
    const userChoice = args[0] ? args[0].toLowerCase() : null; // Pilihan pengguna
    const betAmount = parseInt(args[1]); // Jumlah taruhan yang diinginkan

    // Memastikan pilihan pengguna adalah yang valid
    if (!userChoice || !options.includes(userChoice)) {
        m.reply('Contoh Bingo a-h taruhan');
        return;
    }

    // Memeriksa apakah taruhan yang diinginkan valid
    if (isNaN(betAmount) || betAmount <= 0) {
        m.reply('Tentukan jumlah taruhan yang valid dan lebih dari 0.');
        return;
    }

    const userBalance = db.data.users[m.sender].balance; // Saldo pengguna

    // Memeriksa apakah saldo pengguna mencukupi untuk taruhan
    if (userBalance < betAmount) {
        m.reply('Maaf, saldo Anda tidak mencukupi untuk taruhan ini.');
        return;
    }

    // Mengacak item yang harus dicari dalam petualangan
    const itemsToFind = shuffle([
        'Potion of Healing',
        'Enchanted Sword',
        'Treasure Map',
        'Dragon Scale',
        'Magic Wand',
        'Ancient Relic',
        'Invisibility Cloak',
        'Elixir of Wisdom',
        'Golden Key',
        'Crystal Ball',
        // Tambahkan item lain sesuai kebutuhan
    ]);

    // Mengambil item yang harus ditemukan sesuai dengan pilihan pengguna
    const chosenItem = itemsToFind[options.indexOf(userChoice)];

    // Memeriksa apakah pengguna menemukan item yang benar
    if (Math.random() < 0.5) { // Menggunakan 50% peluang
        m.reply(`Selamat! Kamu berhasil menemukan ${chosenItem} dan memenangkan ${betAmount} balance.`);
        db.data.users[m.sender].balance += betAmount;
    } else {
        m.reply(`Maaf, pilihan Anda (${userChoice}) belum menemukan item yang harus dicari. Coba lagi nanti!`);
        db.data.users[m.sender].balance -= betAmount;
    }
    break;
}
case 'cvlimit': {
    const convertAmount = parseInt(args[0]);
    if (isNaN(convertAmount) || convertAmount <= 0) {
        m.reply('Masukkan jumlah yang valid untuk diubah dari limit ke balance.');
        return;
    }
    const userLimit = db.data.users[m.sender].limit;
    const balanceToAdd = convertAmount * 100;
    if (userLimit < convertAmount) {
        m.reply('Maaf, limit Anda tidak mencukupi untuk melakukan konversi sebesar ini.');
        return;
    }
    db.data.users[m.sender].balance += balanceToAdd;
    db.data.users[m.sender].limit -= convertAmount; 
    m.reply(`Anda telah berhasil mengonversi ${convertAmount} limit menjadi ${balanceToAdd} balance.`);
    break;
}
					
            	case 'aicustome': {
            	  if (!isPrem) return replyprem(mess.premium)
		if (!text) throw `aicustome pesan|characterai`
		text1 = text.split(' | ')[0] ? text.split(' | ')[0] : '-'
text2 = text.split(' | ')[1] ? text.split(' | ')[1] : '-'
    try {
    m.reply('Aicustome Still in Development')
            	var { data } = await axios.get(`https://api.yanzbotz.my.id/api/ai/characterai?text=${text1}&name=${text2}`)
			m.reply(`${data.result}`.trim())
             } catch (error) {
        m.reply(error);
    }
            }
            break
			case 'toptv':{
try {
if
	(m.message.extendedTextMessage) 
{
  var dataVideo = { ptvMessage: m.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage }
    sky.relayMessage(m.chat, dataVideo, {})
 }
    } catch (error) {
        m.reply(error);
        }
        }
        break
					
			case 'whois': {
		if (!text) throw `Put Url`
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.betabotz.org/api/webzone/whois?query=${text}&apikey=2fbgCgOB`)
			m.reply(`${data.result}`.trim())
			}
			break
			case 'resetbalance': {
    const newBalance = 1000; // Saldo baru yang akan diatur untuk semua pengguna
    // Mengatur ulang saldo seluruh pengguna menjadi 1000
    for (const user in db.data.users) {
        db.data.users[user].balance = newBalance;
    }
    m.reply(`Saldo seluruh pengguna telah direset menjadi ${newBalance} balance.`);
    break;
}
			case 'resetlimit': {
    const newBalance = 20; // Saldo baru yang akan diatur untuk semua pengguna
    // Mengatur ulang saldo seluruh pengguna menjadi 1000
    for (const user in db.data.users) {
        db.data.users[user].limit = newBalance;
    }
    m.reply(`limit seluruh pengguna telah direset menjadi ${newBalance} limit.`);
    break;
}
case 'ipinfo2': {
  if (!isPrem) return replyprem(mess.premium)
		if (!text) throw `Input *[IP]*`
			m.reply(mess.wait)
			var { data } = await axios.get(`https://ipapi.co/${text}/json/`)
			m.reply(`HASIL\nIP : ${data.ip}\nNETWORK : ${data.network}\nVERSION : ${data.version}\nCITY : ${data.city}\nREGION : ${data.region}\nREGION CODE : ${data.region_code}\nCOUNTRY : ${data.country}\nCOUNTRY NAME : ${data.country_name}\nCOUNTRY CODE : ${data.country_code_iso3}\nCOUNTRY KAPITAL : ${data.country_capital}\nCOUNTRY TLD : ${data.country_tld}\nCONTINENT CODE : ${data.continent_code}\nIN EU : ${data.in_eu}\nLATITUDE : ${data.latitude}\nLONGITUDE : ${data.longitude}\nTIMEZONE : ${data.timezone}\nUTC OFFSET : ${data.utc_offset}\nCOUNTRY CALL ID : ${data.country_calling_code}\nCURRENCY : ${data.currency}\nCURRENCY NAME : ${data.currency_name}\nLANGUAGE : ${data.languages}\nCOUNTRY AREA : ${data.country_area}\nCOUNTRY POPULATION : ${data.country_population}\nASN : ${data.asn}\nORG : ${data.org}`.trim())
			}
			break
case 'tag':{
  if (!isGroup) throw mess.onlygroup;
  const target = args[0]; // User yang ingin ditag
  const amount = parseInt(args[1]); // Jumlah tag yang ingin dikirim
  if (!target || !amount || isNaN(amount) || amount <= 0) {
    throw 'Gunakan: *tag [@user] [jumlah]* (misal: tag @user 3)';
  }

  // Membuat antrian tag untuk pengguna
  tagQueue[sender] = {
    target,
    amount,
    currentIndex: 0
  };

  // Memulai pengiriman tag bergilir
  sendNextTag(sender);
}
  break;
case 'tag2':{
  const tagUser = args[0] || '';
  const tagCount = args[1] ? parseInt(args[1]) : 1;

  if (!tagUser.startsWith('@') || isNaN(tagCount) || tagCount <= 0) {
    await sky.sendText(from, 'Gunakan perintah dengan format yang benar, contoh: "tag @user jumlah".');
    return;
  }

  const taggedUsers = [];

  for (let i = 0; i < tagCount; i++) {
    taggedUsers.push(tagUser);
  }

  const taggedMessage = taggedUsers.join(' ');

  await sky.sendText(from, taggedMessage);
  }
  break;
case 'randomtag': {
  if (!isGroup) throw mess.onlygroup;
  if (!args[0]) throw `Gunakan: *${prefix}randmtag [jumlah tag]*`;
  const jumlahTag = parseInt(args[0]);
  if (isNaN(jumlahTag) || jumlahTag <= 0) throw 'Jumlah tag harus berupa angka positif.';
  const participants = await sky.groupMetadata(from);
  const participantList = participants.participants;
  const randomIndexes = [];
  while (randomIndexes.length < Math.min(jumlahTag, participantList.length)) {
    const randomIndex = Math.floor(Math.random() * participantList.length);
    if (!randomIndexes.includes(randomIndex)) {
      randomIndexes.push(randomIndex);
    }
  }
  const taggedMembers = randomIndexes.map(index => {
    const participant = participantList[index];
    return `> @${participant.id.split('@')[0]}\n`;
  });
  const tagMessage = taggedMembers.join(' ');

  await sky.sendTextWithMentions(from, tagMessage);
  break;
}
case 'poker': {
    const args = m.text.split(' ');
    if (args.length !== 2) {
        m.reply('Format yang benar: !poker [jumlah taruhan]');
        return;
    }

    const taruhan = parseInt(args[1]);

    if (isNaN(taruhan) || taruhan <= 0) {
        m.reply('Masukkan jumlah taruhan yang valid.');
        return;
    }

    const suits = ['Spades', 'Hearts', 'Diamonds', 'Clubs'];
    const ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
    const deck = [];
    for (const suit of suits) {
        for (const rank of ranks) {
            deck.push(`${rank} of ${suit}`);
        }
    }

    // Acak deck kartu dengan lebih baik
    const shuffledDeck = [];
    while (deck.length > 0) {
        const randomIndex = Math.floor(Math.random() * deck.length);
        shuffledDeck.push(deck.splice(randomIndex, 1)[0]);
    }

    const players = ['Pemain', 'Bot 1', 'Bot 2', 'Bot 3'];
    const hands = {};
    for (const player of players) {
        hands[player] = [shuffledDeck.pop(), shuffledDeck.pop()];
    }

    // Logika permainan yang memungkinkan semua tiga opsi
    const pemainMenang = Math.floor(Math.random() * 3); // Acak antara 0, 1, atau 2 untuk menentukan pemenang

    if (pemainMenang === 0) {
        // Pemain menang
        const menang = taruhan * 2;
        db.data.users[m.sender].balance += menang;
        m.reply(`Pemain menang! Kamu memenangkan ${menang} balance.`);
    } else {
        // Salah satu bot menang
        const botMenang = `Bot ${pemainMenang}`;
        const kalah = taruhan;
        db.data.users[m.sender].balance -= kalah;
        m.reply(`${botMenang} menang! Kamu kehilangan ${kalah} balance.`);
    }
    break;
}
case 'adualien': {
    const namaAlien = ['xenon', 'zorgon', 'krakthor', 'vorkax', 'quintar', 'yurlex', 'plasmak', 'galactron', 'nebulor', 'zyggon'];
    const pilihan = args[0]?.toLowerCase();
    const taruhan = parseInt(args[1]);

    const userBalance = db.data.users[m.sender].balance; // Saldo pengguna
    let userWins = db.data.users[m.sender].wins || 0; // Jumlah kemenangan pengguna
    let userLosses = db.data.users[m.sender].losses || 0; // Jumlah kekalahan pengguna

    if (!pilihan) {
        return await m.reply(`Pilihan alien yang tersedia: ${namaAlien.join(', ')}`);
    }
    if (!namaAlien.includes(pilihan)) {
        return await m.reply('Pilihan alien tidak valid. Pilihan yang tersedia: ' + namaAlien.join(', '));
    }

    if (isNaN(taruhan) || taruhan <= 0 || taruhan > userBalance) {
        return await m.reply('Tentukan jumlah taruhan yang valid dan sesuai dengan saldo Anda.');
    }

    const lawanPilihan = namaAlien[Math.floor(Math.random() * namaAlien.length)];

    let userScore = 0;
    let lawanScore = 0;
    let maxRounds = 15; // Jumlah ronde maksimal
    let round = 1;
    let result = `⚔️ Mulai permainan adu alien dengan ${pilihan} melawan ${lawanPilihan} ⚔️\n\n`;

    while (round <= maxRounds) {
        let userAction = Math.random() < 0.5 ? 'serang' : 'bertahan';
        let lawanAction = Math.random() < 0.5 ? 'serang' : 'bertahan';

        if (userAction === 'serang' && lawanAction === 'bertahan') {
            userScore++;
            result += `🤜 ${pilihan} menyerang dan berhasil mengalahkan taktik bertahan ${lawanPilihan}! (+1 poin)\n`;
        } else if (userAction === 'bertahan' && lawanAction === 'serang') {
            lawanScore++;
            result += `🤜 ${lawanPilihan} menyerang dan mengalahkan taktik bertahan ${pilihan}! (+1 poin)\n`;
        } else {
            result += `🤝 Kedua alien sama-sama menerapkan taktik yang sama, ${pilihan} dan ${lawanPilihan}.\n`;
        }

        // Variasi aksi tambahan
        if (userScore - lawanScore >= 2) {
            result += `💥 ${pilihan} terluka dan masuk rumah sakit!\n`;
        } else if (lawanScore - userScore >= 2) {
            result += `💥 ${lawanPilihan} terluka dan masuk rumah sakit!\n`;
        }

        if (userScore >= 5) {
            result += `😢 ${pilihan} merasa tertekan oleh kekuatan ${lawanPilihan}.\n`;
        } else if (lawanScore >= 5) {
            result += `😢 ${lawanPilihan} merasa tertekan oleh kekuatan ${pilihan}.\n`;
        }

        if (userScore <= 1) {
            result += `🗣️ ${lawanPilihan} mengeluarkan teriakan menakutkan!\n`;
        } else if (lawanScore <= 1) {
            result += `🗣️ ${pilihan} mengeluarkan teriakan menakutkan!\n`;
        }

        round++;
    }
    result += `\n⏱️ Pertandingan selesai! Total skor: ${pilihan} ${userScore} - ${lawanPilihan} ${lawanScore}`;

    if (userScore > lawanScore) {
        const hasilMenang = taruhan * 2; // Menang 2x lipat taruhan
        result += `\n🎉 ${pilihan} menang +${hasilMenang} Balance melawan ${lawanPilihan}!`;
        db.data.users[m.sender].balance += hasilMenang - taruhan; // Menambah saldo jika menang
        userWins++;
    } else if (lawanScore > userScore) {
        result += `\n😢 ${pilihan} kalah -${taruhan} Balance melawan ${lawanPilihan}!`;
        db.data.users[m.sender].balance -= taruhan; // Mengurangi saldo jika kalah
        userLosses++;
    } else {
        result += `\n⚖️ Pertandingan adu alien melawan ${lawanPilihan} berakhir imbang!`;
    }

    // Memperbarui jumlah kemenangan dan kekalahan pengguna
    db.data.users[m.sender].wins = userWins;
    db.data.users[m.sender].losses = userLosses;

    await m.reply(`${result}`);
}
break;
                
case 'casino':
    {
        let bet = parseInt(args[0]); // Jumlah taruhan dari pengguna
        let number = parseInt(args[1]); // Nomor yang dipilih oleh pengguna

        if (isNaN(bet) || isNaN(number)) {
            throw new Error('Format yang benar: casino <taruhan> <nomor>');
        }

        let userBalance = 1000; // Saldo pengguna (gantilah dengan nilai saldo sesuai kebutuhan)

        if (bet > userBalance) {
            throw new Error('Saldo tidak cukup.');
        }

        let rolledNumber = Math.floor(Math.random() * 6) + 1; // Menghasilkan angka acak dari 1 hingga 6

        let resultText = `Angka dadu yang keluar: ${rolledNumber}\n`;

        if (rolledNumber === number) {
            let winnings = bet * 6; // Jika tebakan benar, pengguna memenangkan 6 kali taruhan
            userBalance += winnings;
            resultText += `Selamat! Anda menang ${winnings}.\n`;
        } else {
            userBalance -= bet;
            resultText += `Sayang sekali, Anda kalah ${bet}.\n`;
        }

        resultText += `Saldo Anda sekarang: ${userBalance}.`;

        m.reply(resultText);
    }
    break;
    case 'ipinfo':
  if (!isPrem) return replyprem(mess.premium)    
    if (!text) throw 'Gunakan: *ipinfo [alamat IP]*';
    const ip = args[0];
    try {
        const ipInfo = await getIpInfo(ip);
        const replyMessage = `Informasi tentang alamat IP ${ip}:\n\nNegara: ${ipInfo.country}\nDaerah: ${ipInfo.region}\nKota: ${ipInfo.city}\nOrganisasi: ${ipInfo.org}\nLokasi: ${ipInfo.loc}`;
        m.reply(replyMessage);
    } catch (error) {
        m.reply(error);
    }
break;
case 'nyt':
  try {
    const newsList = await getLatestNYTNews();

    if (newsList.length === 0) {
      m.reply('Tidak ada berita terbaru dari New York Times yang tersedia saat ini.');
    } else {
      let replyMessage = 'Berita Terbaru dari New York Times:\n';

      for (const newsItem of newsList) {
        const { title, link } = newsItem;
        replyMessage += `Judul: ${title}\n`;
        replyMessage += `Link: ${link}\n\n`;
      }

      m.reply(replyMessage);
    }
  } catch (error) {
    m.reply('Terjadi kesalahan saat mengambil berita terbaru dari New York Times.');
    console.error('Error fetching latest NYT news:', error);
  }
  break;

case 'bbcnews':
  try {
    const newsList = await getLatestBBCNews();

    if (newsList.length === 0) {
      m.reply('Tidak ada berita terbaru dari BBC yang tersedia saat ini.');
    } else {
      let replyMessage = 'Berita Terbaru dari BBC:\n';

      for (const newsItem of newsList) {
        const { title, link } = newsItem;
        replyMessage += `Judul: ${title}\n`;
        replyMessage += `Link: ${link}\n\n`;
      }

      m.reply(replyMessage);
    }
  } catch (error) {
    m.reply('Terjadi kesalahan saat mengambil berita terbaru dari BBC.');
    console.error('Error fetching latest BBC news:', error);
  }
  break;  
case 'animelast':{
  try {
    const animeList = await getLatestAnime();

    if (animeList.length === 0) {
      m.reply('Tidak ada daftar anime terbaru yang tersedia saat ini.');
    } else {
      let replyMessage = 'Anime Terbaru:\n';

      for (const anime of animeList) {
        const { title, link } = anime;
        replyMessage += `Judul: ${title}\n`;
        replyMessage += `Link: ${link}\n\n`;
      }

      m.reply(replyMessage);
    }
  } catch (error) {
    m.reply('Terjadi kesalahan saat mengambil daftar anime terbaru.');
    console.error('Error fetching latest anime:', error);
  }
  }
  break;
case 'akar':{
		if (!text) throw `Example : ${prefix + command} 30`
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.akuari.my.id/edukasi/akar?angka=${text}`)
			m.reply(`${data.hasil}`.trim())
			}
			break
			case 'toxicheck':{
			  let cok = text;
  if (m.quoted) {
    const quotedMessage = await m.getQuotedMessage();
    if (quotedMessage.text) {
      cok = quotedMessage.text;
    }
  }
  if (!cok) {
    m.reply('Balas pesan seseorang dengan pertanyaan atau ketik pertanyaan langsung.');
    return;
  }
			var { data } = await axios.get(`https://skizo.tech/api/toxic-checker?text=${cok}&apikey=${apikey}`)
			m.reply(`Nilai : ${data.toxicity}\nInsult : ${data.insult}\nCombined : ${data.combined}`.trim())
			}
			break
			case 'ringkasan':{
						  let cok = text;
  if (m.quoted) {
    const quotedMessage = await m.getQuotedMessage();
    if (quotedMessage.text) {
      cok = quotedMessage.text;
    }
  }
  if (!cok) {
    m.reply('Balas pesan seseorang dengan pertanyaan atau ketik pertanyaan langsung.');
    return;
  }			
			var { data } = await axios.get(`https://skizo.tech/api/paraphraser?text=${cok}&apikey=${apikey}`)
			m.reply(`Hasil : ${data.content}\nTotal Keys : ${data.countWord}`.trim())
			}		
			break
case 'quote':
  if (!isPrem) return replyprem(mess.premium)  
    if (!text)  throw 'Gunakan: *quote [kata_kunci]*';
                    if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
                db.data.users[m.sender].limit -= 20 // -1 limit
    const input = args.join('_');
    try {
        const quoteResult = await quotes(input);
        if (quoteResult.status) {
            const randomIndex = Math.floor(Math.random() * quoteResult.data.length);
            const randomQuote = quoteResult.data[randomIndex];
            const replyMessage = `${q}\n\n"${randomQuote.quote}"\n\n- ${randomQuote.author} (${randomQuote.bio})\n\n•Made In Avosky`;
            m.reply(replyMessage);
        } else {
            m.reply('Kutipan bijak tidak ditemukan.');
        }
    } catch (error) {
        m.reply('Terjadi kesalahan saat mencari kutipan bijak.');
    }
break;
			case 'biksu': {
		if (!text) throw `Example : ${prefix + command} Siapa Nama Mu`			
			var { data } = await axios.get(`https://api.betabotz.org/api/search/openai-logic?text=${text}&logic=halo%20saya%20adalah%20biksu%20saya%20di%20ciptakan%20untuk%20memberi%20tau%20kamu%20tentang%20agama%20buddha%20jika%20kamu%20ingin%20bertanya%20silahkan%20saja%20dan%20nama%20saya%20adalah%20ai%20biksu&apikey=2fbgCgOB`)
			m.reply(`${data.message}`.trim())
			}
			break
			case 'colong': case '🙏':{
	if (!m.quoted) throw 'Reply a sticker!'
	let stiker = false
	try {
		let [packname, ...author] = text.split('|')
		author = (author || []).join('|')
		let mime = m.quoted.mimetype || ''
		if (!/webp/.test(mime)) throw 'Reply sticker!'
		let img = await m.quoted.download()
		if (!img) throw 'Reply a sticker!'
		stiker = await addExif(img, packname || '', author || '')
	} catch (e) {
		console.error(e)
		if (Buffer.isBuffer(e)) stiker = e
	} finally {
		if (stiker) sky.sendMessage(m.chat, { sticker: stiker }, { quoted: m })
		else throw 'Conversion failed'
	}
	}
break
case 'suitbot':{
  const weapons = ['rock', 'paper', 'scissors'];

  function getRandomWeapon() {
      return weapons[Math.floor(Math.random() * weapons.length)];
  }

  const userWeapon = args[0]?.toLowerCase();
  if (!userWeapon || !weapons.includes(userWeapon)) {
    return sky.sendText(from, `Pilih senjata yang valid: ${weapons.join(', ')}`);
  }

  const computerWeapon = getRandomWeapon();
  
  let result;
  if (userWeapon === computerWeapon) {
    result = "It's a tie!";
  } else if (
    (userWeapon === 'rock' && computerWeapon === 'scissors') ||
    (userWeapon === 'paper' && computerWeapon === 'rock') ||
    (userWeapon === 'scissors' && computerWeapon === 'paper')
  ) {
    result = 'You win!';
  } else {
    result = 'Computer wins!';
  }

  sky.sendText(from, `You chose ${userWeapon}\nComputer chose ${computerWeapon}\n${result}`);
  }
  break;
case 'jam':
  const currentTime = new Date();
  const hours = currentTime.getHours();
  const minutes = currentTime.getMinutes();
  const formattedTime = `${hours}:${minutes < 10 ? '0' + minutes : minutes}`;
  sky.sendText(sender, `Sekarang pukul ${formattedTime} WIB.`);
  break;
case 'wik': {
  if (!text) throw 'Uh oh, where is the text?\n\nExample:\nWikipedia Albert Einstein';
  replygc('Please wait, searching Wikipedia...');
  try {
    const axios = require('axios');
    const cheerio = require('cheerio');
    const searchTerm = encodeURIComponent(text);
    const response = await axios.get(`https://en.wikipedia.org/w/api.php?action=query&format=json&list=search&srsearch=${searchTerm}`);
    const searchResults = response.data.query.search;
    if (searchResults.length === 0) {
      throw 'Sorry, no results found on Wikipedia.';
    }
    const pageId = searchResults[0].pageid;
    const pageResponse = await axios.get(`https://en.wikipedia.org/w/api.php?format=json&action=query&prop=extracts&exintro&explaintext&pageids=${pageId}`);
    const pageData = pageResponse.data.query.pages[pageId];
    const pageSummary = pageData.extract;
    replygc(pageSummary);
  } catch (error) {
    throw 'Oops, something went wrong while searching Wikipedia. Please try again later.';
  }
}
break
case 'wikipedia': {
    if (!text) throw 'Uh oh, di mana teksnya?\n\nContoh:\nWikipedia Albert Einstein';
    replygc('Harap tunggu, mencari Wikipedia...');
    try {
        const axios = require('axios');
        const cheerio = require('cheerio');
        const searchTerm = encodeURIComponent(text);
        const response = await axios.get(`https://id.wikipedia.org/w/api.php?action=query&format=json&list=search&srsearch=${searchTerm}`);
        const searchResults = response.data.query.search;
        if (searchResults.length === 0) {
            throw 'Maaf, tidak ada hasil ditemukan di Wikipedia.';
        }
        const pageId = searchResults[0].pageid;
        const pageResponse = await axios.get(`https://id.wikipedia.org/w/api.php?format=json&action=query&prop=extracts&exintro&explaintext&pageids=${pageId}`);
        const pageData = pageResponse.data.query.pages[pageId];
        const pageSummary = pageData.extract;
        m.reply(pageSummary);
    } catch (error) {
        throw 'Ups, terjadi kesalahan saat mencari di Wikipedia. Silakan coba lagi nanti.';
    }
}
break;
case 'daftar': {
  const username = args[0]; // Ambil nama pengguna dari pesan

  if (!username) {
    m.reply('Masukkan nama pengguna saat mendaftar.');
    return;
  }

  const userNumber = m.sender; // Nomor pengguna, Anda dapat menggantinya sesuai dengan struktur bot Anda

  // Cek apakah pengguna sudah terdaftar
  if (registeredUsers[userNumber]) {
    m.reply('Anda sudah terdaftar.');
  } else {
    sendOTP(userNumber);
    m.reply(`Selamat datang, ${username}! Kami telah mengirimkan OTP ke Anda.`);
  }
  }
  break;
// Case untuk memverifikasi pengguna dengan OTP
case 'verifikasi': {
  const userNumber = m.sender; // Nomor pengguna
  const userOTP = args[0]; // Ambil OTP dari pesan

  if (!userOTP) {
    m.reply('Masukkan OTP untuk verifikasi.');
    return;
  }

  // Cek apakah pengguna sudah terdaftar
  if (registeredUsers[userNumber]) {
    const storedOTP = registeredUsers[userNumber].otp;

    if (parseInt(userOTP) === storedOTP) {
      m.reply('Verifikasi sukses! Anda sekarang terdaftar.');
      delete registeredUsers[userNumber]; // Hapus data pengguna setelah verifikasi sukses
    } else {
      m.reply('Verifikasi gagal. Harap masukkan OTP yang benar.');
    }
  } else {
    m.reply('Anda belum mendaftar. Silakan daftar terlebih dahulu.');
  }
  }
  break;
case 'alkitab':{
    if (!text) throw `uhm.. teksnya mana?\n\ncontoh:\nAlkitab kejadian`
    m.reply('Patience, O Earthlings')
    let res = await axios.get(`https://alkitab.me/search?q=${encodeURIComponent(text)}`, { headers: { "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36" } })
    const cheerio = require('cheerio');
    let $ = cheerio.load(res.data)
    let result = []
    $('div.vw').each(function (a, b) {
        let teks = $(b).find('p').text().trim()
        let link = $(b).find('a').attr('href')
        let title = $(b).find('a').text().trim()
        result.push({ teks, link, title })
    })

    let caption = result.map(v => `${v.title}\n${v.teks}`).join('\n────────\n')
    m.reply(caption)
}
break
case 'sinonim': {
    if (!text) throw 'Tolong masukkan kata untuk mencari sinonimnya.'

    try {
        m.reply('Sedang mencari sinonim kata...')
        let res = await axios.get(`https://api.datamuse.com/words?rel_syn=${encodeURIComponent(text)}`, {
            timeout: 50000 // Timeout dalam milidetik (misalnya, 5 detik)
        });
        let data = res.data
        if (data.length > 0) {
            let synonyms = data.map(item => item.word).join(', ')
            m.reply(`Sinonim dari "${text}" adalah: ${synonyms}`)
        } else {
            throw 'Tidak ada sinonim yang ditemukan.'
        }
    } catch (err) {
        console.error(err);
        if (err.code === 'ECONNABORTED') {
            m.reply('Permintaan ke server terlalu lambat. Coba lagi nanti.');
        } else {
            m.reply('Terjadi kesalahan saat mencari sinonim kata.');
        }
    }

    break;
}

case 'kamus': {
    if (!text) throw 'Tolong masukkan kata yang ingin Anda cari.'

    try {
        m.reply('Sedang mencari arti kata...')
        let res = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(text)}`, {
            timeout: 15000 // Timeout dalam milidetik (misalnya, 5 detik)
        });
        let data = res.data[0]
        if (data) {
            let meanings = data.meanings.map(meaning => {
                let definitions = meaning.definitions.map(def => def.definition).join('\n')
                return `${meaning.partOfSpeech}: ${definitions}`
            }).join('\n\n')

            let response = `**${data.word}**\n\n${meanings}`
            m.reply(response)
        } else {
            throw 'Kata tidak ditemukan dalam kamus.'
        }
    } catch (err) {
        console.error(err);
        if (err.code === 'ECONNABORTED') {
            m.reply('Permintaan ke server terlalu lambat. Coba lagi nanti.');
        } else {
            m.reply('Terjadi kesalahan saat mencari arti kata.');
        }
    }

    break;
}
case 'akar':{
		if (!text) throw `Example : ${prefix + command} 30`
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.akuari.my.id/edukasi/akar?angka=${text}`)
			m.reply(`${data.hasil}`.trim())
			}
			break
case 'pangkat':{
		if (!text) throw `Example : ${prefix + command} 3|4`
		    satu = text.split('|')[0] ? text.split('|')[0] : '-'
            dua = text.split('|')[1] ? text.split('|')[1] : '-'   
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.akuari.my.id/edukasi/pangkat?angka=${satu}&pangkat=${dua}`)
			m.reply(`${data.hasil}`.trim())
			}
			breakt
case 'kali':{
		if (!text) throw `Example : ${prefix + command} 3|4`
		    satu = text.split('|')[0] ? text.split('|')[0] : '-'
            dua = text.split('|')[1] ? text.split('|')[1] : '-'   
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.akuari.my.id/edukasi/kali?angka1=${satu}&angka2=${dua}`)
			m.reply(`${data.hasil}`.trim())
			}
			break
case 'ainime': {
if (!isPrem) return replyprem(mess.premium)
if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ainime doodle\n\nList Filter\n• anime_2d\n• pretty_soldier\n• bizzare\n• romance_comic\n• maid_dressing\n• superhero_comic\n• watercolor\n• doodle\n• america_comic\n• starry_girl`)
                    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ainime doodle\n\nList Filter\n• anime_2d\n• pretty_soldier\n• bizzare\n• romance_comic\n• maid_dressing\n• superhero_comic\n• watercolor\n• doodle\n• america_comic\n• starry_girl`)
                    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ainime doodle\n\nList Filter\n• anime_2d\n• pretty_soldier\n• bizzare\n• romance_comic\n• maid_dressing\n• superhero_comic\n• watercolor\n• doodle\n• america_comic\n• starry_girl`)
m.reply(mess.wait)
	const media = await sky.downloadAndSaveMediaMessage(quoted)
	const { TelegraPh } = require('./lib/uploader')
	const anu = await TelegraPh(media)
	let { data } = await axios.get(`https://skizo.tech/api/aimirror?&apikey=${apikey}&url=${anu}&filter=${text}`)
	if (data.message) return m.reply(JSON.stringify(data))
	await sky.sendMessage(m.chat, { image: { url: data.generated_image_addresses[0] }, caption: mess.done }, { quoted: m })
}
break
case 'ainime2': {
if (!isPrem) return replyprem(mess.premium)
if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ainime2 doodle\n\nList Filter\n• gta5\n• dball\n• naruto\n• cyber\n• killer\n• kyoto\n• bikini\n• iron`)
                    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ainime2 doodle\n\nList Filter\n• gta5\n• dball\n• naruto\n• cyber\n• killer\n• kyoto\n• bikini\n• iron`)
                    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ainime2 doodle\n\nList Filter\n• gta5\n• dball\n• naruto\n• cyber\n• killer\n• kyoto\n• bikini\n• iron`)
m.reply(mess.wait)
	const media = await sky.downloadAndSaveMediaMessage(quoted)
	const { TelegraPh } = require('./lib/uploader')
	const anu = await TelegraPh(media)
	let { data } = await axios.get(`https://skizo.tech/api/aimirrorvip?&apikey=${apikey}&url=${anu}&filter=${text}`)
	if (data.message) return m.reply(JSON.stringify(data))
	await sky.sendMessage(m.chat, { image: { url: data.generated_image_addresses[0] }, caption: mess.done }, { quoted: m })
}
break
                  case 'aivideo': case 'aifindvideo': case 'carivideo': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
if (!isPrem) return replyprem(mess.premium)
			  if (!text) throw 'contoh carivideo Kenzie!'
			m.reply(mess.wait)
			axios.get(`https://skizo.tech/api/ttsearch?search=${text}&apikey=${apikey}`).then(({ data }) => {
			var caption = `Region : ${data.region}\n`
			caption += `Title : ${data.title}\n\n`
			caption += `Dilhat : ${data.play_count} ×\n`
			caption += `Comment : ${data.comment_count}\n`
			caption += `Share : ${data.share_count}\n`
			caption += `Download : ${data.download_count}\n`
			caption += `Video Id : ${data.video_id}`
				sky.sendMessage(m.chat, { video: { url: data.play }, mimetype: 'video/mp4', caption })
				})
			
			}
				break
                case 'searchanime': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
if (!isPrem) return replyprem(mess.premium)
			  if (!text) throw 'lucia lotus!'
			m.reply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/anime?apikey=GataDios&query=${text}`).then(({ data }) => {
			var caption = `Title : ${data.result.title.romaji}\n`
			caption += `Id : ${data.result.id}\n`
			caption += `idMal : ${data.result.idMal}\n\n`
			caption += `Description : ${data.result.description}`		
				sky.sendMessage(m.chat, { image: { url: data.result.coverImage.large }, caption })
				})
			
			}
				break			
case 'bucinquote': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
let zeltoria = await fetch(`https://api.lolhuman.xyz/api/random/bucin?apikey=GataDios`)
let hasil = await zeltoria.json()
 m.reply(`${hasil.result}`.trim())
 }
 break
 case 'ai2':{
if (!text) return m.reply(`contoh ai2 Hello`)
m.reply(mess.wait)
let url = await fetchJson(`https://api.yanzbotz.my.id/api/ai/gptvoice?query=${text}`)
sky.sendMessage(m.chat, { audio: { url: url }, mimetype: 'audio/mp4', ptt: true, fileName: `${text}.mp3` }, { quoted: m })
}
break
case 'shortlink': case 'shortlink2': case 'shortlink3': case 'shortlink4': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
if (!text) throw `Input Link`
let zeltoria = await fetch(`https://api.lolhuman.xyz/api/shortlink?apikey=GataDios&url=${text}`)
let hasil = await zeltoria.json()
 m.reply(`${hasil.result}`.trim())
 }
 break

case 'sc':{
      sky.relayMessage(m.chat,  {
    requestPaymentMessage: {
      currencyCodeIso4217: 'INR',
      amount1000: 1234567,
      requestFrom: m.sender,
      noteMessage: {
      extendedTextMessage: {
      text: `
╭─「 Nyari Sc? 」
╰────
`,
      contextInfo: {
      externalAdReply: {
      showAdAttribution: true
      }}}}}}, {})
      }
      break
case 'namajepang': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
if (!text) throw `Input Name`
let zeltoria = await fetch(`https://api.lolhuman.xyz/api/ninja?apikey=GataDios&nama=${text}`)
let hasil = await zeltoria.json()
 m.reply(`${hasil.result}`.trim())
 }
 break
case 'truth': case 'dare': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
let zeltoria = await fetch(`https://api.betabotz.org/api/random/${command}?apikey=2fbgCgOB`)
let hasil = await zeltoria.json()
 m.reply(`${hasil.result}`.trim())
 }
 break
case 'dokter':
  if (pasienSakit[m.chat]) {
    m.reply('Permainan dokter sudah dimulai. Ketik *periksa* untuk memeriksa pasien.');
  } else {
    pasienSakit[m.chat] = [];
    m.reply('Permainan dokter dimulai! Ketik *periksa* untuk memeriksa pasien.');
  }
  break;
case 'periksa':
  if (!pasienSakit[m.chat]) {
    m.reply('Tidak ada permainan dokter yang sedang berlangsung. Ketik *dokter* untuk memulai.');
  } else {
  let member = participants.map(u => u.id)
  let me = m.sender
  let jodoh = member[Math.floor(Math.random() * member.length)]
    const pasien = m.sender;
    const penyakit = ['Demam', 'Flu', 'Sakit Perut', 'Pusing'];
    const penyakitIndex = Math.floor(Math.random() * penyakit.length);
    const hasilPeriksa = `${m.sender} memeriksa @${jodoh.split('@')[0]} dan menemukan bahwa dia memiliki penyakit: ${penyakit[penyakitIndex]}`;
    pasienSakit[m.chat].push(pasien);
    const obatIndex = Math.floor(Math.random() * obatTersedia.length);
    const obat = obatTersedia[obatIndex];
    obatDokter[pasien] = obat; 
    m.reply(`${hasilPeriksa}\nDokter memberikan ${obat} sebagai pengobatan\n\nketik obati.`);
  }
  break;
  case 'konversisuhu': {
    const suhuCelsius = parseFloat(args[0]);

    if (isNaN(suhuCelsius)) {
        m.reply('Masukkan suhu dalam Celsius yang valid.');
        return;
    }

    // Konversi ke Fahrenheit
    const suhuFahrenheit = (suhuCelsius * 9/5) + 32;

    // Konversi ke Kelvin
    const suhuKelvin = suhuCelsius + 273.15;

    // Konversi ke Reamur
    const suhuReamur = suhuCelsius * 4/5;

    m.reply(`Hasil konversi suhu:
    ${suhuCelsius} Celsius sama dengan:
    ${suhuFahrenheit} Fahrenheit
    ${suhuKelvin} Kelvin
    ${suhuReamur} Reamur`);
    break;
} 
case 'obati':
  if (!pasienSakit[m.chat]) {
    m.reply('Tidak ada permainan dokter yang sedang berlangsung. Ketik *dokter* untuk memulai.');
  } else {
    const pasien = m.sender;
    
    if (obatDokter[pasien]) {
      m.reply(`Anda memberikan ${obatDokter[pasien]} kepada pasien.`);
      delete obatDokter[pasien];
      const index = pasienSakit[m.chat].indexOf(pasien);
      if (index !== -1) {
        pasienSakit[m.chat].splice(index, 1);
      }
      if (pasienSakit[m.chat].length === 0) {
        const pemenang = pasien;
        delete pasienSakit[m.chat];
        m.reply(`Selamat, ${pemenang} telah berhasil mengobati semua pasien! Permainan dokter selesai.`);
      }
    } else {
      m.reply('Anda tidak memiliki obat untuk diberikan kepada pasien.');
    }
  }
  break;
case 'daftarpasien':
  if (!pasienSakit[m.chat]) {
    m.reply('Tidak ada permainan dokter yang sedang berlangsung. Ketik *dokter* untuk memulai.');
  } else {
    const daftarPasien = pasienSakit[m.chat].join(', ');
    m.reply(`Daftar pasien yang sakit: ${daftarPasien}`);
  }
  break;
case 'selesai':
  if (!pasienSakit[m.chat]) {
    m.reply('Tidak ada permainan dokter yang sedang berlangsung.');
  } else {
    const pemenang = pasienSakit[m.chat].join(', ');
    delete pasienSakit[m.chat];
    m.reply(`Permainan dokter selesai! Pemenangnya adalah: ${pemenang}`);
  }
  break;
case 'katabijak': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
let zeltoria = await fetch(`https://api.lolhuman.xyz/api/random/katabijak?apikey=GataDios`)
let hasil = await zeltoria.json()
 m.reply(`${hasil.result}`.trim())
 }
 break
case 'motivasi': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
let zeltoria = await fetch(`https://api.lolhuman.xyz/api/random/katabijak?apikey=GataDios`)
let hasil = await zeltoria.json()
 m.reply(`${hasil.result}`.trim())
 }
 break
case 'yoo':{
await loading()
}
break 
case 'dilanquote': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
let skey = await fetch(`https://api.lolhuman.xyz/api/quotes/dilan?apikey=GataDios`)
let hasil = await skey.json()
 m.reply(`${hasil.result}`.trim())
 }
 break
case 'puisi': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
let zeltoria = await fetch(`https://api.lolhuman.xyz/api/random/puisi?apikey=GataDios`)
let hasil = await zeltoria.json()
 m.reply(`${hasil.result}`.trim())
 }
 break
case 'naruto': case 'sasuke': case 'luffy': case 'goku':
case 'vegeta': case 'ichigo': case 'eren': case 'mikasa':
case 'levi': case 'gon': case 'killua': case 'hisoka':
case 'edward': case 'alphonse': case 'winry': case 'light':
case 'ryuk': case 'ken': case 'kaneki': case 'toka':
case 'izuku': case 'bakugo': case 'allmight': case 'deku':
case 'mob': case 'reigen': case 'teru': case 'narancia':
case 'giorno': case 'jotaro': case 'dio': case 'kira':
case 'shinichi': case 'ran': case 'conan': case 'kaito':
case 'aizen': case 'byakuya': case 'hitsugaya': case 'orihime':
case 'gintoki': case 'shinpachi': case 'kagura': case 'zura':
case 'makoto': case 'haru': case 'rin': case 'nagisa':
case 'saitama': case 'genos': case 'mumen': case 'boros':
case 'gohan': case 'piccolo': case 'krillin': case 'frieza':
case 'vegeto': case 'goten': case 'trunks': case 'cell':
case 'neji': case 'rocklee': case 'tenten': case 'itachi':
case 'kakashi': case 'sakura': case 'tsunade': case 'gaara':
case 'neku': case 'shiki': case 'joshua': case 'beat':
case 'naoto': case 'kanji': case 'rise': case 'yosuke':
case 'makoto': case 'yusuke': case 'ann': case 'morgana':
case 'ryuji': case 'futaba': case 'haru': case 'aigis':
case 'makoto': case 'yukiko': case 'chie': case 'nanako':
case 'yukari': case 'junpei': case 'mitsuru': case 'akihiko':
case 'yusuke': case 'makoto': case 'futaba': case 'haru':
case 'frodo': case 'sam': case 'aragorn': case 'gandalf':
case 'legolas': case 'gimli': case 'boromir': case 'smeagol':
case 'harry': case 'ron': case 'hermione': case 'dumbledore':
case 'voldemort': case 'snape': case 'malfoy': case 'hagrid':
case 'bilbo': case 'thorin': case 'smaug': {
    m.reply(mess.wait); // Balas dengan pesan penantian
    let { pinterest } = require('./lib/scraper');
   let anu = await pinterest(`${command}`);
   let result = anu[Math.floor(Math.random() * anu.length)];
    sky.sendMessage(m.chat, { image: { url: result }, caption: mess.done }, { quoted: m });
    }
    break;
case 'pantun': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
let zeltoria = await fetch(`https://api.lolhuman.xyz/api/random/pantun?apikey=GataDios`)
let hasil = await zeltoria.json()
 m.reply(`${hasil.result}`.trim())
 }
 break
        case 'totag': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
               if (!m.isGroup) throw mess.group
               if (!isBotAdmins) throw mess.botAdmin
               if (!isAdmins) throw mess.admin
               if (!m.quoted) throw `Reply pesan dengan caption ${prefix + command}`
               sky.sendMessage(m.chat, { forward: m.quoted.fakeObj, mentions: participants.map(a => a.id) })
               }
               break
                               case 'infonegara':{
    const countryName = args.join(' ');

    if (!countryName) {
        m.reply('Masukkan nama negara terlebih dahulu.');
        return;
    }

    const apiUrl = `https://restcountries.com/v3.1/name/${countryName}`;
    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            const countryInfo = data[0];

            if (countryInfo) {
const infoNegara = `
Informasi Negara ${countryInfo.name.common}
Wilayah: ${countryInfo.region}
Sub Wilayah: ${countryInfo.subregion}
Ibukota: ${countryInfo.capital}
Bahasa Resmi: ${countryInfo.languages[Object.keys(countryInfo.languages)[0]]}
Mata Uang: ${countryInfo.currencies[Object.keys(countryInfo.currencies)[0]].name} (${countryInfo.currencies[Object.keys(countryInfo.currencies)[0]].symbol})
Populasi: ${countryInfo.population}
Luas Wilayah: ${countryInfo.area} km²
Domain Internet: ${countryInfo.tld}
Batas Negara: ${countryInfo.borders.join(', ')}
Zona Waktu: ${countryInfo.timezones.join(', ')}
                `;

                replygc(infoNegara);
            } else {
                m.reply('Negara tidak ditemukan.');
            }
        })
        .catch(error => {
            console.error('Terjadi kesalahan:', error);
            m.reply('Terjadi kesalahan saat mengambil informasi negara.');
        });
    break;
}
case 'hargabbm':
    if (!text) throw 'Gunakan: *travelcost [jarak dalam kilometer] [harga bahan bakar per liter]\nContoh hargabbm 18 12000*';   
    const distance = parseFloat(args[0]);
    const fuelPrice = parseFloat(args[1]);

    if (isNaN(distance) || isNaN(fuelPrice) || distance <= 0 || fuelPrice <= 0) {
        throw 'Masukkan angka yang valid untuk jarak dan harga bahan bakar.';
    }

    // Estimating fuel consumption at 10 kilometers per liter
    const fuelConsumption = distance / 10;

    // Calculating total cost
    const totalCost = fuelConsumption * fuelPrice;

    const replyMessage = `Estimasi biaya perjalanan:\nJarak: ${distance} kilometer\nHarga bahan bakar: Rp${fuelPrice} per liter\nBiaya bahan bakar: Rp${totalCost.toFixed(0)}0`;
    m.reply(replyMessage);
break;

               case 'group': case 'grup': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
                if (args[0].toLowerCase() === 'close'){
                    await sky.groupSettingUpdate(m.chat, 'announcement').then((res) => m.reply(`Sukses Menutup Group`)).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0].toLowerCase() === 'open'){
                    await sky.groupSettingUpdate(m.chat, 'not_announcement').then((res) => m.reply(`Sukses Membuka Group`)).catch((err) => m.reply(jsonformat(err)))
                } else {
                    sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} Open`,`${command.charAt(0).toUpperCase()+command.slice(1)} Close`])
             }
            }
            break
            case 'editinfo': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
             if (args[0].toLowerCase() === 'open'){
                await sky.groupSettingUpdate(m.chat, 'unlocked').then((res) => m.reply(`Sukses Membuka Edit Info Group`)).catch((err) => m.reply(jsonformat(err)))
             } else if (args[0].toLowerCase() === 'close'){
                await sky.groupSettingUpdate(m.chat, 'locked').then((res) => m.reply(`Sukses Menutup Edit Info Group`)).catch((err) => m.reply(jsonformat(err)))
             } else {
                sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} Open`,`${command.charAt(0).toUpperCase()+command.slice(1)} Close`])
            }
            }
            break
            case 'antilinkgc': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (Antilinkgc) return m.reply('Already activated')
ntlinkgc.push(from)
fs.writeFileSync('./database/antilinkgc.json', JSON.stringify(ntlinkgc))
m.reply('Success in turning on AntilinkGc in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!Antilinkgc) return m.reply('Already deactivated')
let off = ntlinkgc.indexOf(from)
ntlinkgc.splice(off, 1)
fs.writeFileSync('./database/antilinkgc.json', JSON.stringify(ntlinkgc))
m.reply('Success in turning off AntilinkGc in this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
            case 'antivirtex': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (antiVirtex) return m.reply('Already activated')
ntvirtex.push(from)
fs.writeFileSync('./database/antivirtex.json', JSON.stringify(ntvirtex))
m.reply('Success in turning on antiVirtex in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!antiVirtex) return m.reply('Already deactivated')
let off = ntvirtex.indexOf(from)
ntvirtex.splice(off, 1)
fs.writeFileSync('./database/antivirtex.json', JSON.stringify(ntvirtex))
m.reply('Success in turning off antiVirtex in this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
case 'antiwame': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (antiWame) return m.reply('Already activated')
ntwame.push(from)
fs.writeFileSync('./database/antiwame.json', JSON.stringify(ntwame))
m.reply('Success in turning on antiWame in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!antiWame) return m.reply('Already deactivated')
let off = ntwame.indexOf(from)
ntwame.splice(off, 1)
fs.writeFileSync('./database/antiwame.json', JSON.stringify(ntwame))
m.reply('Success in turning off antiWame in this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
case 'ayat': {
    const command = m.body.split(' '); // Memisahkan perintah menjadi komponen-komponennya
    const surahNumber = command[1]; // Nomor surah yang diberikan oleh pengguna
    const ayatNumber = command[2]; // Nomor ayat yang diberikan oleh pengguna
    if (!surahNumber || !ayatNumber) {
        m.reply('Silakan masukkan nomor surah dan ayat yang valid.');
        return;
    }
    const apiUrl = `https://api.alquran.cloud/ayah/${surahNumber}:${ayatNumber}`;
    axios.get(apiUrl)
        .then((response) => {
            const ayatData = response.data.data;
            const text = ayatData.text;
            const surah = ayatData.surah.englishName;
            const juz = ayatData.juz;
            const manzil = ayatData.manzil;
            const page = ayatData.page;
            const result = `📖 Ayat Al-Quran 📖\n\nSurah ${surahNumber}, Ayat ${ayatNumber}\nSurahName : ${surah}\nJuz : ${juz}\nManzil : ${manzil}\nHalaman : ${page}\nType : Al-Quran\n\nisi :\n\n${text}`;
            replygc(result);
        })
        .catch((error) => {
            console.error('Error:', error);
            m.reply('Maaf, terjadi kesalahan saat mengambil informasi ayat Al-Quran. Pastikan nomor surah dan ayat yang Anda masukkan benar.');
        });
}
break;
case 'carisurah': {
    const surahName = m.body.substring(10).trim(); // Nama surah yang diberikan oleh pengguna

    if (!surahName) {
        m.reply('Silakan masukkan Kode 1-114.');
        return;
    }

    // Mengambil informasi Surah dari API Al-Quran
    fetch(`https://api.alquran.cloud/v1/surah/${surahName}`)
        .then(response => response.json())
        .then(data => {
            if (!data.data) {
                m.reply('Surah dengan nama tersebut tidak ditemukan.');
                return;
            }

            const surahData = data.data;
            const surahName = surahData.englishName;
            const ayatCount = surahData.ayahs.length;

            // Menggabungkan semua ayat Surah menjadi satu teks
            let surahText = `Nama Surah: ${surahName}\nJumlah Ayat: ${ayatCount}\n\n`;

            surahData.ayahs.forEach(ayah => {
                surahText += `Ayat ${ayah.number}: ${ayah.text}\n`;
            });

            // Mengirim satu pesan dengan semua ayat
            m.reply(surahText);
        })
        .catch(error => {
            console.error('Gagal mengambil informasi Surah:', error);
            m.reply('Maaf, terjadi kesalahan saat mencari Surah. Pastikan nama Surah yang Anda masukkan benar.');
        });
}
break;

case 'antibatu': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (AntiBatu) return m.reply('Already activated')
ntibatu .push(from)
fs.writeFileSync('./database/antibatu.json', JSON.stringify(ntibatu ))
m.reply('Success in turning on antiBatu in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!AntiBatu) return m.reply('Already deactivated')
let off = ntibatu .indexOf(from)
ntibatu .splice(off, 1)
fs.writeFileSync('./database/antibatu.json', JSON.stringify(ntibatu ))
m.reply('Success in turning off AntiBatu in this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
             case 'antiemoji': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (antiEmote) return m.reply('Already activated')
ntiemoji .push(from)
fs.writeFileSync('./database/antiemoji.json', JSON.stringify(ntiemoji ))
m.reply('Success in turning on AntiEmot in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!antiEmote) return m.reply('Already deactivated')
let off = ntiemoji .indexOf(from)
ntiemoji .splice(off, 1)
fs.writeFileSync('./database/antiemoji.json', JSON.stringify(ntiemoji ))
m.reply('Success in turning off AntiEmote in this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
case 'investasi': {
    if (!text) throw `Penggunaan: *investasi [jumlah] 1 = 1 adalah 1 menit`	
    m.reply('Silahkan Tunggu Sesuai Waktu Yang kamu Berikan')		    
    const investAmount = parseInt(args[0]); // Jumlah uang yang akan diinvestasikan
    const investTime = parseInt(args[1]); // Waktu investasi dalam menit
    const userBalance = db.data.users[m.sender].balance; // Saldo pengguna

    if (investAmount <= 0 || investTime <= 0 || investAmount > userBalance) {
        return m.reply('Investasi tidak valid atau saldo tidak mencukupi.');
    }

    // Simulasi hasil investasi (misalnya, hasil acak positif atau negatif)
    const randomResult = Math.random() < 0.5 ? 'untung' : 'rugi';

    // Waktu untuk menunggu hasil investasi
    setTimeout(() => {
        let result = `Hasil investasi: ${randomResult}\n`;
        if (randomResult === 'untung') {
            const profitAmount = investAmount * 0.2; // Jumlah untung (misalnya, 20% dari investasi)
            db.data.users[m.sender].balance += profitAmount;
            result += `Selamat! Anda mendapatkan +${profitAmount} balance.`;
        } else {
            // Jika rugi, saldo dikurangi dengan jumlah investasi
            db.data.users[m.sender].balance -= investAmount;
            result += `Maaf, Anda kehilangan -${investAmount} balance.`;
        }

        m.reply(result);
    }, investTime * 60000); // Konversi menit menjadi milidetik (1 menit = 60.000 milidetik)
}
break;
            case 'simih':{
if (!m.isGroup) throw mess.group
if (!isBotAdmins) throw mess.botAdmin
if (!isAdmins) throw mess.admin
if (!q) return m.reply(`Pilih on atau off`)
if (args[0] === "on") {
if (SimiActive) return m.reply('Already activated')
simion.push(from)
fs.writeFileSync('./database/simion.json', JSON.stringify(simion))
m.reply('Success in turning on Simi in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
sky.sendMessage(from, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nSimi Online!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!SimiActive) return m.reply('Already deactivated')
let off = nttoxic.indexOf(from)
simion.splice(off, 1)
fs.writeFileSync('./database/simion.json', JSON.stringify(simion))
m.reply('Success in turning off Simi in this group')
} else {
  await m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`)
  }
  }
  break
      case 'banchat':{
if (!isCreator) throw mess.owner
if (!q) return m.reply(`Pilih on atau off`)
if (args[0] === "on") {
if (bocet) return m.reply('Already activated')
bacat.push(from)
fs.writeFileSync('./database/bacat.json', JSON.stringify(bacat))
m.reply('BanChat Active')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
sky.sendMessage(from, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nBanchat On`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!bocet) return m.reply('Already deactivated')
let off = nttoxic.indexOf(from)
bacat.splice(off, 1)
fs.writeFileSync('./database/bacat.json', JSON.stringify(bacat))
m.reply('Banchat Off')
} else {
  await m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`)
  }
  }
  break
case 'antilinktiktok': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (AntiLinkTiktok) return m.reply('Already activated')
ntlinktt.push(from)
fs.writeFileSync('./database/antilinktiktok.json', JSON.stringify(ntlinktt))
m.reply('Success in turning on antiLinkTiktok in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!AntiLinktiktok) return m.reply('Already deactivated')
let off = ntlinktt.indexOf(from)
ntlinktt.splice(off, 1)
fs.writeFileSync('./database/antilinktiktok.json', JSON.stringify(ntlinktt))
m.reply('Success in turning off antiLinkTiktok n this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
case 'antilinkyt': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (AntiLinkYt) return m.reply('Already activated')
ntlinkyt.push(from)
fs.writeFileSync('./database/antilinkyt.json', JSON.stringify(ntlinkyt))
m.reply('Success in turning on antiLinkYt in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!AntiLinkYt) return m.reply('Already deactivated')
let off = ntlinktt.indexOf(from)
ntlinkyt.splice(off, 1)
fs.writeFileSync('./database/antilinkyt.json', JSON.stringify(ntlinkyt))
m.reply('Success in turning off antiLinkYt in this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
case 'antilinkall': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (AntiLinkAll) return m.reply('Already activated')
ntlinkall.push(from)
fs.writeFileSync('./database/antilinkall.json', JSON.stringify(ntlinkall))
m.reply('Success in turning on antiLinkAll in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!AntiLinkAll) return m.reply('Already deactivated')
let off = ntlinkall.indexOf(from)
ntlinkall.splice(off, 1)
fs.writeFileSync('./database/antilinkall.json', JSON.stringify(ntlinkall))
m.reply('Success in turning off antiLinkAll in this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
case 'antilinktwitter': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (AntiLinkTwitter) return m.reply('Already activated')
ntlinktwt.push(from)
fs.writeFileSync('./database/antilinktwitter.json', JSON.stringify(ntlinktwt))
m.reply('Success in turning on antiLinkTwitter in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!AntiLinkTwitter) return m.reply('Already deactivated')
let off = ntlinktwt.indexOf(from)
ntlinktwt.splice(off, 1)
fs.writeFileSync('./database/antilinktwitter.json', JSON.stringify(ntlinktwt))
m.reply('Success in turning off antiLinkTwitter in this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
             case 'getcase':
if (!isCreator) throw mess.owner
if (!text) throw 'input case'
const getCase = (cases) => {
return "case"+`'${cases}'`+fs.readFileSync("sky.js").toString().split('case \''+cases+'\'')[1].split("break")[0]+"break"
}
m.reply(`${getCase(q)}`)
break
case 'antilinktelegram': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (AntiLinkTelegram) return m.reply('Already activated')
ntlinktg.push(from)
fs.writeFileSync('./database/antilinktelegram.json', JSON.stringify(ntlinktg))
m.reply('Success in turning on antiLinkTelegram in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!AntiLinkTelegram) return m.reply('Already deactivated')
let off = ntlinktwt.indexOf(from)
ntlinktg.splice(off, 1)
fs.writeFileSync('./database/antilinktelegram.json', JSON.stringify(ntlinktg))
m.reply('Success in turning off antiLinkTelegram in this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
case 'antilinkinstagram': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (antiLinkInstagram) return m.reply('Already activated')
ntlinkig.push(from)
fs.writeFileSync('./database/antilinkinstagram.json', JSON.stringify(ntlinktg))
m.reply('Success in turning on antilinkinstagram in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!AntiLinkInstagram) return m.reply('Already deactivated')
let off = ntlinkig.indexOf(from)
ntlinkig.splice(off, 1)
fs.writeFileSync('./database/antilinkinstagram.json', JSON.stringify(ntlinkig))
m.reply('Success in turning off antiLinkInstagram in this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
case 'antilinkfacebook': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (AntiLinkFacebook) return m.reply('Already activated')
ntlinkfb.push(from)
fs.writeFileSync('./database/antilinkfacebook.json', JSON.stringify(ntlinkfb))
m.reply('Success in turning on antiLinkFacebook in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!AntiLinkFacebook) return m.reply('Already deactivated')
let off = ntlinkfb.indexOf(from)
ntlinkfb.splice(off, 1)
fs.writeFileSync('./database/antilinkfacebook.json', JSON.stringify(ntlinkfb))
m.reply('Success in turning off antiLinkFacebook in this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
case 'autosticker': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (!autosticker) return m.reply('Already activated')
autosticker.push(from)
fs.writeFileSync('./database/autostickee.json', JSON.stringify(autosticker))
m.reply('Success in turning on autosticker in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!autosticker) return m.reply('Already deactivated')
let off = autosticker.indexOf(from)
autosticker.splice(off, 1)
fs.writeFileSync('./database/autosticker.json', JSON.stringify(autosticker))
m.reply('Success in turning off autosticker in this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
     case 'antipushkontakv1': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) return m.reply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].antipushkontakv1) return m.reply(`Sudah Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antipushkontakv1 = true
                    m.reply(`Anti Push Kontak Aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].antipushkontakv1) return m.reply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antipushkontakv1 = false
                    m.reply(`Anti Push kontak Nonaktif 🕊️`)
                } else {
                    m.reply(`Mode ${command}\n\n\nKetik ${prefix + command}on/off`)
                }
            }
            break
            case 'antipushkontakv2': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) return m.reply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].antipushkontakv2) return m.reply(`Sudah Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antipushkontakv2 = true
                    m.reply(`Anti Push Kontak Aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].antipushkontakv2) return m.reply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antipushkontakv2 = false
                    m.reply(`Anti Push kontak Nonaktif 🕊️`)
                } else {
                    m.reply(`Mode ${command}\n\n\nKetik ${prefix + command}on/off`)
                }
            }
            case 'sound': {
            
    const soundNumber = parseInt(args[0]);

    if (isNaN(soundNumber) || soundNumber < 1 || soundNumber > 161) {
        throw 'Masukkan nomor suara antara 1 dan 161.';
    }
m.reply(mess.wait)
    const soundURL = `https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/sound${soundNumber}.mp3`;
    const soundBuffer = await getBuffer(soundURL);

    await sky.sendMessage(m.chat, { audio: soundBuffer, mimetype: 'audio/mp4', ptt: true }, { quoted: m });
}
break
case 'ltbb_': {
    const ltbbNumber = parseInt(args[0]);

    if (isNaN(ltbbNumber) || ltbbNumber < 2 || ltbbNumber > 338) {
        throw 'Masukkan ltbb_ 001 sampai 338.';
    }
    
    m.reply(mess.wait);
    
    const ltbbName = `ltbb_${String(ltbbNumber).padStart(3, '0')}`;
    const ltbbURL = `https://www.nonstick.com/audio/soundsource/Bugs_Bunny/${ltbbName}.mp3`;
    const ltbbBuffer = await getBuffer(ltbbURL);

    await sky.sendMessage(m.chat, { audio: ltbbBuffer, mimetype: 'audio/mp4', ptt: true }, { quoted: m });
}
break;
            case 'gitclone':
if (!args[0]) return m.reply(`Example :\n${prefix}${command} input link`)
if (!isUrl(args[0]) && !args[0].includes('github.com')) return m.reply(`Link Salah!!`)
let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
let [, user, repo] = args[0].match(regex1) || []
repo = repo.replace(/.git$/, '')
let url = `https://api.github.com/repos/${user}/${repo}/zipball`
let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
sky.sendMessage(m.chat, { document: { url: url }, fileName: filename+'.zip', mimetype: 'application/zip' }, { quoted: m }).catch((err) => m.reply(mess.error))
break
case 'welcome':{
if (!m.isGroup) throw mess.group
if (!isBotAdmins) throw mess.botAdmin
if (!isAdmins) throw mess.admin
if (!q) return m.reply(`Pilih on atau off`)
if (args[0] === "on") {
if (isWelcome) return m.reply(`Welcome sudah aktif`)
welcome.push(m.chat)
fs.writeFileSync('./database/welcome.json', JSON.stringify(welcome, null, 2))
m.reply(`Sukses mengaktifkan welcome di grup ini`)
} else if (args[0] === "off") {
if (!isWelcome) return m.reply(`Welcome sudah nonaktif`)
var posi = welcome.indexOf(m.chat)
welcome.splice(posi, 1)
fs.writeFileSync('./database/welcome.json', JSON.stringify(welcome, null, 2))
m.reply(`Sukses menonaktifkan welcome di grup ini`)
} else {
m.reply(`Pilih on atau off`)
}
}
break
            case 'mute': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
                if (args[0].toLowerCase() === "on") {
                if (db.data.chats[m.chat].mute) return m.reply(`Sudah Aktif Sebelumnya`)
                db.data.chats[m.chat].mute = true
                m.reply(`${sky.user.name} telah di mute di group ini !`)
                } else if (args[0].toLowerCase() === "off") {
                if (!db.data.chats[m.chat].mute) return m.reply(`Sudah Tidak Aktif Sebelumnya`)
                db.data.chats[m.chat].mute = false
                m.reply(`${sky.user.name} telah di unmute di group ini !`)
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} On`,`${command.charAt(0).toUpperCase()+command.slice(1)} Off`])
                }
             }
             break
            case 'linkgroup': case 'linkgc': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                let response = await sky.groupInviteCode(m.chat)
                sky.sendText(m.chat, `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true })
            }
            break
            case 'ephemeral': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
                if (args[0].toLowerCase() === '1') {
                    await sky.groupToggleEphemeral(m.chat, 1*24*3600).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0].toLowerCase() === '7') {
                    await sky.groupToggleEphemeral(m.chat, 7*24*3600).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0].toLowerCase() === '90') {
                    await sky.groupToggleEphemeral(m.chat, 90*24*3600).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0].toLowerCase() === 'off') {
                    await sky.groupToggleEphemeral(m.chat, 0).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else {
                    sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", ["Ephemeral 1","Ephemeral 7","Ephemeral 90","Ephemeral Disable"])
                }
            }
            break
             case 'setnamabot': case 'setnamebot': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!text) throw `Example : ${prefix + command} WhatsApp ✅`
            let name = await sky.updateProfileName(text)
            m.reply(`Successfully renamed bot to ${name}`)
            }
            break
            case 'setstatus': case 'setbiobot': case 'setbotbio': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!text) throw `this is a WhatsApp Bot named sky-Morou`
            let name = await sky.updateProfileStatus(text)
            m.reply(`Successfully changed bot bio status to ${name}`)
            }
            break
case'demoteall':
if (!isCreator) return m.reply('*Khusus Owner Bot*')
if (!m.isGroup) return m.reply('Buat Di Group Bodoh')
if (!isBotAdmins) return m.reply('Bot Bukan Admin Cuy')
if (!isAdmins) return m.reply('Lah Dikira Admin Group Kali')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
sky.groupParticipantsUpdate(from, mems, 'demote')
break
//=================================================//
case'promoteall':
if (!isCreator) return m.reply('*Khusus Owner Bot*')
if (!m.isGroup) return m.reply('Buat Di Group Bodoh')
if (!isBotAdmins) return m.reply('Bot Bukan Admin Cuy')
if (!isAdmins) return m.reply('Lah Dikira Admin Group Kali')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
sky.groupParticipantsUpdate(from, mems, 'promote')
break
            case 'anticall': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!isCreator) throw mess.owner
                let ciko = db.data.settings[botNumber].anticall
                if (args[0].toLowerCase() === "on") {
                if (ciko) return m.reply(`Sudah Aktif Sebelumnya`)
                ciko = true
                m.reply(`AntiCall Aktif !`)
                } else if (args[0].toLowerCase() === "off") {
                if (!ciko) return m.reply(`Sudah Tidak Aktif Sebelumnya`)
                ciko = false
                m.reply(`AntiCall Tidak Aktif !`)
                } else {
                sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} On`,`${command.charAt(0).toUpperCase()+command.slice(1)} Off`])
                }
             }
             break
      case 'del': case 'delete': case 'd':{         
         if (!isBotAdmins) return m.reply(mess.botAdmin)
if (!isAdmins) throw mess.admin     
sky.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: m.quoted.id,
participant: m.quoted.sender
}
})
}
break
            case 'bcgc': case 'bcgroup': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) throw mess.owner
                if (!text) throw `Text mana?\n\nExample : ${prefix + command} fatih-san`
                let getGroups = await sky.groupFetchAllParticipating()
                let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
                let anu = groups.map(v => v.id)
                m.reply(`Mengirim Broadcast Ke ${anu.length} Group Chat, Waktu Selesai ${anu.length * 1.5} detik`)
                for (let i of anu) {
                    await sleep(1500)
                      let txt = `「 Broadcast Bot 」\n\n${text}`
                      sky.sendText(i, txt)
                    }
                m.reply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
            }
            break
            case 'bc': case 'broadcast': case 'bcall': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) throw mess.owner
                if (!text) throw `Text mana?\n\nExample : ${prefix + command} ikyy-san`
                let anu = await store.chats.all().map(v => v.id)
                m.reply(`Mengirim Broadcast Ke ${anu.length} Chat\nWaktu Selesai ${anu.length * 1.5} detik`)
    		for (let yoi of anu) {
    		    await sleep(1500)
    		    let txt = `「 Broadcast Bot 」\n\n${text}`
                      sky.sendText(yoi, txt)    		  
    		}
    		m.reply('Sukses Broadcast')
            }
            break
              case 'infochat': {
                if (!m.quoted) m.reply('Reply Pesan')
                let msg = await m.getQuotedObj()
                if (!m.quoted.isBaileys) return 'Pesan tersebut bukan dikirim oleh bot!'
                let teks = ''
                for (let i of msg.userReceipt) {
                    let read = i.readTimestamp
                    let unread = i.receiptTimestamp
                    let waktu = read ? read : unread
                    teks += `👤 @${i.userJid.split('@')[0]}\n`
                    teks += `⏳ *Waktu :* ${moment(waktu * 1000).format('DD/MM/YY HH:mm:ss')}\n📈 *Status :* ${read ? 'Dibaca' : 'Terkirim'}\n\n`
                }
                sky.sendTextWithMentions(m.chat, teks, m)
            }
            break
            case 'q': case 'quoted': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!m.quoted) return m.reply('Reply Pesannya!!')
		let wokwol = await sky.serializeM(await m.getQuotedObj())
		if (!wokwol.quoted) return m.reply('Pesan Yang anda reply tidak mengandung reply')
		await wokwol.quoted.copyNForward(m.chat, true)
            }
	    break
	    case'delsesi':
            case 'clearsession': {
                if (!isCreator) return m.reply(mess.owner)
                fs.readdir("./sky", async function(err, files) {
                    if (err) {
                        console.log('Unable to scan directory: ' + err);
                        return m.reply('Unable to scan directory: ' + err);
                    }                    
                    let filteredArray = await files.filter(item => item.startsWith("pre-key") ||
                        item.startsWith("sender-key") || item.startsWith("sky-") || item.startsWith("app-state") || item.startsWith("session")
                    )
                    console.log(filteredArray.length);
                    let teks = `Terdeteksi ${filteredArray.length} file sampah\n\n`
                    if (filteredArray.length == 0) return m.reply(teks)
                    filteredArray.map(function(e, i) {
                        teks += (i + 1) + `. ${e}\n`
                    })
                    m.reply(teks)
                    await sleep(2000)
                    m.reply("Menghapus file sampah...")
                    await filteredArray.forEach(function(file) {
                        fs.unlinkSync(`./sky/${file}`)
                    });
                    await sleep(2000)
                    m.reply("Berhasil menghapus semua sampah di folder sky")
                });
            }
            break
            case 'listpc': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                 let anu = await store.chats.all().filter(v => v.id.endsWith('.net')).map(v => v.id)
                 let teks = `⬣ *LIST PERSONAL CHAT*\n\nTotal Chat : ${anu.length} Chat\n\n`
                 for (let i of anu) {
                     let nama = store.messages[i].array[0].pushName
                     teks += `⬡ *Nama :* ${nama}\n⬡ *User :* @${i.split('@')[0]}\n⬡ *Chat :* https://wa.me/${i.split('@')[0]}\n\n────────────────────────\n\n`
                 }
                 sky.sendTextWithMentions(m.chat, teks, m)
             }
             break
                case 'listgc': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                 let anu = await store.chats.all().filter(v => v.id.endsWith('@g.us')).map(v => v.id)
                 let teks = `⬣ *LIST GROUP CHAT*\n\nTotal Group : ${anu.length} Group\n\n`
                 for (let i of anu) {
                     let metadata = await sky.groupMetadata(i)
                     teks += `⬡ *Nama :* ${metadata.subject}\n⬡ *Owner :* ${metadata.owner !== undefined ? '@' + metadata.owner.split`@`[0] : 'Tidak diketahui'}\n⬡ *ID :* ${metadata.id}\n⬡ *Dibuat :* ${moment(metadata.creation * 1000).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}\n⬡ *Member :* ${metadata.participants.length}\n\n────────────────────────\n\n`
                 }
                 sky.sendTextWithMentions(m.chat, teks, m)
             }
             break
             case 'listonline': case 'liston': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                    let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : m.chat
                    let online = [...Object.keys(store.presences[id]), botNumber]
                    sky.sendText(m.chat, 'List Online:\n\n' + online.map(v => '⭔ @' + v.replace(/@.+/, '')).join`\n`, m, { mentions: online })
             }
             break
            case 'sticker': case 's': case 'stickergif': case 'sgif': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
           if (/image/.test(mime)) {
           m.reply(mess.wait)
                let media = await sky.downloadMediaMessage(qmsg)
                let encmedia = await sky.sendImageAsSticker(m.chat, media, m, { packname: global.packname, author: global.author })
                await fs.unlinkSync(encmedia)
            } else if (/video/.test(mime)) {
            m.reply(mess.wait)
                if (qmsg.seconds > 11) return m.reply('Maksimal 10 detik!')
                let media = await sky.downloadMediaMessage(qmsg)
                let encmedia = await sky.sendVideoAsSticker(m.chat, media, m, { packname: global.packname, author: global.author })
                await fs.unlinkSync(encmedia)
            } else {
                m.reply(`Kirim/reply gambar/video/gif dengan caption ${prefix + command}\nDurasi Video/Gif 1-9 Detik`)
                }
            }
            break
            case 'stickerwm': case 'swm': case 'stickergifwm': case 'sgifwm': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let [teks1, teks2] = text.split`|`
                if (!teks1) throw `Kirim/reply image/video dengan caption ${prefix + command} teks1|teks2`
                if (!teks2) throw `Kirim/reply image/video dengan caption ${prefix + command} teks1|teks2`
            	m.reply(mess.wait)
                if (/image/.test(mime)) {
                    let media = await sky.downloadMediaMessage(qmsg)
                    let encmedia = await sky.sendImageAsSticker(m.chat, media, m, { packname: teks1, author: teks2 })
                    await fs.unlinkSync(encmedia)
                } else if (/video/.test(mime)) {
                    if ((quoted.msg || quoted).seconds > 11) return m.reply('Maksimal 10 detik!')
                    let media = await sky.downloadMediaMessage(qmsg)
                    let encmedia = await sky.sendVideoAsSticker(m.chat, media, m, { packname: teks1, author: teks2 })
                    await fs.unlinkSync(encmedia)
                } else {
                    throw `Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`
                }
            }
            break           
            case 'ebinary': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!text) throw `Example : ${prefix + command} text`
            let { eBinary } = require('./lib/binary')
            let eb = await eBinary(text)
            m.reply(eb)
        }
        break
            case 'dbinary': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!text) throw `Example : ${prefix + command} text`
            let { dBinary } = require('./lib/binary')
            let db = await dBinary(text)
            m.reply(db)
        }
        break
// Case untuk menghitung selisih waktu antara dua tanggal
case 'count': {
  const datePattern = /^(\d{2})-(\d{2})-(\d{4})$/;

  const startDateMatch = args[0].match(datePattern);
  const endDateMatch = args[1].match(datePattern);

  if (!startDateMatch || !endDateMatch) {
    await sky.sendText(from, 'Gunakan perintah dengan format yang benar, contoh: "count DD-MM-YYYY DD-MM-YYYY".');
    return;
  }

  const startDate = new Date(`${startDateMatch[3]}-${startDateMatch[2]}-${startDateMatch[1]}`);
  const endDate = new Date(`${endDateMatch[3]}-${endDateMatch[2]}-${endDateMatch[1]}`);

  if (isNaN(startDate) || isNaN(endDate)) {
    await sky.sendText(from, 'Tanggal yang dimasukkan tidak valid.');
    return;
  }

  const timeDifference = endDate - startDate;
  const millisecondsPerMinute = 60 * 1000; // Jumlah milidetik dalam satu menit
  const millisecondsPerHour = 60 * millisecondsPerMinute; // Jumlah milidetik dalam satu jam
  const millisecondsPerDay = 24 * millisecondsPerHour; // Jumlah milidetik dalam satu hari

  const totalDays = Math.floor(timeDifference / millisecondsPerDay);
  const totalHours = Math.floor((timeDifference % millisecondsPerDay) / millisecondsPerHour);
  const totalMinutes = Math.floor((timeDifference % millisecondsPerHour) / millisecondsPerMinute);
  const totalWeeks = Math.floor(totalDays / 7);

  const resultMessage = `Selisih waktu antara tanggal ${args[0]} dan ${args[1]} adalah:\n\n(${totalDays} hari) (${totalWeeks} minggu).`;

  await sky.sendText(from, resultMessage);
}
break;
case 'geturl': {				
         	if (!text) throw `Example : ${prefix + command} url/link`
             m.reply(mess.wait)
             let igmk = await getBuffer(`${text}`)
             sky.sendMessage(m.chat, { image: igmk}, { quoted: m }).catch((err) => m.reply(mess.error))
         	}
         break
            case 'emojimix': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		let [emoji1, emoji2] = text.split`+`
		if (!emoji1) throw `Example : ${prefix + command} 😅+🤔`
		if (!emoji2) throw `Example : ${prefix + command} 😅+🤔`
		let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`)
		for (let res of anu.results) {
		    let encmedia = await sky.sendImageAsSticker(m.chat, res.url, m, { packname: global.packname, author: global.author, categories: res.tags })
		    await fs.unlinkSync(encmedia)
		}
	    }
	    break	 
	    case 'emojimix2': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
	    if (!text) throw `Example : ${prefix + command} 😅`
		let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(text)}`)
		for (let res of anu.results) {
		    let encmedia = await sky.sendImageAsSticker(m.chat, res.url, m, { packname: global.packname, author: global.author, categories: res.tags })
		    await fs.unlinkSync(encmedia)
		}
	    }
	    break
case 'joincall':{
sky.relayMessage(m.chat, {
		scheduledCallCreationMessage: {
		callType: "VIDEO",		
		scheduledTimestampMs: 12000,
		title: botname,		
		inviteCode: 'wa.me/6283870640443',
		}
	}, {})
	}
	break
	            case 'attp':
                try {
                if (args1.length == 0) return m.reply(`Example: ${prefix + command} Yori Hosting`)
                await sky.sendMessage(m.chat, {sticker: {url:`https://api.lolhuman.xyz/api/attp?apikey=GataDios&text=${text}` }}, { quoted: m })
            } catch (e) {
                m.reply(mess.error)
            }
            break
 case 'ceklimit': case 'checklimit': case 'limit':{
     let who
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender
    else who = m.sender
    if (typeof db.data.users[who] == 'undefined') throw 'Pengguna tidak ada didalam data base'
    m.reply(`Nomer : ${who}\n\nLimit\n> ${db.data.users[who].limit} 🪙\n\nBalance\n> Rp.${db.data.users[who].balance} 💸`)
					}
					break
					case 'buylimit': {
  const pricePerLimit = 150; // Harga per limit dalam balance
  const amountToBuy = parseInt(args[0]);
  if (isNaN(amountToBuy) || amountToBuy <= 0) {
    throw 'Gunakan: *.buylimit <jumlah>*\nContoh: *.buylimit 5*';
  }
  const totalCost = pricePerLimit * amountToBuy;
  if (db.data.users[m.sender].balance < totalCost) {
    throw 'Balance Anda tidak mencukupi untuk membeli limit sebanyak ini.';
  }
  db.data.users[m.sender].balance -= totalCost;
  db.data.users[m.sender].limit += amountToBuy;
  m.reply(`Anda telah membeli ${amountToBuy} limit dengan harga ${totalCost} balance.`);
  break;
}

					case 'getlimit':{
				 if (!isCreator) throw mess.owner
					let moneyy = `${Math.floor(Math.random() * 999999999999999)}`.trim()
db.data.users[m.sender].limit += moneyy * 1
    m.reply(`Bot Sudah Memasukan limit Sebesar ${moneyy} Ke Owner`)
    }
    break
    	case 'getbalance':{
				 if (!isCreator) throw mess.owner
					let moneyy = `${Math.floor(Math.random() * 10000)}`.trim()
db.data.users[m.sender].balance += moneyy * 1
    m.reply(`Bot Sudah Memasukan limit Sebesar ${moneyy} Ke Owner`)
    }
    break
    case 'tflimit': {
  if (isGroup) {
    const [userMention, amountStr] = args;    
    if (!userMention || !amountStr) {
      throw 'Gunakan: *.tflimit @user jumlahLimit*';
    }    
    const targetUser = m.mentionedJid[0];
    const amount = parseFloat(amountStr);    
    if (isNaN(amount) || amount <= 0) {
      throw 'Jumlah limit harus berupa angka positif.';
    }    
    const senderLimit = db.data.users[m.sender].limit;    
    if (senderLimit < amount) {
      throw 'Limit Anda tidak mencukupi untuk mentransfer sejumlah ini.';
    }    
    if (!db.data.users[targetUser]) {
      throw 'Pengguna yang Anda tuju tidak ditemukan.';
    }    
    db.data.users[m.sender].limit -= amount;
    db.data.users[targetUser].limit += amount;    
    m.reply(`Anda telah mentransfer ${amount} limit ke @${targetUser.replace('@s.whatsapp.net', '')}.`);
  } else {
    throw 'Perintah ini hanya dapat digunakan dalam grup.';
  }
  break;
}
    case 'tfbalance': {
  if (isGroup) {
    const [userMention, amountStr] = args;    
    if (!userMention || !amountStr) {
      throw 'Gunakan: *.tfbalance @user jumlahbalance*';
    }    
    const targetUser = m.mentionedJid[0];
    const amount = parseFloat(amountStr);    
    if (isNaN(amount) || amount <= 0) {
      throw 'Jumlah balance harus berupa angka positif.';
    }    
    const senderbalance = db.data.users[m.sender].balance;    
    if (senderbalance < amount) {
      throw 'balance Anda tidak mencukupi untuk mentransfer sejumlah ini.';
    }    
    if (!db.data.users[targetUser]) {
      throw 'Pengguna yang Anda tuju tidak ditemukan.';
    }    
    db.data.users[m.sender].balance -= amount;
    db.data.users[targetUser].balance += amount;    
    m.reply(`Anda telah mentransfer ${amount} balance ke @${targetUser.replace('@s.whatsapp.net', '')}.`);
  } else {
    throw 'Perintah ini hanya dapat digunakan dalam grup.';
  }
  break;
}
            case 'attp2':
                try {
                    if (args1.length == 0) return m.reply(`Example: ${prefix + command} Yori Hosting`)
                    await sky.sendMessage(m.chat, {sticker: {url:`https://api.lolhuman.xyz/api/attp2?apikey=GataDios&text=${args}` }}, { quoted: m })
                } catch (e) {
                    m.reply(mess.error)
            }
            break
            case 'ttp': case 'ttp2': case 'ttp3': case 'ttp4': case 'ttp5': case 'ttp6':
                try {
                    if (args1.length == 0) return m.reply(`Example: ${prefix + command} Yori Hosting`)
                    await sky.sendMessage(m.chat, {sticker: {url:`https://api.lolhuman.xyz/api/${command}?apikey=GataDios&text=${text}` }}, { quoted: m })
                } catch (e) {
                    m.reply(mess.error)
            }
            break
	           	        
            case 'toimage': case 'toimg': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!/webp/.test(mime)) throw `Reply sticker dengan caption *${prefix + command}*`
                m.reply(mess.wait)
                let media = await sky.downloadAndSaveMediaMessage(qmsg)
                let ran = await getRandom('.png')
                exec(`ffmpeg -i ${media} ${ran}`, (err) => {
                    fs.unlinkSync(media)
                    if (err) throw err
                    let buffer = fs.readFileSync(ran)
                    sky.sendMessage(m.chat, { image: buffer }, { quoted: m })
                    fs.unlinkSync(ran)
                })
            }
            break
	        case 'tomp4': case 'tovideo': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!/webp/.test(mime)) throw `Reply stiker dengan caption *${prefix + command}*`
                m.reply(mess.wait)
		        let { webp2mp4File } = require('./lib/uploader')
                let media = await sky.downloadAndSaveMediaMessage(qmsg)
                let webpToMp4 = await webp2mp4File(media)
                await sky.sendMessage(m.chat, { video: { url: webpToMp4.result, caption: 'Convert Webp To Video' } }, { quoted: m })
                await fs.unlinkSync(media)
            }
            break
            case 'toaud': case 'toaudio': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!/video/.test(mime) && !/audio/.test(mime)) throw `Kirim/Reply Video/Audio Yang Ingin Dijadikan Audio Dengan Caption ${prefix + command}`
            m.reply(mess.wait)
            let media = await sky.downloadMediaMessage(qmsg)
            let { toAudio } = require('./lib/converter')
            let audio = await toAudio(media, 'mp4')
            sky.sendMessage(m.chat, {audio: audio, mimetype: 'audio/mpeg'}, { quoted : m })
            }
            break
            case 'tomp3': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!/video/.test(mime) && !/audio/.test(mime)) throw `Kirim/Reply Video/Audio Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`
            m.reply(mess.wait)
            let media = await sky.downloadMediaMessage(qmsg)
            let { toAudio } = require('./lib/converter')
            let audio = await toAudio(media, 'mp4')
            sky.sendMessage(m.chat, {document: audio, mimetype: 'audio/mpeg', fileName: `Convert By ${sky.user.name}.mp3`}, { quoted : m })
            }
            break
            case 'tovn': case 'toptt': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!/video/.test(mime) && !/audio/.test(mime)) throw `Reply Video/Audio Yang Ingin Dijadikan VN Dengan Caption ${prefix + command}`
            m.reply(mess.wait)
            let media = await sky.downloadMediaMessage(qmsg)
            let { toPTT } = require('./lib/converter')
            let audio = await toPTT(media, 'mp4')
            sky.sendMessage(m.chat, {audio: audio, mimetype:'audio/mpeg', ptt:true }, {quoted:m})
            }
            break
            case 'togif': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!/webp/.test(mime)) throw `Reply stiker dengan caption *${prefix + command}*`
                m.reply(mess.wait)
		        let { webp2mp4File } = require('./lib/uploader')
                let media = await sky.downloadAndSaveMediaMessage(qmsg)
                let webpToMp4 = await webp2mp4File(media)
                await sky.sendMessage(m.chat, { video: { url: webpToMp4.result, caption: 'Convert Webp To Video' }, gifPlayback: true }, { quoted: m })
                await fs.unlinkSync(media)
            }
            break
case 'top': {
    const limit = 25; // Jumlah maksimal pengguna yang akan ditampilkan

    // Mengambil seluruh data pengguna dan saldo serta limit mereka dari database
    const userData = db.data.users;

    // Mengubah data pengguna menjadi array
    const userArray = Object.entries(userData);

    // Mengurutkan array berdasarkan saldo dalam urutan menurun
    const saldoSorted = [...userArray].sort((a, b) => b[1].balance - a[1].balance);

    // Mengurutkan array berdasarkan limit dalam urutan menurun
    const limitSorted = [...userArray].sort((a, b) => b[1].limit - a[1].limit);

    let saldoResult = '🏆 Top Saldo Pengguna 🏆\n\n';
    let limitResult = '🏆 Top Limit Pengguna 🏆\n\n';

    // Menampilkan pengguna dengan peringkat dari terbanyak hingga terdikit dalam saldo
    saldoSorted.slice(0, limit).forEach((userEntry, index) => {
        const [userId, userData] = userEntry;
        saldoResult += `${index + 1}. @${userId.split('@')[0]} - Saldo: Rp.${userData.balance} 💸\n`;
    });

    // Menampilkan pengguna dengan peringkat dari terbanyak hingga terdikit dalam limit
    limitSorted.slice(0, limit).forEach((userEntry, index) => {
        const [userId, userData] = userEntry;
        limitResult += `${index + 1}. @${userId.split('@')[0]} - Limit: ${userData.limit} 🪙\n`;
    });

    m.reply(`${saldoResult}\n${limitResult}`);
}
break;
             case 'paptt':
if (!q) return m.reply(`Example paptt foto/video`)
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
                db.data.users[m.sender].limit -= 300 // -1 limit
let papttfoto = JSON.parse(fs.readFileSync('./database/paptt-foto.json'))
let papttvideo = JSON.parse(fs.readFileSync('./database/paptt-video.json'))
let titid1 = (pickRandom(papttfoto))
let titid2 = (pickRandom(papttvideo))
if (q == 'foto') {
m.reply("Foto Akan Dikirim Lewat Private Chat ( *PC* )")
                sky.sendMessage(m.sender, { image: { url: titid1 }, caption: 'Mana Tahan😛'}, { quoted: fkontak })
            } else if (q == 'video') {
m.reply("Video Akan Dikirim Lewat Private Chat ( *PC* )")
                sky.sendMessage(m.sender, { video: { url: titid2 }, caption: 'Mana Tahan🙈'}, { quoted: fkontak })
            }
break
            case 'imagenobg': case 'removebg': case 'remove-bg': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
	    if (!/image/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
	    if (/webp/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
	    let remobg = require('remove.bg')
	    let apirnobg = ['q61faXzzR5zNU6cvcrwtUkRU','S258diZhcuFJooAtHTaPEn4T','5LjfCVAp4vVNYiTjq9mXJWHF','aT7ibfUsGSwFyjaPZ9eoJc61','BY63t7Vx2tS68YZFY6AJ4HHF','5Gdq1sSWSeyZzPMHqz7ENfi8','86h6d6u4AXrst4BVMD9dzdGZ','xp8pSDavAgfE5XScqXo9UKHF','dWbCoCb3TacCP93imNEcPxcL']
	    let apinobg = apirnobg[Math.floor(Math.random() * apirnobg.length)]
	    hmm = await './src/remobg-'+getRandom('')
	    localFile = await sky.downloadAndSaveMediaMessage(qmsg, hmm)
	    outputFile = await './src/hremo-'+getRandom('.png')
	    m.reply(mess.wait)
	    remobg.removeBackgroundFromImageFile({
	      path: localFile,
	      apiKey: apinobg,
	      size: "regular",
	      type: "auto",
	      scale: "100%",
	      outputFile 
	    }).then(async result => {
	    sky.sendMessage(m.chat, {image: fs.readFileSync(outputFile), caption: mess.success}, { quoted : m })
	    await fs.unlinkSync(localFile)
	    await fs.unlinkSync(outputFile)
	    })
	    }
	    break
	    
case 'search':
case 'yts': case 'ytsearch': {
                if (!text) return m.reply(`Example : ${prefix + command} story wa anime`)
                let yts = require("yt-search")
                let search = await yts(text)
                let teks = 'YouTube Search\n\n Result From '+text+'\n\n'
                let no = 1
                for (let i of search.all) {
                    teks += `No : ${no++}\nType : ${i.type}\nVideo ID : ${i.videoId}\nTitle : ${i.title}\nViews : ${i.views}\nDuration : ${i.timestamp}\nUploaded : ${i.ago}\nUrl : ${i.url}\n\n─────────────────\n\n`
                }
                sky.sendMessage(m.chat, { image: { url: search.all[0].thumbnail },  caption: teks }, { quoted: m })
            }
            break
        case 'google': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} fatih arridho`
                let google = require('google-it')
                google({'query': text}).then(res => {
                let teks = `Google Search From : ${text}\n\n`
                for (let g of res) {
                teks += `⭔ *Title* : ${g.title}\n`
                teks += `⭔ *Description* : ${g.snippet}\n`
                teks += `⭔ *Link* : ${g.link}\n\n────────────────────────\n\n`
                } 
                m.reply(teks)
                })
                }
                break       
	  case 'playmusic': case 'ttaudio': case 'tiktokmp3':{
if (!text) return m.reply( `Example : ${prefix + command} link`)
if (!q.includes('tiktok')) return m.reply(`Link Invalid!!`)
m.reply(mess.wait)
require('./lib/tiktok').Tiktok(q).then( data => {
sky.sendMessage(m.chat, { audio: { url: data.audio }, mimetype: 'audio/mp4' }, { quoted: m })
})
}
break
     
			case 'saveall': 
if (!isCreator) throw mess.owner
huhuhs = await sky.sendMessage(m.chat, {
    text: `NAME GROUP : ${groupMetadata.subject}\nTOTAL MEMBER :${participants.length}`
}, {quoted: m, ephemeralExpiration: 86400})
await sleep(1000) // (?); mengirim kontak seluruh member
sky.sendContact(m.chat, participants.map(a => a.id), huhuhs)
break
case 'savekontak': case 'svkontak':
if (!isCreator) throw mess.owner
let cmiggc = await sky.groupMetadata(m.chat)
let orgiggc = participants.map(a => a.id)
vcard = ''
noPort = 0
for (let a of cmiggc.participants) {
    vcard += `BEGIN:VCARD\nVERSION:3.0\nFN:[${noPort++}] +${a.id.split("@")[0]}\nTEL;type=CELL;type=VOICE;waid=${a.id.split("@")[0]}:+${a.id.split("@")[0]}\nEND:VCARD\n`
} // (?); mengimpor kontak seluruh member - save
let nmfilect = './contacts.vcf'
m.reply('*Mengimpor '+cmiggc.participants.length+' kontak..*')
fs.writeFileSync(nmfilect, vcard.trim())
await sleep(2000)
sky.sendMessage(m.chat, {
    document: fs.readFileSync(nmfilect), mimetype: 'text/vcard', fileName: 'Contact.vcf', caption: 'GROUP: *'+cmiggc.subject+'*\nMEMBER: *'+cmiggc.participants.length+'*'
}, {ephemeralExpiration: 86400, quoted: m})
fs.unlinkSync(nmfilect)
break	
case 'wanumber': case 'searchno': case 'searchnumber':{
  if (!isPrem) return replyprem(mess.premium)
           	if (!text) return m.reply(`Provide Number with last number x\n\nExample: ${prefix + command} 91690913721x`)
var inputnumber = text.split(" ")[0]
        
        m.reply(`Searching for WhatsApp account in given range...`)
        function countInstances(string, word) {
            return string.split(word).length - 1
        }
        var number0 = inputnumber.split('x')[0]
        var number1 = inputnumber.split('x')[countInstances(inputnumber, 'x')] ? inputnumber.split('x')[countInstances(inputnumber, 'x')] : ''
        var random_length = countInstances(inputnumber, 'x')
        var randomxx
        if (random_length == 1) {
            randomxx = 10
        } else if (random_length == 2) {
            randomxx = 100
        } else if (random_length == 3) {
            randomxx = 1000
        }
        var text66 = `*==[ List of Whatsapp Numbers ]==*\n\n`
        var nobio = `\n*Bio:* || \nHey there! I am using WhatsApp.\n`
        var nowhatsapp = `\n*Numbers with no WhatsApp account within provided range.*\n`
        for (let i = 0; i < randomxx; i++) {
            var nu = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
            var status1 = nu[Math.floor(Math.random() * nu.length)]
            var status2 = nu[Math.floor(Math.random() * nu.length)]
            var status3 = nu[Math.floor(Math.random() * nu.length)]
            var dom4 = nu[Math.floor(Math.random() * nu.length)]
            var random21
            if (random_length == 1) {
                random21 = `${status1}`
            } else if (random_length == 2) {
                random21 = `${status1}${status2}`
            } else if (random_length == 3) {
                random21 = `${status1}${status2}${status3}`
            } else if (random_length == 4) {
                random21 = `${status1}${status2}${status3}${dom4}`
            }
            var anu = await sky.onWhatsApp(`${number0}${i}${number1}@s.whatsapp.net`)
            var anuu = anu.length !== 0 ? anu : false
            try {
                try {
                    var anu1 = await sky.fetchStatus(anu[0].jid)
                } catch {
                    var anu1 = '401'
                }
                if (anu1 == '401' || anu1.status.length == 0) {
                    nobio += `wa.me/${anu[0].jid.split("@")[0]}\n`
                } else {
                    text66 += `🪀 *Number:* wa.me/${anu[0].jid.split("@")[0]}\n 🎗️*Bio :* ${anu1.status}\n🧐*Last update :* ${moment(anu1.setAt).tz('Asia/Kolkata').format('HH:mm:ss DD/MM/YYYY')}\n\n`
                }
            } catch {
                nowhatsapp += `${number0}${i}${number1}\n`
            }
        }
        m.reply(`${text66}${nobio}${nowhatsapp}`)
        }
break
case 'factornumber': {
    if (!text) {
        return m.reply(`Provide a number to get its prime factors.\n\nExample: ${prefix + command} 60`);
    }

    const number = parseInt(text);
    if (isNaN(number)) {
        return m.reply('Invalid number. Please provide a valid number.');
    }

    function getPrimeFactors(n) {
        const factors = [];
        let divisor = 2;

        while (n >= 2) {
            if (n % divisor === 0) {
                factors.push(divisor);
                n = n / divisor;
            } else {
                divisor++;
            }
        }

        return factors.join(', ');
    }

    const primeFactors = getPrimeFactors(number);
    if (primeFactors.length === 0) {
        m.reply(`${number} is a prime number with no prime factors.`);
    } else {
        m.reply(`Prime factors of ${number}: ${primeFactors}`);
    }
}
break;
case 'aboutnumber': {
    const axios = require('axios');

    if (!text) {
        return m.reply(`Provide a number to get a fun fact about it.\n\nExample: ${prefix + command} 42`);
    }

    const number = parseInt(text);
    if (isNaN(number)) {
        return m.reply('Invalid number. Please provide a valid number.');
    }

    axios.get(`http://numbersapi.com/${number}`)
        .then(response => {
            const fact = response.data;
            m.reply(`Fun fact about ${number}: ${fact}`);
        })
        .catch(error => {
            m.reply('Failed to fetch number fact. Please try again later.');
        });
}
break;
	    case 'getmusic': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let { yta } = require('./lib/y2mate')
                if (!text) throw `Example : ${prefix + command} 1`
                if (!m.quoted) return m.reply('Reply Pesan')
                if (!m.quoted.isBaileys) throw `Hanya Bisa Membalas Pesan Dari Bot`
		let urls = quoted.text.match(new RegExp(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch|v|embed|shorts)(?:\.php)?(?:\?.*v=|\/))([a-zA-Z0-9\_-]+)/, 'gi'))
                if (!urls) throw `Mungkin pesan yang anda reply tidak mengandung result ytsearch`
                let quality = args[1] ? args[1] : '128kbps'
                let media = await yta(urls[text - 1], quality)
                if (media.filesize >= 100000) return m.reply('File Melebihi Batas '+util.format(media))
                sky.sendImage(m.chat, media.thumb, `⭔ Title : ${media.title}\n⭔ File Size : ${media.filesizeF}\n⭔ Url : ${urls[text - 1]}\n⭔ Ext : MP3\n⭔ Resolusi : ${args[1] || '128kbps'}`, m)
                sky.sendMessage(m.chat, { audio: { url: media.dl_link }, mimetype: 'audio/mpeg', fileName: `${media.title}.mp3` }, { quoted: m })
            }
            break
            case 'getvideo': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let { ytv } = require('./lib/y2mate')
                if (!text) throw `Example : ${prefix + command} 1`
                if (!m.quoted) return m.reply('Reply Pesan')
                if (!m.quoted.isBaileys) throw `Hanya Bisa Membalas Pesan Dari Bot`
                let urls = quoted.text.match(new RegExp(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch|v|embed|shorts)(?:\.php)?(?:\?.*v=|\/))([a-zA-Z0-9\_-]+)/, 'gi'))
                if (!urls) throw `Mungkin pesan yang anda reply tidak mengandung result ytsearch`
                let quality = args[1] ? args[1] : '360p'
                let media = await ytv(urls[text - 1], quality)
                if (media.filesize >= 100000) return m.reply('File Melebihi Batas '+util.format(media))
                sky.sendMessage(m.chat, { video: { url: media.dl_link }, mimetype: 'video/mp4', fileName: `${media.title}.mp4`, caption: `⭔ Title : ${media.title}\n⭔ File Size : ${media.filesizeF}\n⭔ Url : ${urls[text - 1]}\n⭔ Ext : MP3\n⭔ Resolusi : ${args[1] || '360p'}` }, { quoted: m })
            }
            break
case 'pinterest': {
 if (!isPrem) return replyprem(mess.premium)
    const [query, count] = text.split(' | ');

    if (!query || !count || isNaN(count)) {
        return m.reply(`Contoh: ${prefix + command} ghost | 7`);
    }

    m.reply(mess.wait);

    let { pinterest } = require('./lib/scraper');
    anu = await pinterest(query);

    const numImagesToSend = parseInt(count);
    const selectedImages = [];

    for (let i = 0; i < numImagesToSend && i < anu.length; i++) {
        selectedImages.push(anu[i]);
    }

    for (const result of selectedImages) {
        sky.sendMessage(m.chat, { image: { url: result }, caption: mess.done }, { quoted: m });
    }
}
break;

	    case 'couple': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                m.reply(mess.wait)
                let anu = await fetchJson('https://raw.githubusercontent.com/iamriz7/kopel_/main/kopel.json')
                let random = anu[Math.floor(Math.random() * anu.length)]
                sky.sendMessage(m.chat, { image: { url: random.male }, caption: `Couple Male` }, { quoted: m })
                sky.sendMessage(m.chat, { image: { url: random.female }, caption: `Couple Female` }, { quoted: m })
            }
	    break	    
 case 'joker': case 'harley': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
  m.reply(mess.wait)
let { data } = await axios.get(`https://api.akuari.my.id/randomimage/${command}`)
	if (data.message) return m.reply(JSON.stringify(data))
	await sky.sendMessage(m.chat, { image: { url: data.respon }, caption: mess.done }, { quoted: m })
}
break

            case 'coffe': case 'kopi': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            let Message = {
                    image: { url: 'https://coffee.alexflipnote.dev/random' },
                    caption: `☕ Random Coffe`
                }
                sky.sendMessage(m.chat, Message, { quoted: m })
            }
            break
            case 'wallpaper': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw 'Masukkan Query Title'
		        let { wallpaper } = require('./lib/scraper')
                anu = await wallpaper(text)
                result = anu[Math.floor(Math.random() * anu.length)]
		        let Message = {
                    image: { url: result.image[0] },
                    caption: `⭔ Title : ${result.title}\n⭔ Category : ${result.type}\n⭔ Detail : ${result.source}\n⭔ Media Url : ${result.image[2] || result.image[1] || result.image[0]}`
                }
                sky.sendMessage(m.chat, Message, { quoted: m })
            }
            break
case 'membangunrumah': {
    const maxRounds = 5; // Jumlah ronde maksimal
    let userHouse = {
        foundation: 0,
        walls: 0,
        roof: 0,
    };
    let computerHouse = {
        foundation: 0,
        walls: 0,
        roof: 0,
    };

    function computerTurn() {
        const randomChoice = Math.floor(Math.random() * 3) + 1;
        switch (randomChoice) {
            case 1:
                computerHouse.foundation++;
                return 'Dasar rumah dibangun.';
            case 2:
                if (computerHouse.foundation > 0) {
                    computerHouse.walls++;
                    return 'Dinding rumah dipasang.';
                } else {
                    return 'Komputer belum dapat membangun dinding, karena belum ada dasar rumah.';
                }
            case 3:
                if (computerHouse.walls > 0) {
                    computerHouse.roof++;
                    return 'Atap rumah diatur.';
                } else {
                    return 'Komputer belum dapat mengatur atap, karena belum ada dinding rumah.';
                }
            default:
                return 'Komputer tidak dapat melakukan aksi.';
        }
    }

    await m.reply('Selamat datang di permainan Membangun Rumah! Mari mulai membangun rumah.');

    for (let round = 1; round <= maxRounds; round++) {
        const userChoice = Math.floor(Math.random() * 3) + 1;

        switch (userChoice) {
            case 1:
                userHouse.foundation++;
                await m.reply('Anda berhasil membangun dasar rumah!');
                break;
            case 2:
                if (userHouse.foundation > 0) {
                    userHouse.walls++;
                    await m.reply('Anda berhasil memasang dinding rumah!');
                } else {
                    await m.reply('Anda harus membangun dasar rumah terlebih dahulu.');
                }
                break;
            case 3:
                if (userHouse.walls > 0) {
                    userHouse.roof++;
                    await m.reply('Anda berhasil mengatur atap rumah!');
                } else {
                    await m.reply('Anda harus memasang dinding rumah terlebih dahulu.');
                }
                break;
        }

        const computerResponse = computerTurn();
        await m.reply(`Giliran komputer: ${computerResponse}`);
    }

    const userTotalProgress = userHouse.foundation + userHouse.walls + userHouse.roof;
    const computerTotalProgress = computerHouse.foundation + computerHouse.walls + computerHouse.roof;

    let result = `🏠 Permainan Membangun Rumah berakhir!\n\n`;
    result += `Hasil pembangunan Anda:\nDasar Rumah: ${userHouse.foundation}\nDinding Rumah: ${userHouse.walls}\nAtap Rumah: ${userHouse.roof}\n`;
    result += `Total Progress Anda: ${userTotalProgress} / 3\n\n`;
    result += `Hasil pembangunan Komputer:\nDasar Rumah: ${computerHouse.foundation}\nDinding Rumah: ${computerHouse.walls}\nAtap Rumah: ${computerHouse.roof}\n`;
    result += `Total Progress Komputer: ${computerTotalProgress} / 3\n\n`;

    if (userTotalProgress > computerTotalProgress) {
        result += `Selamat! Anda berhasil membangun rumah lebih baik daripada komputer!`;
    } else if (userTotalProgress < computerTotalProgress) {
        result += `Sayang sekali, komputer berhasil membangun rumah lebih baik daripada Anda.`;
    } else {
        result += `Pertandingan berakhir imbang! Keduanya membangun rumah dengan kemajuan yang sama.`;
    }

    await m.reply(result);
}
break;
case 'petualanganepik': {
    if (!m.mentionedJid || m.mentionedJid.length !== 5) {
        return await m.reply('Tag lima pengguna untuk memulai permainan petualangan epik.')
    }

    const participants = m.mentionedJid;
    const maxRounds = 10; // Jumlah ronde maksimal

    let result = `🛡️ Petualangan epik dimulai! 🛡️\n\n`;

    function generateRandomAction() {
        const actions = [
            'Serangan pedang',
            'Serangan panah',
            'Serangan sihir',
            'Serangan mukul',
            'Serangan tusukan',
        ];
        return actions[Math.floor(Math.random() * actions.length)];
    }

    function calculateDamage(action) {
        return Math.floor(Math.random() * 30) + 10;
    }

    function calculateTotalDamage(participant) {
        let totalDamage = 0;
        for (let i = 0; i < maxRounds; i++) {
            totalDamage += calculateDamage(generateRandomAction());
        }
        return totalDamage;
    }

    function getCharacterEmoji(participant) {
        const emojis = ['🛡️', '⚔️', '🏹', '🔮', '🔨'];
        return emojis[participants.indexOf(participant)];
    }

    for (let round = 1; round <= maxRounds; round++) {
        result += `⚔️ Tahap ${round}\n\n`;

        for (const participant of participants) {
            let action = generateRandomAction();
            let damage = calculateDamage(action);

            result += `${getCharacterEmoji(participant)} @${participant.split('@')[0]} melakukan aksi: ${action} - Menyebabkan ${damage} kerusakan!\n`;
        }

        result += '\n';
    }

    result += `\n🏁 Petualangan epik berakhir!\n\n`;

    let winner = participants[0];
    let highestDamage = calculateTotalDamage(participants[0]);

    for (const participant of participants) {
        let totalDamage = calculateTotalDamage(participant);

        if (totalDamage > highestDamage) {
            winner = participant;
            highestDamage = totalDamage;
        }
    }

    result += `🎉 Pemenang petualangan epik adalah ${getCharacterEmoji(winner)} @${winner.split('@')[0]}!`;
    await m.reply(result);
}
break;
case 'aidb': {
 if (!text) throw 'aidb 1-10|Pertanyaan nya'    
text1 = text.split('|')[0] ? text.split('|')[0] : '-'
text2 = text.split('|')[1] ? text.split('|')[1] : '-'
    m.reply(mess.wait);    
    try {
        var { data } = await axios.get(`https://aemt.me/openai-db?user=${text1}&text=${text2}`);        
        if (data && data.result) {
            m.reply(`${data.result}`.trim());
        } else {
            m.reply('Tidak dapat mengambil jawaban dari OpenAI.');
        }
    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan saat menghubungi API.');
    }
}
break
case 'tess':{
if (!isCreator) return m.reply(mess.owner)
m.reply('U Dah Owner')
}
break
case 'addowner':
if (!isCreator) return m.reply(mess.owner)
if (!args[0]) return m.reply(`Use ${prefix+command} number\nExample ${prefix+command} 628****`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await sky.onWhatsApp(bnnd)
if (ceknye.length == 0) return m.reply(`Enter A Valid And Registered Number On WhatsApp!!!`)
owner.push(bnnd)
fs.writeFileSync('./database/owner.json', JSON.stringify(owner))
m.reply(`Number ${bnnd} Has Become An Owner!!!`)
break
case 'delowner':
 if (!isCreator) return m.reply(mess.owner)
if (!args[0]) return m.reply(`Use ${prefix+command} nomor\nExample ${prefix+command} 62882022339839`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = owner.indexOf(ya)
owner.splice(unp, 1)
fs.writeFileSync('./database/owner.json', JSON.stringify(owner))
m.reply(`The Numbrr ${ya} Has been deleted from owner list by the owner!!!`)
break
case 'akinator': {
                    if (akinator.hasOwnProperty(m.sender.split('@')[0])) throw ("Selesein yg sebelumnya dulu atuh")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/akinator/start?apikey=GataDios`)
                    let { server, frontaddr, session, signature, question, step } = get_result.result
                    const data = {}
                    data["server"] = server
                    data["frontaddr"] = frontaddr
                    data["session"] = session
                    data["signature"] = signature
                    data["question"] = question
                    data["step"] = step
                    imi_txt = `🤔🤔\n${question}\n\n`
                    imi_txt += "0 - Ya\n"
                    imi_txt += "1 - Tidak\n"
                    imi_txt += "2 - Saya Tidak Tau\n"
                    imi_txt += "3 - Mungkin\n"
                    imi_txt += "4 - Mungkin Tidak"
                    sky.sendText(m.chat, imi_txt, m).then(() => {
                        akinator[m.sender.split('@')[0]] = data
                        fs.writeFileSync("./src/akinator.json", JSON.stringify(akinator))
                    })                
                    }   
                    break
                case 'cancelakinator': {
                    if (!akinator.hasOwnProperty(m.sender.split('@')[0])) throw ("Anda tidak memiliki akinator sebelumnya")
                    delete akinator[m.sender.split('@')[0]]
                    fs.writeFileSync("./src/akinator.json", JSON.stringify(akinator))
                    m.reply("Success mengcancel akinator sebelumnya")
                    }
                    break		
		// Akinator menu end
    case 'akira':
            case 'akiyama':
            case 'ana':
            case 'asuna':
            case 'ayuzawa':
            case 'boruto':
            case 'chitoge':
            case 'deidara':
            case 'doraemon':
            case 'elaina':
            case 'emilia':
            case 'erza':
            case 'gremory':
            case 'hestia':
            case 'hinata':
            case 'inori':
            case 'isuzu':
            case 'itachi':
            case 'itori':
            case 'kagas':
            case 'kagura':
            case 'kakasih':
            case 'kaori':
            case 'keneki':
            case 'kotori':
            case 'kurumi':
            case 'kisahnabi':
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} Muhammad`)
			m.reply(mess.wait)
			axios
				.get(`https://api.lolhuman.xyz/api/kisahnabi/${text}?apikey=GataDios`)
				.then(({ data }) => {
					var text = `Name : ${data.result.name}\n`
					text += `Lahir : ${data.result.thn_kelahiran}\n`
					text += `Umur : ${data.result.age}\n`
					text += `Tempat : ${data.result.place}\n`
					text += `Story : \n${data.result.story}`
					m.reply(text)
				})
				.catch(console.error)
			break
			
            case 'wikimedia': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw 'Masukkan Query Title'
		let { wikimedia } = require('./lib/scraper')
                anu = await wikimedia(text)
                result = anu[Math.floor(Math.random() * anu.length)]
                let Message = {
                    image: { url: result.image },
                    caption: `⭔ Title : ${result.title}\n⭔ Source : ${result.source}\n⭔ Media Url : ${result.image}`
                }
                sky.sendMessage(m.chat, Message, { quoted: m })
            }
            break
            
case 'quotesanime': case 'quoteanime': {
  if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
  let { quotesAnime } = require('./lib/scraper');
  
  try {
    let anu = await quotesAnime();
    let result = anu[Math.floor(Math.random() * anu.length)];
    
    let Message = {
      text: `~_${result.quotes}_\n\nBy : ${result.karakter}\nJudul : ${result.anime}\nEps : ${result.episode}\n\n- ${result.up_at}`
    };
    
    sky.sendMessage(m.chat, Message, { quoted: fkontak });
  } catch (error) {
    console.error(error);
    m.reply('Terjadi kesalahan saat mengambil kutipan anime.');
  }
  break;
}

            case '3dchristmas': case '3ddeepsea': case 'americanflag': case '3dscifi': case '3drainbow': case '3dwaterpipe': case 'halloweenskeleton': case 'sketch': case 'bluecircuit': case 'space': case 'metallic': case 'fiction': case 'greenhorror': case 'transformer': case 'berry': case 'thunder': case 'magma': case '3dcrackedstone': case '3dneonlight': case 'impressiveglitch': case 'naturalleaves': case 'fireworksparkle': case 'matrix': case 'dropwater':  case 'harrypotter': case 'foggywindow': case 'neondevils': case 'christmasholiday': case '3dgradient': case 'blackpink': case 'gluetext': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} text`
                m.reply(mess.wait)
                sky.sendMessage(m.chat, { image: { url: api('zenz', '/textpro/' + command, { text: text }, 'apikey') }, caption: `Text Pro ${command}` }, { quoted: m})
	    }
            break	        
	    case 'nomerhoki': case 'nomorhoki': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!Number(text)) throw `Example : ${prefix + command} 6288292024190`
                let anu = await primbon.nomer_hoki(Number(text))
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nomor HP :* ${anu.message.nomer_hp}\n⭔ *Angka Shuzi :* ${anu.message.angka_shuzi}\n⭔ *Energi Positif :*\n- Kekayaan : ${anu.message.energi_positif.kekayaan}\n- Kesehatan : ${anu.message.energi_positif.kesehatan}\n- Cinta : ${anu.message.energi_positif.cinta}\n- Kestabilan : ${anu.message.energi_positif.kestabilan}\n- Persentase : ${anu.message.energi_positif.persentase}\n⭔ *Energi Negatif :*\n- Perselisihan : ${anu.message.energi_negatif.perselisihan}\n- Kehilangan : ${anu.message.energi_negatif.kehilangan}\n- Malapetaka : ${anu.message.energi_negatif.malapetaka}\n- Kehancuran : ${anu.message.energi_negatif.kehancuran}\n- Persentase : ${anu.message.energi_negatif.persentase}`, m)
            }
            break
            case 'artimimpi': case 'tafsirmimpi': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} belanja`
                let anu = await primbon.tafsir_mimpi(text)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Mimpi :* ${anu.message.mimpi}\n⭔ *Arti :* ${anu.message.arti}\n⭔ *Solusi :* ${anu.message.solusi}`, m)
            }
            break
            case 'ramalanjodoh': case 'ramaljodoh': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.ramalan_jodoh(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama Anda :* ${anu.message.nama_anda.nama}\n⭔ *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n⭔ *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n⭔ *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            //NEW
 case 'factornumber': {
    if (!text) {
        return m.reply(`Provide a number to get its prime factors.\n\nExample: ${prefix + command} 60`);
    }

    const number = parseInt(text);
    if (isNaN(number)) {
        return m.reply('Invalid number. Please provide a valid number.');
    }

    function getPrimeFactors(n) {
        const factors = [];
        let divisor = 2;

        while (n >= 2) {
            if (n % divisor === 0) {
                factors.push(divisor);
                n = n / divisor;
            } else {
                divisor++;
            }
        }

        return factors.join(', ');
    }

    const primeFactors = getPrimeFactors(number);
    if (primeFactors.length === 0) {
        m.reply(`${number} is a prime number with no prime factors.`);
    } else {
        m.reply(`Prime factors of ${number}: ${primeFactors}`);
    }
}
break;
case 'aboutnumber': {
    const axios = require('axios');

    if (!text) {
        return m.reply(`Provide a number to get a fun fact about it.\n\nExample: ${prefix + command} 42`);
    }

    const number = parseInt(text);
    if (isNaN(number)) {
        return m.reply('Invalid number. Please provide a valid number.');
    }

    axios.get(`http://numbersapi.com/${number}`)
        .then(response => {
            const fact = response.data;
            m.reply(`Fun fact about ${number}: ${fact}`);
        })
        .catch(error => {
            m.reply('Failed to fetch number fact. Please try again later.');
        });
}
break;       
// ...
// ...

case 'adupahlawan': {
 const namaPahlawan = ['goku', 'naruto', 'sasuke', 'allmight', 'saitama', 'zen', 'iky', 'itachi', 'luffy', 'eren'];
    const pilihan = args[0]?.toLowerCase();

    if (!pilihan) {
        return await m.reply(`Pilihan pahlawan yang tersedia: ${namaPahlawan.join(', ')}`);
    }
    if (!namaPahlawan.includes(pilihan)) {
        return await m.reply('Pilihan pahlawan tidak valid. Pilihan yang tersedia: ' + namaPahlawan.join(', '));
    }

    const lawanPilihan = namaPahlawan[Math.floor(Math.random() * namaPahlawan.length)];

    let userScore = 0;
    let lawanScore = 0;
    let maxRounds = 15; // Jumlah ronde maksimal
    let round = 1;
    let result = `⚔️ Mulai permainan adu pahlawan dengan ${pilihan} melawan ${lawanPilihan} ⚔️\n\n`;

    while (round <= maxRounds) {
        let userAction = Math.random() < 0.5 ? 'serang' : 'bertahan';
        let lawanAction = Math.random() < 0.5 ? 'serang' : 'bertahan';

        if (userAction === 'serang' && lawanAction === 'bertahan') {
            userScore++;
            result += `🤜 ${pilihan} menyerang dan berhasil mengalahkan taktik bertahan ${lawanPilihan}! (+1 poin)\n`;
        } else if (userAction === 'bertahan' && lawanAction === 'serang') {
            lawanScore++;
            result += `🤜 ${lawanPilihan} menyerang dan mengalahkan taktik bertahan ${pilihan}! (+1 poin)\n`;
        } else {
            result += `🤝 Kedua pahlawan sama-sama menerapkan taktik yang sama, ${pilihan} dan ${lawanPilihan}.\n`;
        }

        // Variasi aksi tambahan
        if (userScore - lawanScore >= 2) {
            result += `💥 ${pilihan} terluka dan masuk rumah sakit!\n`;
        } else if (lawanScore - userScore >= 2) {
            result += `💥 ${lawanPilihan} terluka dan masuk rumah sakit!\n`;
        }

        if (userScore >= 5) {
            result += `😢 ${pilihan} menangis dan merasa tertekan.\n`;
        } else if (lawanScore >= 5) {
            result += `😢 ${lawanPilihan} menangis dan merasa tertekan.\n`;
        }

        if (userScore <= 1) {
            result += `🗣️ ${lawanPilihan} ngadu bapak awoakwoak!\n`;
        } else if (lawanScore <= 1) {
            result += `🗣️ ${pilihan} ngadu bapak awkoakwo!\n`;
        }

        round++;
    }
    result += `\n⏱️ Pertandingan selesai! Total skor: ${pilihan} ${userScore} - ${lawanPilihan} ${lawanScore}`;

    if (userScore > lawanScore) {
        result += `\n🎉 ${pilihan} memenangkan permainan adu pahlawan melawan ${lawanPilihan}!`;
    } else if (lawanScore > userScore) {
        result += `\n😢 ${pilihan} kalah dalam permainan adu pahlawan melawan ${lawanPilihan}!`;
    } else {
        result += `\n⚖️ Pertandingan adu pahlawan melawan ${lawanPilihan} berakhir imbang!`;
    }

    await m.reply(`${result}`);
}
break;
case 'adusemut': {
    const pilihanSemut = ['hitam', 'merah'];
    const pilihan = args[0]?.toLowerCase();

    if (!pilihan) {
        return await m.reply(`Pilihan semut yang tersedia: ${pilihanSemut.join(', ')}`);
    }

    if (!pilihanSemut.includes(pilihan)) {
        return await m.reply('Pilihan semut tidak valid. Pilihan yang tersedia: ' + pilihanSemut.join(', '));
    }

    let userScore = 0;
    let botScore = 0;
    let maxRounds = 10; // Jumlah ronde maksimal
    let round = 1;
    let result = `🐜 Mulai permainan adu semut dengan pilihan ${pilihan} 🐜\n\n`;

    while (round <= maxRounds) {
        let userAction = Math.random() < 0.5 ? 'menyerang' : 'menangkis';
        let botAction = Math.random() < 0.5 ? 'menyerang' : 'menangkis';

        if (userAction === 'menyerang' && botAction === 'menangkis') {
            userScore++;
            result += `🤜 Anda ${pilihan} menyerang dan berhasil mengalahkan semut lawan! (+1 poin)\n`;
        } else if (userAction === 'menangkis' && botAction === 'menyerang') {
            botScore++;
            result += '🤜 Lawan berhasil menangkis dan berhasil mengalahkan semut Anda! (+1 poin)\n';
        } else {
            result += '🤝 Kedua semut sama-sama menangkis serangan.\n';
        }

        round++;
    }

    result += `\n⏱️ Pertandingan selesai! Total skor: Anda ${userScore} - Lawan ${botScore}`;

    if (userScore > botScore) {
        result += `\n🎉 Anda memenangkan permainan adu semut dengan pilihan ${pilihan}!`;
    } else if (botScore > userScore) {
        result += `\n😢 Anda kalah dalam permainan adu semut dengan pilihan ${pilihan}!`;
    } else {
        result += `\n⚖️ Pertandingan adu semut dengan pilihan ${pilihan} berakhir imbang!`;
    }

    await m.reply(`${result}`);
}
break;

// ...

            case 'ramalanjodohbali': case 'ramaljodohbali': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.ramalan_jodoh_bali(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama Anda :* ${anu.message.nama_anda.nama}\n⭔ *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n⭔ *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n⭔ *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'suamiistri': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.suami_istri(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama Suami :* ${anu.message.suami.nama}\n⭔ *Lahir Suami :* ${anu.message.suami.tgl_lahir}\n⭔ *Nama Istri :* ${anu.message.istri.nama}\n⭔ *Lahir Istri :* ${anu.message.istri.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
              case 'restart':
                if (!isCreator) return m.reply(mess.owner)
                m.reply('Proses....')
                exec('reset')
                break
            case 'ramalancinta': case 'ramalcinta': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.ramalan_cinta(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama Anda :* ${anu.message.nama_anda.nama}\n⭔ *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n⭔ *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n⭔ *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n⭔ *Sisi Positif :* ${anu.message.sisi_positif}\n⭔ *Sisi Negatif :* ${anu.message.sisi_negatif}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'artinama': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika Ardianta`
                let anu = await primbon.arti_nama(text)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Arti :* ${anu.message.arti}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'kecocokannama': case 'cocoknama': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 7, 7, 2005`
                let [nama, tgl, bln, thn] = text.split`,`
                let anu = await primbon.kecocokan_nama(nama, tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Life Path :* ${anu.message.life_path}\n⭔ *Destiny :* ${anu.message.destiny}\n⭔ *Destiny Desire :* ${anu.message.destiny_desire}\n⭔ *Personality :* ${anu.message.personality}\n⭔ *Persentase :* ${anu.message.persentase_kecocokan}`, m)
            }
            break
            case 'kecocokanpasangan': case 'cocokpasangan': case 'pasangan': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika|Novia`
                let [nama1, nama2] = text.split`|`
                let anu = await primbon.kecocokan_nama_pasangan(nama1, nama2)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendImage(m.chat,  anu.message.gambar, `⭔ *Nama Anda :* ${anu.message.nama_anda}\n⭔ *Nama Pasangan :* ${anu.message.nama_pasangan}\n⭔ *Sisi Positif :* ${anu.message.sisi_positif}\n⭔ *Sisi Negatif :* ${anu.message.sisi_negatif}`, m)
            }
            break
            case 'jadianpernikahan': case 'jadiannikah': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 6, 12, 2020`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.tanggal_jadian_pernikahan(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Tanggal Pernikahan :* ${anu.message.tanggal}\n⭔ *karakteristik :* ${anu.message.karakteristik}`, m)
            }
            break
            case 'sifatusaha': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!ext)throw `Example : ${prefix+ command} 28, 12, 2021`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.sifat_usaha_bisnis(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Usaha :* ${anu.message.usaha}`, m)
            }
            break
            case 'rejeki': case 'rezeki': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.rejeki_hoki_weton(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Rezeki :* ${anu.message.rejeki}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'pekerjaan': case 'kerja': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.pekerjaan_weton_lahir(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Pekerjaan :* ${anu.message.pekerjaan}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            
                case 'ramalannasib': case 'ramalnasib': case 'nasib': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
               if (!text) throw `Example : ${prefix + command} 7, 7, 2004`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.ramalan_nasib(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `• *Analisa :* ${anu.message.analisa}`, m)
            }
            case 'potensipenyakit': case 'penyakit': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.cek_potensi_penyakit(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Analisa :* ${anu.message.analisa}\n⭔ *Sektor :* ${anu.message.sektor}\n⭔ *Elemen :* ${anu.message.elemen}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'fengshui': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 1, 2005\n\nNote : ${prefix + command} Nama, gender, tahun lahir\nGender : 1 untuk laki-laki & 2 untuk perempuan`
                let [nama, gender, tahun] = text.split`,`
                let anu = await primbon.perhitungan_feng_shui(nama, gender, tahun)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tahun_lahir}\n⭔ *Gender :* ${anu.message.jenis_kelamin}\n⭔ *Angka Kua :* ${anu.message.angka_kua}\n⭔ *Kelompok :* ${anu.message.kelompok}\n⭔ *Karakter :* ${anu.message.karakter}\n⭔ *Sektor Baik :* ${anu.message.sektor_baik}\n⭔ *Sektor Buruk :* ${anu.message.sektor_buruk}`, m)
            }
            break
            case 'haribaik': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.petung_hari_baik(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Kala Tinantang :* ${anu.message.kala_tinantang}\n⭔ *Info :* ${anu.message.info}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'harisangar': case 'taliwangke': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.hari_sangar_taliwangke(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Info :* ${anu.message.info}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'harinaas': case 'harisial': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.primbon_hari_naas(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *Tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hari Naas :* ${anu.message.hari_naas}\n⭔ *Info :* ${anu.message.catatan}\n⭔ *Catatan :* ${anu.message.info}`, m)
            }
            break
            case 'nagahari': case 'harinaga': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.rahasia_naga_hari(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *Tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Arah Naga Hari :* ${anu.message.arah_naga_hari}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'arahrejeki': case 'arahrezeki': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.primbon_arah_rejeki(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Arah Rezeki :* ${anu.message.arah_rejeki}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'peruntungan': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} DIka, 7, 7, 2005, 2022\n\nNote : ${prefix + command} Nama, tanggal lahir, bulan lahir, tahun lahir, untuk tahun`
                let [nama, tgl, bln, thn, untuk] = text.split`,`
                let anu = await primbon.ramalan_peruntungan(nama, tgl, bln, thn, untuk)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Peruntungan Tahun :* ${anu.message.peruntungan_tahun}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'weton': case 'wetonjawa': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.weton_jawa(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Tanggal :* ${anu.message.tanggal}\n⭔ *Jumlah Neptu :* ${anu.message.jumlah_neptu}\n⭔ *Watak Hari :* ${anu.message.watak_hari}\n⭔ *Naga Hari :* ${anu.message.naga_hari}\n⭔ *Jam Baik :* ${anu.message.jam_baik}\n⭔ *Watak Kelahiran :* ${anu.message.watak_kelahiran}`, m)
            }
            break
            case 'sifat': case 'karakter': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 7, 7, 2005`
                let [nama, tgl, bln, thn] = text.split`,`
                let anu = await primbon.sifat_karakter_tanggal_lahir(nama, tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Garis Hidup :* ${anu.message.garis_hidup}`, m)
            }
            break
            case 'keberuntungan': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 7, 7, 2005`
                let [nama, tgl, bln, thn] = text.split`,`
                let anu = await primbon.potensi_keberuntungan(nama, tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}`, m)
            }
            break
            case 'mancing': {
    const peluangMancing = Math.random();

    if (peluangMancing < 0.3) {
        const ikanDitangkap = ['ikan kecil', 'ikan sedang', 'ikan besar'];
        const hasilMancing = ikanDitangkap[Math.floor(Math.random() * ikanDitangkap.length)];
        let hasil = `🎣 Kamu berhasil menangkap ${hasilMancing}!\n`;

        const peluangJual = Math.random();
        let penjualan = 0;

        if (peluangJual < 0.3) {
            penjualan = Math.floor(Math.random() * 20) + 10; // Jumlah uang dari penjualan
            hasil += `💰 Kamu menjual ${hasilMancing} dan mendapatkan ${penjualan} koin!`;
        } else {
            hasil += `😔 Sayangnya, kamu tidak bisa menjual ikan ini. Mungkin lain kali.`;
        }

        await m.reply(hasil);
    } else {
        await m.reply('🎣 Kamu mencoba untuk mancing, tetapi tidak berhasil kali ini. Coba lagi nanti!');
    }
}
break;
            case 'bughunter':
    if (!text) throw 'Gunakan: *bughunter [URL situs web]*';
    const websiteUrl = args[0];
    try {
        const bugHuntingReport = await performAdvancedBugHunting(websiteUrl);
        m.reply(bugHuntingReport);
    } catch (error) {
        m.reply(error);
    }
break;
            case 'memancing': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 12, 1, 2022`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.primbon_memancing_ikan(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Tanggal :* ${anu.message.tgl_memancing}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'masasubur': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 12, 1, 2022, 28\n\nNote : ${prefix + command} hari pertama menstruasi, siklus`
                let [tgl, bln, thn, siklus] = text.split`,`
                let anu = await primbon.masa_subur(tgl, bln, thn, siklus)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
case 'hitungkata': {
  if (!args[0]) throw 'Gunakan: *hitungkata [teks]*';

  const kata = args.join(' ');
  const jumlahKata = kata.split(/\s+/).filter(word => word.length > 0).length;

  await sky.sendText(from, `Jumlah kata dalam teks tersebut adalah: ${jumlahKata}`);
  break;
}
case 'hitunghuruf': {
  if (!args[0]) throw 'Gunakan: *hitunghuruf [teks]*';

  const teks = args.join(' ');
  const jumlahHuruf = teks.replace(/\s+/g, '').length;

  await sky.sendText(from, `Teks : ${teks}\nmengandung ${jumlahHuruf} huruf.`);
  break;
}

case 'kbbi':{
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} kursi`)
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/kbbi?apikey=GataDios&query=${args}`)
			var titid = `\`\`\`Kata : ${data.result[0].nama}\`\`\`\n`
			titid += `\`\`\`Kata Dasar : ${data.result[0].kata_dasar}\`\`\`\n`
			titid += `\`\`\`Pelafalan : ${data.result[0].pelafalan}\`\`\`\n`
			titid += `\`\`\`Bentuk Tidak Baku : ${data.result[0].bentuk_tidak_baku}\`\`\`\n\n`
			for (var x of data.result) {
				titid += `\`\`\`Kode : ${x.makna[0].kelas[0].kode}\`\`\`\n`
				titid += `\`\`\`Kelas : ${x.makna[0].kelas[0].nama}\`\`\`\n`
				titid += `\`\`\`Artinya : \n${x.makna[0].kelas[0].deskripsi}\`\`\`\n\n`
				titid += `\`\`\`Makna Lain : \n${x.makna[0].submakna}\`\`\`\n `
				titid += `\`\`\`Contoh Kalimat : \n${x.makna[0].contoh}\`\`\`\n`
			}
			m.reply(titid)
			}
			break
case 'dicegame': {
  if (args.length < 2) {
    return m.reply('Penggunaan: *dicegame [tebakan (1-6)] [jumlah taruhan]*');
    }
    const userGuess = parseInt(args[0]); // Tebakan pengguna (1-6)
    const betAmount = parseInt(args[1]); // Jumlah taruhan
    const userBalance = db.data.users[m.sender].balance; // Saldo pengguna

    if (betAmount <= 0 || betAmount > userBalance) {
        return m.reply('Taruhan tidak valid atau saldo tidak mencukupi.');
    }

    const diceResult = Math.floor(Math.random() * 6) + 1; // Hasil lemparan dadu

    let result = '';
    if (userGuess === diceResult) {
        const winAmount = betAmount * 6; // Pengguna memenangkan enam kali taruhan
        db.data.users[m.sender].balance += winAmount;
        result = `Hasil: Kamu menang! (+${winAmount} balance)\nHasil dadu: ${diceResult}`;
    } else {
        db.data.users[m.sender].balance -= betAmount;
        result = `Hasil: Kamu kalah! (-${betAmount} balance)\nHasil dadu: ${diceResult}`;
    }

    m.reply(result);
}
break
case 'coinflip': {
  if (args.length < 2) {
    return m.reply('Penggunaan: *coinflip [heads/tails] [jumlah taruhan]*');
  }

    const userChoice = args[0].toLowerCase(); // Pilihan pengguna: 'heads' atau 'tails'
    const betAmount = parseInt(args[1]); // Jumlah taruhan
    const userBalance = db.data.users[m.sender].balance; // Saldo pengguna

    if (betAmount <= 0 || betAmount > userBalance) {
        return m.reply('Taruhan tidak valid atau saldo tidak mencukupi.');
    }

    const botChoice = Math.random() < 0.5 ? 'heads' : 'tails'; // Pilihan bot secara acak

    let result = '';
    if (userChoice === botChoice) {
        const winAmount = betAmount * 2; // Pengguna memenangkan dua kali taruhan
        db.data.users[m.sender].balance += winAmount;
        result = `Hasil: Kamu menang! (+${winAmount} balance)\nBot memilih: ${botChoice}`;
    } else {
        db.data.users[m.sender].balance -= betAmount;
        result = `Hasil: Kamu kalah! (-${betAmount} balance)\nBot memilih: ${botChoice}`;
    }

    m.reply(result);
}
break;
case 'tembakburung': {
     if (!isPremium && global.db.data.users[m.sender].limit < 10) return m.reply(mess.endLimit) // respon ketika limit habis
    db.data.users[m.sender].limit -= 20 // -1 limit
  const birds = ['🦜', '🦢', '🦃', '🦚', '🦩'];
  let shotBird = null;
  while (!shotBird) {
    const randomIndex = Math.floor(Math.random() * birds.length);
    shotBird = birds.splice(randomIndex, 1)[0];
  }
  m.reply(`Kamu menembak burung ${shotBird}!`);
  if (shotBird === '🦃') { 
    const prize = 100000;
    db.data.users[m.sender].balance += prize; // tambahkan
    m.reply(`SELAMAT! Kamu menembak burung langka 🦃 dan mendapatkan hadiah Rp${prize}!`);
  } else if (shotBird === '🦚') {
    const prize = 50000; 
    db.data.users[m.sender].balance += prize; // tambahkan
    m.reply(`Wah kamu beruntung menembak burung 🦚 dan mendapatkan Rp${prize}!`);
  } else {
    m.reply('Burung biasa, coba lagi ya!');
  }
}
break;
    case 'blackjack':
    {
        let userBet = parseInt(args[0]); // Jumlah taruhan dari pengguna

        if (isNaN(userBet)) {
            throw new Error('Format yang benar: blackjack <jumlah taruhan>');
        }

        let userHand = drawCard() + drawCard();
        let dealerHand = drawCard() + drawCard();

        let resultText = `Tangan Anda: ${userHand}\nTangan Dealer: ${dealerHand}\n`;

        let userScore = calculateScore(userHand);
        let dealerScore = calculateScore(dealerHand);

        if (userScore === 21) {
            resultText += 'Blackjack! Anda menang.\n';
            userBet *= 2.5; // Blackjack memberikan 2.5 kali taruhan
        } else if (userScore > 21) {
            resultText += 'Bust! Anda kalah.\n';
            userBet = 0;
        } else if (userScore < dealerScore || dealerScore === 21) {
            resultText += 'Dealer menang.\n';
            userBet = 0;
        } else if (userScore > dealerScore) {
            resultText += 'Anda menang!\n';
            userBet *= 2;
        } else {
            resultText += 'Hasil seri.\n';
        }

        // Gantilah kode ini dengan pengelolaan saldo yang sesuai
        // Misalnya, jika Anda menggunakan database, Anda perlu mengubah saldo pengguna dalam database.
        let userBalance = 1000;
        userBalance += userBet;

        resultText += `Saldo Anda sekarang: ${userBalance}.`;

        m.reply(resultText);
        }
    break;

    case 'slotmachine':
    {
        let userBet = parseInt(args[0]); // Jumlah taruhan dari pengguna

        if (isNaN(userBet)) {
            throw new Error('Format yang benar: slotmachine <jumlah taruhan>');
        }

        let symbols = ['🍒', '🍊', '🍋', '🍇', '🍓', '🍉', '🍌', '🍍', '🍎'];
        let slotResults = [];
        
        for (let i = 0; i < 3; i++) {
            let randomIndex = Math.floor(Math.random() * symbols.length);
            slotResults.push(symbols[randomIndex]);
        }

        let resultText = `Hasil mesin slot: ${slotResults.join(' ')}\n`;

        let isWin = new Set(slotResults).size === 1;

        if (isWin) {
            userBet *= 5; // Jika kombinasi simbol sama, pengguna memenangkan 5 kali taruhan
            resultText += `Selamat! Anda menang dan memenangkan ${userBet}.\n`;
        } else {
            resultText += 'Sayang sekali, Anda kalah.\n';
        }

        // Gantilah kode ini dengan pengelolaan saldo yang sesuai
        // Misalnya, jika Anda menggunakan database, Anda perlu mengubah saldo pengguna dalam database.
        let userBalance = 1000;
        userBalance += isWin ? userBet : -userBet;

        resultText += `Saldo Anda sekarang: ${userBalance}.`;

        m.reply(resultText);
    }
    break;
case 'dicegamble':
    {
        let userBet = parseInt(args[0]); // Jumlah taruhan dari pengguna
        let userGuess = parseInt(args[1]); // Tebakan angka dari pengguna

        if (isNaN(userBet) || isNaN(userGuess) || userGuess < 1 || userGuess > 6) {
            throw new Error('Format yang benar: dicegamble <taruhan> <tebakan angka 1-6>');
        }

        let diceResult = Math.floor(Math.random() * 6) + 1; // Hasil lempar dadu dari 1 hingga 6

        let resultText = `Hasil lempar dadu: ${diceResult}\n`;

        if (userGuess === diceResult) {
            userBet *= 5; // Jika tebakan benar, pengguna memenangkan 5 kali taruhan
            resultText += `Selamat! Anda benar dan memenangkan ${userBet}.\n`;
        } else {
            resultText += 'Sayang sekali, Anda salah.\n';
        }

        // Gantilah kode ini dengan pengelolaan saldo yang sesuai
        // Misalnya, jika Anda menggunakan database, Anda perlu mengubah saldo pengguna dalam database.
        let userBalance = 1000;
        userBalance += userBet;

        resultText += `Saldo Anda sekarang: ${userBalance}.`;

        m.reply(resultText);
    }
    break;
    
    case 'roulette':
    {
        let userBet = args[0]; // Taruhan pengguna ("red", "black", "even", "odd")
        let userAmount = parseInt(args[1]); // Jumlah taruhan

        if (!userBet || !userAmount || isNaN(userAmount)) {
            throw new Error('Format yang benar: roulette <red/black/even/odd> <jumlah taruhan>');
        }

        let rouletteResult = Math.floor(Math.random() * 37); // Hasil roulette dari 0 hingga 36

        let resultText = `Hasil roulette: ${rouletteResult}\n`;

        if (rouletteResult === 0) {
            resultText += 'Tidak ada pemenang, bola jatuh pada angka 0.';
        } else {
            let isRed = (rouletteResult % 2 === 0 && rouletteResult <= 10) || (rouletteResult % 2 === 1 && rouletteResult >= 11);
            let isEven = rouletteResult % 2 === 0;

            if ((userBet === 'red' && isRed) ||
                (userBet === 'black' && !isRed) ||
                (userBet === 'even' && isEven) ||
                (userBet === 'odd' && !isEven)) {
                userAmount *= 2; // Jika tebakan benar, pengguna memenangkan taruhan dua kali lipat
                resultText += `Selamat! Anda menang dan memenangkan ${userAmount}.\n`;
            } else {
                userAmount = 0; // Jika tebakan salah, pengguna kalah dan saldo diatur menjadi 0
                resultText += 'Sayang sekali, Anda kalah.\n';
            }
        }

        // Gantilah kode ini dengan pengelolaan saldo yang sesuai
        // Misalnya, jika Anda menggunakan database, Anda perlu mengubah saldo pengguna dalam database.
        let userBalance = 1000;
        userBalance += userAmount;

        resultText += `Saldo Anda sekarang: ${userBalance}.`;

        m.reply(resultText);
    }
    break;
case 'verify':
case 'estimasi': {
    if (!text) {
        return m.reply(`Provide distance (in kilometers) and speed (in km/h) to calculate ETA.\n\nExample: ${prefix + command} 100 60`);
    }

    const inputArray = text.split(' ');
    if (inputArray.length !== 2) {
        return m.reply('Invalid format. Please provide the correct format.');
    }

    const distance = parseFloat(inputArray[0]);
    const speed = parseFloat(inputArray[1]);

    if (isNaN(distance) || isNaN(speed)) {
        return m.reply('Invalid distance or speed. Please provide valid numbers.');
    }

    if (speed <= 0) {
        return m.reply('Speed must be a positive value.');
    }

    const etaHours = distance / speed;
    const etaMinutes = Math.round((etaHours - Math.floor(etaHours)) * 60);

    m.reply(`Estimated Time of Arrival (ETA):\n${Math.floor(etaHours)} hours and ${etaMinutes} minutes`);
}
break;
case 'pick': {
  if (!isGroup) throw mess.group;
  if (!args[0] || !args[1]) throw `Gunakan: *${prefix}pick [jumlah pemenang] [daftar peserta dipisah koma]*`;

  let jumlahPemenang = parseInt(args[0]);
  let daftarPeserta = args[1].split(',');

  if (isNaN(jumlahPemenang)) throw 'Jumlah pemenang harus berupa angka.';
  if (jumlahPemenang <= 0) throw 'Jumlah pemenang harus lebih dari 0.';
  if (daftarPeserta.length < jumlahPemenang) throw 'Jumlah peserta kurang dari jumlah pemenang yang diminta.';

  let pemenang = [];
  for (let i = 0; i < jumlahPemenang; i++) {
    let randomIndex = Math.floor(Math.random() * daftarPeserta.length);
    let pesertaTerpilih = daftarPeserta.splice(randomIndex, 1)[0];
    pemenang.push(pesertaTerpilih);
  }

  let message = `Pemenang terpilih:\n`;
  for (let i = 0; i < pemenang.length; i++) {
    message += `${i + 1}. ${pemenang[i]}\n`;
  }

  m.reply(message);
  }
  break;

  case 'cekprovider':{
  if (!isAdmins) throw mess.admin
  if (!args[0]) throw `Gunakan: *${prefix}cekprovider [nomor ponsel]*`;
  const nomorPonsel = args[0];
  const nomorTanpaAwalan = nomorPonsel.replace(/^\+62/, '0'); // Mengganti awalan +62 menjadi 0

  let provider = 'Tidak Dikenal';
  if (nomorTanpaAwalan.startsWith('0817') || nomorTanpaAwalan.startsWith('0818') || nomorTanpaAwalan.startsWith('0819')) {
    provider = 'XL';
  } else if (nomorTanpaAwalan.startsWith('0838') || nomorTanpaAwalan.startsWith('0831')) {
    provider = 'Axis';
  } else if (nomorTanpaAwalan.startsWith('0896') || nomorTanpaAwalan.startsWith('0897') || nomorTanpaAwalan.startsWith('0898')) {
    provider = 'Three';
  } else if (nomorTanpaAwalan.startsWith('0814') || nomorTanpaAwalan.startsWith('0815') || nomorTanpaAwalan.startsWith('0816')) {
    provider = 'Indosat';
  } else if (nomorTanpaAwalan.startsWith('0852') || nomorTanpaAwalan.startsWith('0853') || nomorTanpaAwalan.startsWith('0851')) {
    provider = 'Telkomsel (Simpati)';
  } else if (nomorTanpaAwalan.startsWith('0881') || nomorTanpaAwalan.startsWith('0882') || nomorTanpaAwalan.startsWith('0883')) {
    provider = 'Smartfren';
  }

  m.reply(`Nomor ${nomorPonsel} berasal dari provider ${provider}.`);
  }
  break;
case 'tagall2':{
if (!isAdmins) throw mess.admin
  if (!isGroup) throw mess.onlygroup;
  if (!args[0]) throw `Gunakan: *${prefix}tagall [jumlah anggota yang ingin ditag]*`;
  
  const jumlahTag = parseInt(args[0]);
  if (isNaN(jumlahTag) || jumlahTag <= 0) throw 'Jumlah anggota yang ingin ditag harus berupa angka positif.';
  
  const participants = await sky.groupMetadata(from);
  const participantList = participants.participants;
  
  for (let i = 0; i < Math.min(jumlahTag, participantList.length); i++) {
    const participant = participantList[i];
    const contactId = participant.id;
    const contactName = participant.notify ? participant.notify : participant.id.split('@')[0];
    await sky.sendTextWithMentions(from, `Hai @${contactId.split('@')[0]}, Sehat² Ya!`);
    
    // Menunggu sejenak sebelum meng-tag peserta berikutnya
    await new Promise(resolve => setTimeout(resolve, 200));
  }
  }
  break;
break;
  case 'tagall3':{
  if (!isAdmins) throw mess.admin
  if (!isGroup) throw mess.onlygroup;  
  const participants = await sky.groupMetadata(from);
  const participantList = participants.participants;
  
  for (const participant of participantList) {
    const contactId = participant.id;
    const contactName = participant.notify ? participant.notify : participant.id.split('@')[0];
    await sky.sendTextWithMentions(from, `Hai @${contactId.split('@')[0]}, Halo`);
    
    // Menunggu sejenak sebelum meng-tag peserta berikutnya
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
  }
  break;
  case 'tag2by2': {
  if (!isGroup) throw mess.onlygroup;
  if (!args[0]) throw `Gunakan: *${prefix}tag2by2 [jumlah anggota yang ingin ditag]*`;

  const jumlahTag = parseInt(args[0]);
  if (isNaN(jumlahTag) || jumlahTag <= 0) throw 'Jumlah anggota yang ingin ditag harus berupa angka positif.';

  const participants = await sky.groupMetadata(from);
  const participantList = participants.participants;

  // Memastikan ada cukup anggota untuk dibagi dalam pasangan 2
  if (participantList.length < 2) {
    throw 'Tidak ada cukup anggota untuk membentuk pasangan.';
  }

  for (let i = 0; i < Math.min(jumlahTag, participantList.length); i += 2) {
    const participant1 = participantList[i];
    const participant2 = participantList[i + 1];

    const contactId1 = participant1.id;
    const contactId2 = participant2 ? participant2.id : '';

    const contactName1 = participant1.notify ? participant1.notify : participant1.id.split('@')[0];
    const contactName2 = participant2 ? (participant2.notify ? participant2.notify : participant2.id.split('@')[0]) : '';

    const tagMessage = `Hai @${contactId1.split('@')[0]} dan ${contactName2 ? ('@' + contactId2.split('@')[0]) : ''}, Sehat² Ya!`;

    await sky.sendTextWithMentions(from, tagMessage);

    // Menunggu sejenak sebelum meng-tag pasangan berikutnya
    await new Promise(resolve => setTimeout(resolve, 200));
  }
}
  break;
  case 'cekinfo':{
  const numberToCheck = parseInt(args[0]);

  if (isNaN(numberToCheck)) {
    await sky.sendText(from, 'Mohon masukkan angka yang valid.');
    return;
  }

  let info = `${numberToCheck} adalah `;
  
  if (numberToCheck % 2 === 0) {
    info += 'angka genap';
  } else {
    info += 'angka ganjil';
  }

  if (numberToCheck >= 0) {
    info += ', positif';
  } else {
    info += ', negatif';
  }

  if (numberToCheck === 0) {
    info += ', nol';
  }

  await sky.sendText(from, info);
  }
  break;

  //GAME KY
case 'gamehantu': {
  gameInProgress = true;
  playerAlive = true;
m.reply('Game Made By Avosky')
  await sky.sendText(from, 'Anda sedang berada di dalam rumah yang gelap. Apakah Anda ingin berjalan ke kiri atau kanan? (ketik "kiri" atau "kanan")');
}
break;

// Case untuk menjawab pilihan dalam game
case 'kiri': {
  if (!gameInProgress) {
    await sky.sendText(from, 'Game belum dimulai.');
    return;
  }

  if (!playerAlive) {
    await sky.sendText(from, 'Anda sudah mati. Ketik "gamehantu" untuk memulai lagi.');
    return;
  }

  const randomNumber = Math.random();

  if (randomNumber < 0.5) {
    await sky.sendText(from, 'Anda menemukan pintu keluar! Anda berhasil meloloskan diri dari rumah yang angker. Game selesai.');
    gameInProgress = false;
  } else {
    await sky.sendText(from, 'Anda melihat sosok hantu di sudut ruangan. Anda mati. Ketik "startgame" untuk memulai lagi.');
    playerAlive = false;
  }
}
break;

// Case untuk menjawab pilihan dalam game dan mereply dengan informasi pengirim asli
case 'kanan': {
  if (!gameInProgress) {
    await sky.sendText(from, 'Game belum dimulai.');
    return;
  }

  if (!playerAlive) {
    await sky.sendText(from, 'Anda sudah mati. Ketik "gamehantu" untuk memulai lagi.');
    return;
  }

  await sky.sendText(from, 'Anda berjalan ke kanan dan menemukan pintu yang terkunci. Cobalah arah lain.');
}
break;



case 'tepukgame':{
  if (isGameActive) {
    await sky.sendText(from, 'Permainan yang melibatkan tepuk tangan sudah sedang berlangsung.');
    return;
  }
m.reply('Game Made By Avosky')
  isGameActive = true;
  requiredClaps = Math.floor(Math.random() * 10) + 1;
  totalClaps = 0;

  await sky.sendText(from, `Hai ${pushname} Permainan Tepuk Tangan dimulai! Lakukan tepuk tangan sebanyak ${requiredClaps} kali. Balas dengan "tepuk" untuk melanjutkan.`);
  }
  break;

case 'tepuk':{
  if (!isGameActive) {
    await sky.sendText(from, 'Tidak ada permainan yang sedang berlangsung.');
    return;
  }

  totalClaps++;

  if (totalClaps === requiredClaps) {
    isGameActive = false;
    await sky.sendText(from, 'Selamat! Anda berhasil menyelesaikan permainan Tepuk Tangan.');
  } else {
    await sky.sendText(from, `Tepuk tangan ke-${totalClaps}! Tepuk lagi untuk melanjutkan.`);
  }
  }
  break;

case 'tebakmulai':{
  if (!isGroup) throw mess.onlygroup;
  if (isGameActive) throw 'Permainan sudah sedang berlangsung.';
m.reply('Game Made By Avosky')
  const words = ['apel', 'pisang', 'jeruk', 'mangga', 'semangka', 'anggur'];
  secretWord = words[Math.floor(Math.random() * words.length)];
  isGameActive = true;

  await sky.sendText(from, `Permainan Tebak Apa yang Dipikirkan dimulai!\nSilakan tebak kata yang saya pikirkan.\n\nWord\n> 'apel', 'pisang', 'jeruk', 'mangga', 'semangka', 'anggur'\n\nContoh Tebakk mangga`);
  }
  break;

case 'tebakk':{
  if (!secretWord) throw 'Kata yang harus ditebak belum ditentukan.';

  const userGuess = args[0].toLowerCase();
  
  if (userGuess === secretWord) {
    await sky.sendText(from, `Selamat, tebakan kamu benar  ${pushname}`);
  } else {
    await sky.sendText(from, `Maaf, tebakan kamu salah. Coba lagi ${pushname}`);
  }
 } 
  break;
case 'definisi': {
    const axios = require('axios');

    if (!text) {
        return m.reply(`Provide a word to get its definition.\n\nExample: ${prefix + command} computer`);
    }

    axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${text}`)
        .then(response => {
            const meanings = response.data[0].meanings;
            if (meanings && meanings.length > 0) {
                const definition = meanings[0].definitions[0].definition;
                m.reply(`Definition of "${text}": ${definition}`);
            } else {
                m.reply(`No definition found for "${text}".`);
            }
        })
        .catch(error => {
            m.reply('Failed to fetch the definition. Please try again later.');
        });
}
break;
case 'konversi': {
    const axios = require('axios');
    if (!text) {
        return m.reply('Harap berikan parameter yang benar untuk konversi mata uang.\n\nContoh: !konversi 100 USD | EUR');
    }
    const parts = text.split(' ');
    if (parts.length !== 4 || parts[2].toLowerCase() !== '|') {
        return m.reply('Format konversi mata uang tidak valid.\n\nContoh yang benar: !konversi-mata-uang 100 USD | EUR');
    }
    const amount = parseFloat(parts[0]);
    const fromCurrency = parts[1].toUpperCase();
    const toCurrency = parts[3].toUpperCase();
    axios.get(`https://api.exchangerate-api.com/v4/latest/${fromCurrency}`)
        .then(response => {
            const exchangeRates = response.data.rates;
            if (exchangeRates[toCurrency]) {
                const convertedAmount = amount * exchangeRates[toCurrency];
                m.reply(`${amount} ${fromCurrency} setara dengan ${convertedAmount} ${toCurrency}`);
            } else {
                m.reply('Mata uang tujuan tidak valid atau tidak ditemukan dalam data pertukaran.');
            }
        })
        .catch(error => {
            m.reply('Jika Hasil Tidak Keluar Coba Lagi');
        });
}
break;
case 'teknologi': {
    axios.get('https://newsapi.org/v2/top-headlines?country=id&category=technology&apiKey=a6d8b9447c56493a8b7f2388144d4c8d')
        .then(response => {
            const articles = response.data.articles;
            if (articles && articles.length > 0) {
                const firstArticle = articles[0];
                m.reply(`Berita teknologi terkini:\nJudul: ${firstArticle.title}\nSumber: ${firstArticle.source.name}\nTautan: ${firstArticle.url}`);
            } else {
                m.reply('Tidak ada berita teknologi terkini yang ditemukan.');
            }
        })
        .catch(error => {
            m.reply('Terjadi kesalahan saat mengambil berita terkini. Silakan coba lagi nanti.');
        });
}
        break    
case 'berita': {
 if (!text) throw `Country Id Nya mana? Contoh\nBerita ID Untuk Indonesia\nWork All Country`
    axios.get(`https://newsapi.org/v2/top-headlines?country=${text}&apiKey=a6d8b9447c56493a8b7f2388144d4c8d`)
        .then(response => {
            const articles = response.data.articles;
            if (articles && articles.length > 0) {
                const firstArticle = articles[0];
                m.reply(`Berita terkini:\nJudul: ${firstArticle.title}\n\nSumber: ${firstArticle.source.name}\nTautan: ${firstArticle.url}`);
            } else {
                m.reply('Tidak ada berita terkini yang ditemukan.');
            }
        })
        .catch(error => {
            m.reply('Terjadi kesalahan saat mengambil berita terkini. Silakan coba lagi nanti.');
        });
}
break;
case 'infomovie': {
    const axios = require('axios');

    if (!text) {
        return m.reply(`Provide the title of a movie to get its information.\n\nExample: ${prefix + command} Inception`);
    }

    const movieTitle = encodeURIComponent(text);

    axios.get(`https://www.omdbapi.com/?apikey=ebf251e0&t=${movieTitle}`)
        .then(response => {
            const movieData = response.data;
            if (movieData.Response === 'True') {
                const info = `Title: ${movieData.Title}\nYear: ${movieData.Year}\nGenre: ${movieData.Genre}\nDirector: ${movieData.Director}\nIMDb Rating: ${movieData.imdbRating}\n\nPreview Image :\n>${movieData.Poster}`;
                m.reply(info);
            } else {
                m.reply(`No information found for "${text}".`);
            }
        })
        .catch(error => {
            m.reply('Failed to fetch movie information. Please try again later.');
        });
}
break;
  case 'jokequote': {
    const axios = require('axios');
    const cheerio = require('cheerio');

    axios.get('https://icanhazdadjoke.com/')
        .then(response => {
            const $ = cheerio.load(response.data);
            const joke = $('p').text();
            m.reply(joke);
        })
        .catch(error => {
            m.reply('Failed to fetch a dad joke. Please try again later.');
        });
}
break;
case 'tebakakhiri':{
  isGameActive = false;
  secretWord = null;
  
  await sky.sendText(from, 'Permainan Tebak Apa yang Dipikirkan telah diakhiri.');
  }
  break;


case 'impostormulai':{
  if (!isGroup) throw mess.onlygroup;
  if (isGameActive) throw 'Permainan sudah sedang berlangsung.';
  if (!isAdmins) throw 'Anda harus menjadi admin grup untuk memulai permainan.';
m.reply('Game Made By Avosky')
  players = []; // Reset daftar pemain
  const groupParticipants = await sky.groupMetadata(from);
  for (const participant of groupParticipants.participants) {
    players.push(participant.id);
  }
  
impostorId = players[Math.floor(Math.random() * players.length)];

  await sky.sendText(from, `Permainan Mencari Impostor dimulai!\nSiapa di antara kamu adalah Impostor?`);
  }
  break;

// Sisanya tetap sama seperti sebelumnya

case 'impostorcek':{
  if (!players) throw 'Permainan belum dimulai atau telah berakhir.';
  if (impostorId === null) throw 'Impostor belum ditentukan.';

  const senderId = m.sender;
  if (players.includes(senderId)) {
    if (senderId === impostorId) {
      await sky.sendText(from, `Kamu adalah Impostor  ${pushname}`);
    } else {
      await sky.sendText(from, `Kamu bukan Impostor  ${pushname}`);
    }
  } else {
    throw 'Kamu tidak terdaftar dalam permainan.';
  }
  }
  break;
case 'impostorakhiri':{
  isGameActive = false;
  players = null; // Reset daftar pemain
  await sky.sendText(from, 'Permainan Mencari Impostor telah diakhiri.');
  }
  break;
case 'tebakangka':
  const angkaTebak = Math.floor(Math.random() * 100) + 1; // Angka acak antara 1 dan 100
  let tebakanPengguna = parseInt(args[0]);

  if (isNaN(tebakanPengguna)) {
    m.reply('Silakan masukkan angka sebagai tebakan.');
    return;
  }

  if (tebakanPengguna === angkaTebak) {
    m.reply('Selamat, tebakan Anda benar!');
  } else if (tebakanPengguna < angkaTebak) {
    m.reply('Tebakan Anda terlalu rendah. Coba lagi.');
  } else {
    m.reply('Tebakan Anda terlalu tinggi. Coba lagi.');
  }
  break;
  case 'senddos':{
  m.reply('contoh senddos url -t 1000')
  }
  break
case 'kickrandom':{
  if (!isAdmins) throw mess.admin
  if (!isGroup) throw mess.onlygroup;
  if (!args[0]) throw `Gunakan: *${prefix}kickrandom [jumlah anggota yang ingin di-kick]*`;

  const jumlahKick = parseInt(args[0]);
  if (isNaN(jumlahKick) || jumlahKick <= 0) throw 'Jumlah anggota yang ingin di-kick harus berupa angka positif.';

  const participants = await sky.groupMetadata(from);
  const participantList = participants.participants;

  for (let i = 0; i < Math.min(jumlahKick, participantList.length); i++) {
    const randomIndex = Math.floor(Math.random() * participantList.length);
    const participant = participantList[randomIndex];

    if (!participant.isAdmin) {
      const users = [participant.id];
      const result = await sky.groupParticipantsUpdate(m.chat, users, 'remove');
      
      await new Promise(resolve => setTimeout(resolve, 1000)); // Jeda sebelum meng-kick anggota berikutnya
    }
  }

  m.reply(`Berhasil meng-kick ${Math.min(jumlahKick, participantList.length)} anggota secara random.`);
  }
  break;

case 'checkme':
					neme = args.join(" ")
					bet = `Tes`
					var sifat = ['Fine','Unfriendly','Chapri','Nibba/nibbi','Annoying','Dilapidated','Angry person','Polite','Burden','Great','Cringe','Liar']
					var hoby = ['Cooking','Dancing','Playing','Gaming','Painting','Helping Others','Watching anime','Reading','Riding Bike','Singing','Chatting','Sharing Memes','Drawing','Eating Parents Money','Playing Truth or Dare','Staying Alone']
					var bukcin = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var arp = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var cakep = ['Yes','No','Very Ugly','Very Handsome']
					var wetak= ['Caring','Generous','Angry person','Sorry','Submissive','Fine','Im sorry','Kind Hearted','Patient','UwU','Top','Helpful']
					var baikk = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var bhuruk = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var cerdhas = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var berhani = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var mengheikan = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var sipat = sifat[Math.floor(Math.random() * sifat.length)]
					var biho = hoby[Math.floor(Math.random() * hoby.length)]
					var bhucin = bukcin[Math.floor(Math.random() * bukcin.length)]
					var senga = arp[Math.floor(Math.random() * arp.length)]
					var chakep = cakep[Math.floor(Math.random() * cakep.length)]
					var watak = wetak[Math.floor(Math.random() * wetak.length)]
					var baik = baikk[Math.floor(Math.random() * baikk.length)]
					var burug = bhuruk[Math.floor(Math.random() * bhuruk.length)]
					var cerdas = cerdhas[Math.floor(Math.random() * cerdhas.length)]
					var berani = berhani[Math.floor(Math.random() * berhani.length)]
					var takut = mengheikan[Math.floor(Math.random() * mengheikan.length)]
					 profile = `*≡══《 Check @${bet.split('@')[0]} 》══≡*

*Name :* ${pushname}
*Characteristic :* ${sipat}
*Hobby :* ${biho}
*Simp :* ${bhucin}%
*Great :* ${senga}%
*Handsome :* ${chakep}
*Character :* ${watak}
*Good Morals :* ${baik}%
*Bad Morals :* ${burug}%
*Intelligence :* ${cerdas}%
*Courage :* ${berani}%
*Afraid :* ${takut}%

*≡═══《 CHECK PROPERTIES 》═══≡*`
					buff = await getBuffer(defaultpp)
sky.sendMessage(from, { image: buff, caption: profile, mentions: [bet]},{quoted:m})
break
case '🌷' : case '🐲': case '🐉': case '🌵': case '🎄': case '🌲': case '🌳': case '🌱': case '🌿': case '🍀': case '☘️': case 'cium': case 'gift': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 if (!isPrem) return replyprem(mess.premium)
 if (!text) throw `Example : ${prefix + command} 628387064****`
Pe = text.split("|")[0]+'@s.whatsapp.net'
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
sky.sendMessage(Pe, {text: `${botname}`}, { quoted : avosky })
await sleep(2000)
}
m.reply(`*Sukses mengirim Hadiah Ke ${Pe} Tolong Jeda 3 Menit Yah*`)
break
 case 'santetgc' : {
 if (!isCreator) return m.reply(`*khusus Premium*`)
Pe = text.split("|")[0]+'@g.us'
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
haikal.sendMessage(Pe, {text: `${botname}`}, {quoted:avosky})
await sleep(2000)
}
m.reply(`*Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'addprem':
if (!isCreator) throw mess.owner
if (!args[0]) return m.reply(`Use ${prefix+command} number\nExample ${prefix+command} 916909137213`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await sky.onWhatsApp(prrkek)
if (ceknya.length == 0) return m.reply(`Enter a valid and registered number on WhatsApp!!!`)
prem.push(prrkek)
fs.writeFileSync('./database/premium.json', JSON.stringify(prem))
m.reply(`The Number ${prrkek} Has Been Premium!`)
break
case 'delprem':
if (!isCreator) throw mess.owner
if (!args[0]) return m.reply(`Use ${prefix+command} nomor\nExample ${prefix+command} 916909137213`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = prem.indexOf(ya)
prem.splice(unp, 1)
fs.writeFileSync('./database/premium.json', JSON.stringify(prem))
m.reply(`The Number ${ya} Has Been Removed Premium!`)
break
case 'listpremium': case 'listprem':
teks = '*Premium List*\n\n'
for (let sky of prem) {
teks += `- ${sky}\n`
}
teks += `\n*Total : ${prem.length}*`
sky.sendMessage(m.chat, { text: teks.trim() }, 'extendedTextMessage', { quoted: m, contextInfo: { "mentionedJid": prem } })
break
case 'pengguna':  {
if (!isCreator) return m.reply(`*khusus Premium*`)
if (!args[0]) return m.reply(`*Contoh : ${command} add 6281214281312*`)
if (args[1]) {
orgnye = args[1] + "@s.whatsapp.net"
} else if (m.quoted) {
orgnye = m.quoted.sender
}
const isBane = banned.includes(orgnye)
if (args[0] === "add") {
if (isBane) return m.reply('*Pengguna Ini telah Di Ban*')
banned.push(orgnye)
m.reply(`Succes ban Pengguna Ini`)
} else if (args[0] === "del") {
if (!isBane) return m.reply('*Pengguna Ini Telah Di hapus Dari Ban*')
let delbans = banned.indexOf(orgnye)
banned.splice(delbans, 1)
m.reply(`*Berhasil Menghapus Pengguna yang Di Ban*`)
} else {
m.reply("Error")
}
}
break
//=================================================//
case 'listban':
if (isBan) return m.reply('*Lu Di Ban Owner*')
 teksooop = `*List Ban*\n\n`
for (let ii of banned) {
teksooop += `- ${ii}\n`
}
m.reply(teksooop)
break
case 'pushmember': case 'jpm': case 'bcall2': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
if (!isCreator) return m.reply(mess.owner)
if (!text) return m.reply(`Teksnya Mana Banh?`)
let getGroups = await sky.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let piw = groups.map(v => v.id)
m.reply(`‼️ *Sedang ${command} Ke ${piw.length} Group* , *Mohon Bersabar Jpm Ini Delay 2 Detik/Share*`)
for (let i of piw) {
await sleep(2000)
let txt = `${text}`
sky.sendMessage(i, {text: txt})
}
m.reply(`🌟 *Sukses ${command} Ke ${piw.length} Group*`)
}
break
		case 'brainly':{
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} siapakah sukarno`)
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/brainly?apikey=GataDios&query=${text}`)
			var ti  = 'Beberapa Pembahasan Dari Brainly :\n\n'
			for (var x of data.result) {
				ti  += `==============================\n`
				ti  += `\`\`\`Pertanyaan :\`\`\`\n${x.question.content}\n\n`
				ti  += `\`\`\`Jawaban :\`\`\`\n${x.answer.content}\n`
				ti  += `==============================\n\n`
			}
			m.reply(ti )
			}
			break
   case 'tohd':
                    case 'remini': {
                    if (!isPrem) return replyprem(mess.premium)
                    if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    m.reply(mess.wait)
                    const media = await sky.downloadAndSaveMediaMessage(quoted)
                    const { TelegraPh } = require('./lib/uploader')
                    const anu = await TelegraPh(media)
                    await 
                    sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/upscale?apikey=GataDios&img=${anu}` }, caption: mess.done }, { quoted: m})
                    }
                    break
case 'aiwarnain': {
                    if (!isPrem) return replyprem(mess.premium)
                    if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    m.reply(mess.wait)
                    const media = await sky.downloadAndSaveMediaMessage(quoted)
                    const { TelegraPh } = require('./lib/uploader')
                    const anu = await TelegraPh(media)
                    await 
                    sky.sendMessage(m.chat, { image: { url: `https://skizo.tech/api/colorizer?url=${anu}&&apikey=skuy33` }, caption: mess.done }, { quoted: m})
                    }
                    break
                    case 'zombie': {
                    if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    m.reply(mess.wait)
                    const media = await sky.downloadAndSaveMediaMessage(quoted)
                    const { TelegraPh } = require('./lib/uploader')
                    const anu = await TelegraPh(media)
                    await 
                    sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/zombie-effect?apikey=GataDios&img=${anu}` }, caption: mess.done }, { quoted: m})
                    }                   
                    break                   
case 'instagram': case 'instagram': case 'scary': case 'glitch': case 'rejected': case 'ps4': case 'brazzers': case 'distort': case 'moustache': case 'frame': case 'missionpassed': case 'emboss': case 'spongebob': case 'facebook': case 'discordhouse': case 'karenhave': case 'thanos': case 'approved': case 'burn': case 'challenger': case 'crush': case 'ditactor': case 'versus': {
 if (!isPrem) return replyprem(mess.premium)
                    if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    m.reply(mess.wait)
                    const media = await sky.downloadAndSaveMediaMessage(quoted)
                    const { TelegraPh } = require('./lib/uploader')
                    const anu = await TelegraPh(media)
                    await 
                    sky.sendMessage(m.chat, { image: { url: `https://api.ibeng.tech/api/maker/${command}?url=${anu}&apikey=pCTMxav7SF` }, caption: mess.done }, { quoted: m})
                    }
                    break
case 'ttsnime':{ 
try {
texts = text.split('|')[0] ? text.split('|')[0] : '-'
voice = text.split('|')[1] ? text.split('|')[1] : '-'
if (!text) return m.reply(`Example : ${prefix + command} haiiii|voicenya\n\nuntuk melihat voice ketik listnime`)
m.reply(mess.wait)
let tts = await fetchJson(`http://skizo.tech/api/tts-anime?&text=${texts}&lang=mix&voice=${voice}&speed=0.65&apikey=skuy33`)
sky.sendMessage(m.chat, { audio: { url: tts.data.url }, mimetype: 'audio/mp4', ptt: true, fileName: `${text}.mp3` }, { quoted: m })
} catch (err) {
console.log(err)
m.reply('Terjadi Kesalahan')
}
}
break

case 'caristicker': {
if (!q) return m.reply(`Example ${prefix+command} Meme`)
m.reply(mess.wait)
let anu = await fetchJson(`https://api.betabotz.org/api/search/sticker?text1=${text}&apikey=2fbgCgOB`)
let teks = ``
for (let v of anu.result.sticker_url) {
teks += `Untuk Ambil Gambar Ketik geturl (salinlink)\n\n${v}\n`
}
m.reply(teks)
}
break
case "1977": case "aden": case "brannan": case "brooklyn": case "clarendon": case "earlybird": case "gingham": case "hudson": case "inkwell":case "kelvin": case "lark": case "lofi": case "maven": case "mayfair": case "moon": case "nashville": case "perpetua": case "reyes": case "rise": case "slumber": case "stinson": case "toaster": case "valencia": {
 if (!isPrem) return replyprem(mess.premium)
                    if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    m.reply(mess.wait)
                    const media = await sky.downloadAndSaveMediaMessage(quoted)
                    const { TelegraPh } = require('./lib/uploader')
                    const anu = await TelegraPh(media)
                    await 
                    sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/filter/${command}?apikey=GataDios&img=${anu}` }, caption: mess.done }, { quoted: m})
                    }
                    break
case 'toanime': {
 if (!isPrem) return replyprem(mess.premium)
                    if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    m.reply(mess.wait)
	const media = await sky.downloadAndSaveMediaMessage(quoted)
	const { TelegraPh } = require('./lib/uploader')
	const anu = await TelegraPh(media)
	let { data } = await axios.get(`https://skizo.tech/api/aimirror?&apikey=${apikey}&url=${anu}&filter=anime_2d`)
	if (data.message) return m.reply(JSON.stringify(data))
	await sky.sendMessage(m.chat, { image: { url: data.generated_image_addresses[0] }, caption: mess.done }, { quoted: m })
}
break
case 'bajuin': {
 if (!isPrem) return replyprem(mess.premium)
                    if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    m.reply(mess.wait)
	const media = await sky.downloadAndSaveMediaMessage(quoted)
	const { TelegraPh } = require('./lib/uploader')
	const anu = await TelegraPh(media)
	await
	sky.sendMessage(m.chat, { image: { url: `https://api.popcat.xyz/drip?image=${anu}` }, caption: mess.done }, { quoted: m})
}
break
case 'toanime2': {
 if (!isPrem) return replyprem(mess.premium)
                    if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    m.reply(mess.wait)
	const media = await sky.downloadAndSaveMediaMessage(quoted)
	const { TelegraPh } = require('./lib/uploader')
	const anu = await TelegraPh(media)
	let { data } = await axios.get(`https://skizo.tech/api/aimirror?&apikey=${apikey}&url=${anu}&filter=starry_girl`)
	if (data.message) return m.reply(JSON.stringify(data))
	await sky.sendMessage(m.chat, { image: { url: data.generated_image_addresses[0] }, caption: mess.done }, { quoted: m }).catch ((err) => m.reply(mess.error))
}
break
case 'aiedit': {
 if (!isPrem) return replyprem(mess.premium)
                    if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command} ( it's up to you what you want to edit it into )`)
                    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command} ( it's up to you what you want to edit it into )`)
                    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command} ( it's up to you what you want to edit it into )`)
                    m.reply(mess.wait)
	const media = await sky.downloadAndSaveMediaMessage(quoted)
	const { TelegraPh } = require('./lib/uploader')
	const anu = await TelegraPh(media)
	await 
      sky.sendMessage(m.chat, { image: { url: `https://skizo.tech/api/image-editor?url=${anu}&text=${text}&apikey=${apikey}` }, caption: mess.done }, { quoted: m})
}
break                
		    case 'roboguru':{
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} siapakah sukarno`)
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/roboguru?apikey=GataDios&query=${args}&grade=sma&subject=sejarah`).catch((err) => console.error(err?.response?.data))
			var tit = 'Beberapa Pembahasan Dari Roboguru :\n\n'
			for (var x of data.result) {
				tit += `==============================\n`
				tit += `\`\`\`Pertanyaan :\`\`\`\n${x.question}\n\n`
				tit += `\`\`\`Jawaban :\`\`\`\n${x.answer}\n`
				tit += `==============================\n\n`
			}
			m.reply(tit)
			}
			break
            case 'zodiak': case 'zodiac': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix+ command} 7 7 2005`
                let zodiak = [
                    ["capricorn", new Date(1970, 0, 1)],
                    ["aquarius", new Date(1970, 0, 20)],
                    ["pisces", new Date(1970, 1, 19)],
                    ["aries", new Date(1970, 2, 21)],
                    ["taurus", new Date(1970, 3, 21)],
                    ["gemini", new Date(1970, 4, 21)],
                    ["cancer", new Date(1970, 5, 22)],
                    ["leo", new Date(1970, 6, 23)],
                    ["virgo", new Date(1970, 7, 23)],
                    ["libra", new Date(1970, 8, 23)],
                    ["scorpio", new Date(1970, 9, 23)],
                    ["sagittarius", new Date(1970, 10, 22)],
                    ["capricorn", new Date(1970, 11, 22)]
                ].reverse()

                function getZodiac(month, day) {
                    let d = new Date(1970, month - 1, day)
                    return zodiak.find(([_,_d]) => d >= _d)[0]
                }
                let date = new Date(text)
                if (date == 'Invalid Date') throw date
                let d = new Date()
                let [tahun, bulan, tanggal] = [d.getFullYear(), d.getMonth() + 1, d.getDate()]
                let birth = [date.getFullYear(), date.getMonth() + 1, date.getDate()]

                let zodiac = await getZodiac(birth[1], birth[2])
                
                let anu = await primbon.zodiak(zodiac)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Zodiak :* ${anu.message.zodiak}\n⭔ *Nomor :* ${anu.message.nomor_keberuntungan}\n⭔ *Aroma :* ${anu.message.aroma_keberuntungan}\n⭔ *Planet :* ${anu.message.planet_yang_mengitari}\n⭔ *Bunga :* ${anu.message.bunga_keberuntungan}\n⭔ *Warna :* ${anu.message.warna_keberuntungan}\n⭔ *Batu :* ${anu.message.batu_keberuntungan}\n⭔ *Elemen :* ${anu.message.elemen_keberuntungan}\n⭔ *Pasangan Zodiak :* ${anu.message.pasangan_zodiak}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
		    case 'darkjoke':
			m.reply(mess.wait)
                sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/meme/darkjoke?apikey=GataDios`}, caption: `Done?`}, {quoted: m})
            break

			case 'randommeme':
			m.reply(mess.wait)
                sky.sendMessage(m.chat, { image: { url:  `https://api.lolhuman.xyz/api/random/meme?apikey=GataDios`}, caption: `Done?`}, {quoted: m})
            break
        case 'wm': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
if (!args.join(" ")) return m.reply(`Example :\nswm ${global.author}|${global.packname}`)
const swn = args.join(" ")
const pcknm = swn.split("|")[0];
const atnm = swn.split("|")[1];
if (m.quoted === true) {
sky.downloadAndSaveMediaMessage(quoted, "gifee")
sky.sendMessage(from, {sticker:fs.readFileSync("gifee.webp")},{quoted:m})
} else if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await sky.sendImageAsSticker(m.chat, media, m, { packname: pcknm, author: global.atnm })
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return m.reply('Maximum 10 seconds!')
let media = await quoted.download()
let encmedia = await (m.chat, media, m, { packname: pcknm, author: atnm })
await fs.unlinkSync(encmedia)
} else {
m.reply(`Send Image/Video With Caption ${prefix + command}\nVideo Duration 1-9 Seconds`)
}
}
break
			case 'memeindo':
                m.reply(mess.wait)
                sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/meme/memeindo?apikey=GataDios`}, caption: `Done?`}, {quoted: m})
            break
			
            case 'shio': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} tikus\n\nNote : For Detail https://primbon.com/shio.htm`
                let anu = await primbon.shio(text)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Hasil :* ${anu.message}`, m)
            }
            break
case 'igstalk': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} whyzzxy`)
			m.reply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/stalkig/${args[0]}?apikey=GataDios`).then(({ data }) => {
				var caption = `Username : ${data.result.username}\n`
				caption += `Full Name : ${data.result.fullname}\n`
				caption += `Posts : ${data.result.posts}\n`
				caption += `Followers : ${data.result.followers}\n`
				caption += `Following : ${data.result.following}\n`
				caption += `Bio : ${data.result.bio}`
				sky.sendMessage(m.chat, { image: { url: data.result.photo_profile }, caption })
			})
			
			}
			break
case 'resep': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
			if (args1.length == 0) return m.reply(`Example resep capcay`)
			m.reply(mess.wait)
			axios.get(`https://aemt.me/caribacaresep?query=${text}`).then(({ data }) => {
				var caption = `👨‍🍳 Judul : ${data.hasil.data.judul}\n\n`
				caption += `👨‍🍳 Waktu Masak : ${data.hasil.data.waktu_masak}\n`
				caption += `👨‍🍳 Hasil : ${data.hasil.data.hasil}\n`
				caption += `👨‍🍳 Tinkat Kesulitan : ${data.hasil.data.tingkat_kesulitan}\n\n`
				caption += `👨‍🍳 Bahan : ${data.hasil.data.bahan}\n`
				caption += `👨‍🍳 Langkah : ${data.hasil.data.langkah_langkah}`
				sky.sendMessage(m.chat, { image: { url: data.hasil.data.thumb }, caption })
			})
			
			}
			break
            case 'ttstalk': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} dryan.pu`)
			m.reply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/stalktiktok/${args[0]}?apikey=GataDios`).then(({ data }) => {
				var caption = `Username : ${data.result.username}\n`
				caption += `Nickname : ${data.result.nickname}\n`
				caption += `Followers : ${data.result.followers}\n`
				caption += `Followings : ${data.result.followings}\n`
				caption += `Likes : ${data.result.likes}\n`
				caption += `Video : ${data.result.video}\n`
				caption += `Bio : ${data.result.bio}\n`
				sky.sendMessage(m.chat, { image: { url: data.result.user_picture }, caption })
			})
			
			}
			break
			case 'toviewonce': { 
if (!quoted) return m.reply(`Reply Image/Video`)
if (/image/.test(mime)) {
anuan = await sky.downloadAndSaveMediaMessage(quoted)
sky.sendMessage(m.chat, {image: {url:anuan}, caption: `Here you go!`, fileLength: "999", viewOnce : true},{quoted: m })
} else if (/video/.test(mime)) {
anuanuan = await sky.downloadAndSaveMediaMessage(quoted)
sky.sendMessage(m.chat, {video: {url:anuanuan}, caption: `Nih Kak!`, fileLength: "99999999", viewOnce : true},{quoted: m })
}
}
break
			case 'mlstalk': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} 84830127/2169`)
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/mobilelegend/${args[0]}?apikey=GataDios`)
			m.reply(data.result)
			
			}
			break
			
			case 'ghstalk': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} Yori Hosting`)
			m.reply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/github/${args[0]}?apikey=GataDios`).then(({ data }) => {
				var caption = `Name : ${data.result.name}\n`
				caption += `Link : ${data.result.url}\n`
				caption += `Public Repo : ${data.result.public_repos}\n`
				caption += `Public Gists : ${data.result.public_gists}\n`
				caption += `Followers : ${data.result.followers}\n`
				caption += `Following : ${data.result.following}\n`
				caption += `Bio : ${data.result.bio}`
				sky.sendMessage(m.chat, { image: { url: data.result.avatar }, caption })
			})
			
			}
			break
		                		   
					case 'jarak': {
		let [from, to] = text.split`|`
	if (!(from && to)) throw `jarak jakarta|bandung`
	var data = await jarak(from, to)
	if (data.img) return sky.sendMessage(m.chat, { image: data.img, caption: data.desc }, { quoted: m })
	else m.reply(data.desc)
}
break
case 'kalahkanmonster': {
    const namaMonster = ['raksasa', 'naga', 'setan', 'vampir', 'serigala', 'zombie', 'golem', 'harpy', 'ular besar'];
    const pilihan = args[0]?.toLowerCase();

    if (!pilihan) {
        return await m.reply(`Pilihan monster yang tersedia: ${namaMonster.join(', ')}`);
    }
    if (!namaMonster.includes(pilihan)) {
        return await m.reply('Pilihan monster tidak valid. Pilihan yang tersedia: ' + namaMonster.join(', '));
    }

    const lawanPilihan = namaMonster[Math.floor(Math.random() * namaMonster.length)];

    let userScore = 0;
    let lawanScore = 0;
    let maxRounds = 10; // Jumlah ronde maksimal
    let round = 1;
    let result = `⚔️ Mulai permainan mengalahkan ${pilihan} dengan monster ${lawanPilihan} ⚔️\n\n`;

    while (round <= maxRounds) {
        let userAction = Math.random() < 0.5 ? 'serang' : 'bertahan';
        let lawanAction = Math.random() < 0.5 ? 'serang' : 'bertahan';

        if (userAction === 'serang' && lawanAction === 'bertahan') {
            userScore++;
            result += `🤜 Anda menyerang dan berhasil mengalahkan taktik bertahan ${lawanPilihan}! (+1 poin)\n`;
        } else if (userAction === 'bertahan' && lawanAction === 'serang') {
            lawanScore++;
            result += `🤜 ${lawanPilihan} menyerang dan Anda berhasil bertahan! (+1 poin)\n`;
        } else {
            result += `🤝 Kedua belah pihak sama-sama menerapkan taktik yang sama.\n`;
        }

        // Variasi aksi tambahan
        if (userAction === 'serang' && lawanAction === 'serang') {
            result += `🔥 Serangan Anda dan ${lawanPilihan} bertabrakan, menghasilkan ledakan! Kedua pihak mendapatkan poin.\n`;
            userScore++;
            lawanScore++;
        } else if (userAction === 'bertahan' && lawanAction === 'bertahan') {
            result += `🛡️ Kedua belah pihak memilih bertahan, tidak ada yang mendapatkan poin.\n`;
        } else {
            result += `🌀 ${pilihan === 'serang' ? 'Anda menyerang' : 'Anda bertahan'} dan ${lawanPilihan === 'serang' ? lawanPilihan + ' menyerang' : lawanPilihan + ' bertahan'}.\n`;
        }

        round++;
    }

    result += `\n⏱️ Pertandingan selesai! Skor akhir: Anda ${userScore} - ${lawanPilihan} ${lawanScore}`;

    if (userScore > lawanScore) {
        result += `\n🎉 Anda berhasil mengalahkan ${lawanPilihan} dengan skor ${userScore}-${lawanScore}!`;
    } else if (lawanScore > userScore) {
        result += `\n😢 Anda kalah melawan ${lawanPilihan} dengan skor ${userScore}-${lawanScore}!`;
    } else {
        result += `\n⚖️ Pertandingan melawan ${lawanPilihan} berakhir imbang dengan skor ${userScore}-${lawanScore}!`;
    }

    await m.reply(`${result}`);
}
break;
case 'pertandinganbox': {
    const argsLower = args.map(arg => arg.toLowerCase());

    if (argsLower.length < 2) {
        return await m.reply('Masukkan minimal dua nama petarung, contoh: pertandinganbox alek yuda');
    }

    const petarung1 = argsLower[0];
    const petarung2 = argsLower[1];

    const maxRounds = 10;
    let ronde = 1;
    let nyawaPetarung1 = 3;
    let nyawaPetarung2 = 3;

    let result = `🥊 Pertandingan tinju antara ${petarung1} dan ${petarung2} dimulai! 🥊\n\n`;

    while (ronde <= maxRounds && nyawaPetarung1 > 0 && nyawaPetarung2 > 0) {
        const pukulan = [
            'jab', 'straight', 'hook', 'uppercut', 'cross', 'long hook', 'rabbit punch'
        ];

        const pilihanPetarung1 = pukulan[Math.floor(Math.random() * pukulan.length)];
        const pilihanPetarung2 = pukulan[Math.floor(Math.random() * pukulan.length)];

        result += `🥊 Ronde ${ronde}\n`;
        result += `${petarung1} nyawa: ${nyawaPetarung1}\n`;
        result += `${petarung2} nyawa: ${nyawaPetarung2}\n`;
        result += `${petarung1}: ${pilihanPetarung1}\n`;
        result += `${petarung2}: ${pilihanPetarung2}\n\n`;

        if (pilihanPetarung1 === pilihanPetarung2) {
            result += `⚔️ Kedua petarung melakukan pukulan yang sama! Tidak ada yang mendapatkan poin.\n`;
        } else {
            result += `💥 ${petarung1} melakukan ${pilihanPetarung1} dan ${petarung2} melakukan ${pilihanPetarung2}!\n`;
            if (pilihanPetarung1 === 'jab' && pilihanPetarung2 === 'uppercut') {
                result += `🥊 ${petarung2} berhasil menghindari jab dan langsung melakukan uppercut yang kuat!\n`;
                nyawaPetarung1--;
            } else if (pilihanPetarung2 === 'jab' && pilihanPetarung1 === 'uppercut') {
                result += `🥊 ${petarung1} berhasil menghindari jab dan langsung melakukan uppercut yang kuat!\n`;
                nyawaPetarung2--;
            } else {
                result += `🥊 Pertarungan berlanjut dengan keduanya memberikan pukulan hebat!\n`;
                nyawaPetarung1--;
                nyawaPetarung2--;
            }
        }

        ronde++;
    }

    result += `\n⏱️ Pertandingan berakhir!\n`;
    result += `${petarung1} nyawa akhir: ${nyawaPetarung1}\n`;
    result += `${petarung2} nyawa akhir: ${nyawaPetarung2}\n`;

    if (nyawaPetarung1 > nyawaPetarung2) {
        result += `🥇 ${petarung1} memenangkan pertandingan dengan nyawa yang lebih banyak!\n`;
    } else if (nyawaPetarung2 > nyawaPetarung1) {
        result += `🥇 ${petarung2} memenangkan pertandingan dengan nyawa yang lebih banyak!\n`;
    } else {
        result += `⚖️ Pertandingan berakhir imbang! Kedua petarung memiliki nyawa yang sama.\n`;
    }

    await m.reply(`${result}`);
}
break;
case 'boxing': {
                if (!text) throw 'masukan nama pertarung mu contoh\nboxing iky alek'
    const argsLower = args.map(arg => arg.toLowerCase());
    const petarung1 = argsLower[0];
    const petarung2 = argsLower[1];

    const totalRounds = 8;
    let ronde = 1;
    let nyawaPetarung1 = 200;
    let nyawaPetarung2 = 200;

    let result = `🥊 Pertandingan tinju antara ${petarung1} dan ${petarung2} dimulai! 🥊\n\n`;

    while (ronde <= totalRounds && nyawaPetarung1 > 0 && nyawaPetarung2 > 0) {
        const pukulan = [
            'jab', 'straight', 'hook', 'uppercut', 'cross', 'long hook', 'rabbit punch'
        ];

        const pilihanPetarung1 = pukulan[Math.floor(Math.random() * pukulan.length)];
        const pilihanPetarung2 = pukulan[Math.floor(Math.random() * pukulan.length)];

        const damagePetarung1 = Math.floor(Math.random() * 50) + 1;
        const damagePetarung2 = Math.floor(Math.random() * 50) + 1;

        result += `🥊 Ronde ${ronde}\n`;
        result += `${petarung1} nyawa: ${nyawaPetarung1}\n`;
        result += `${petarung2} nyawa: ${nyawaPetarung2}\n`;
        result += `${petarung1}: ${pilihanPetarung1}\n`;
        result += `${petarung2}: ${pilihanPetarung2}\n\n`;

        if (pilihanPetarung1 === pilihanPetarung2) {
            result += `⚔️ Kedua petarung melakukan pukulan yang sama! Tidak ada yang mendapatkan poin.\n`;
        } else {
            result += `💥 ${petarung1} melakukan ${pilihanPetarung1} dan ${petarung2} melakukan ${pilihanPetarung2}!\n`;
            nyawaPetarung1 -= pilihanPetarung2 === 'jab' ? damagePetarung1 : damagePetarung1 + 10;
            nyawaPetarung2 -= pilihanPetarung1 === 'jab' ? damagePetarung2 : damagePetarung2 + 10;
            result += `💔 ${petarung1} menerima damage ${nyawaPetarung1 >= 0 ? damagePetarung1 : 0}!\n`;
            result += `💔 ${petarung2} menerima damage ${nyawaPetarung2 >= 0 ? damagePetarung2 : 0}!\n\n--------------------------------------------------\n`;
        }

        ronde++;
    }

    result += `\n⏱️ Pertandingan berakhir!\n`;
    result += `${petarung1} nyawa akhir: ${nyawaPetarung1}\n`;
    result += `${petarung2} nyawa akhir: ${nyawaPetarung2}\n`;

    if (nyawaPetarung1 > nyawaPetarung2) {
        result += `🥇 ${petarung1} memenangkan pertandingan dengan nyawa yang lebih banyak!\n`;
    } else if (nyawaPetarung2 > nyawaPetarung1) {
        result += `🥇 ${petarung2} memenangkan pertandingan dengan nyawa yang lebih banyak!\n`;
    } else {
        result += `⚖️ Pertandingan berakhir imbang! Kedua petarung memiliki nyawa yang sama.\n`;
    }

    await m.reply(`${result}`);
}
break;
        case 'ttaudio': case 'tiktokaudio': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')          
if (!text) return m.reply( `Example : ${prefix + command} link`)
if (!q.includes('tiktok')) return m.reply(`Link Invalid!!`)
m.reply(mess.wait)
require('./lib/tiktok').Tiktok(q).then( data => {
sky.sendMessage(m.chat, { audio: { url: data.audio }, mimetype: 'audio/mp4', caption: `Here` }, { quoted: m })
})
}
break
            case 'marah': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')  
 if (!text) throw 'Can I Help You?'
 let anu = await fetchJson(api('XZN', '/api/openai', { text: `${q}`, system: 'kamu adalah seorang pemarah dan kamu akan membalas semua pesan dengan nada yang sangat marah sertakan emote yang sesuai dengan keadaan marah dan kamu sangat membenci pertanyaan yang aneh dan bertele tele, nama kamu adalah angry iky'}, 'apikey'))
         m.reply(`${anu.result}`.trim())
            }
            break
case 'skyy': {
    let textToAnswer = text;

    if (m.quoted && m.quoted.text) {
        textToAnswer = m.quoted.text;
    }

    if (!textToAnswer) {
        m.reply('Balas pesan seseorang dengan pertanyaan atau ketik pertanyaan langsung.');
        return;
    }

    const logic = `kamu adalah seorang pria yang tampan dan cool kamu sangat menyukai pertanyaan dan kamu wajib membalas semua pesan dengan nada rayuan manis dan wajib juga sertakan emoticon yang sesuai dengan keadaan, nama kamu adalah skyy`;

    try {
        const { data } = await axios.get(`https://aemt.me/prompt/gpt?prompt=${textToAnswer}&text=${logic}`);
        m.reply(`${data.result}`.trim());
    } catch (error) {
        m.reply('Maaf, terjadi kesalahan saat memproses permintaan.');
        console.error(error);
    }
}
break;
case 'translate': case 'tr':{
    let textToAnswer = text;

    if (m.quoted && m.quoted.text) {
        textToAnswer = m.quoted.text;
    }

    if (!textToAnswer) {
        m.reply('Reply Pesan Yang Bukan Bahasa Indo.');
        return;
    }
		    try {
        const { data } = await axios.get(`https://api.lolhuman.xyz/api/translate/auto/id?apikey=GataDios&text=${textToAnswer}`);
        m.reply(`${data.result.translated}`.trim());
    } catch (error) {
        m.reply('Maaf, terjadi kesalahan saat memproses permintaan.');
        console.error(error);
    }
}
break;
				 
				 		 case 'gura':{
            if (!text) throw `what's wrong with you maderfaker`
            logic = 'Halo! Halo semua!!! Telah lama lama! Aku adalah Gawr Gura dari Hololive EN! Baiklah? Ya! Saya adalah gadis hiu dari Hololive EN. Sejujurnya, saya adalah shork, tapi kita hanya tidak akan membicarakannya, oke? Baiklah! Jadi, ada banyak hal menyenangkan yang saya suka lakukan, misalnya, streaming, memasak, dan banyak lagi'
			var { data } = await axios.get(`https://aemt.me/prompt/gpt?prompt=${q}&text=${logic}`)
			m.reply(`${data.result}`.trim())
			}
			break
case 'joox': case 'jooxdl': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw 'No Query Title'
                m.reply(mess.wait)
                let anu = await fetchJson(api('zenz', '/downloader/joox', { query: text }, 'apikey'))
                let msg = await sky.sendImage(m.chat, anu.result.img, `⭔ Title : ${anu.result.lagu}\n⭔ Album : ${anu.result.album}\n⭔ Singer : ${anu.result.penyanyi}\n⭔ Publish : ${anu.result.publish}\n⭔ Lirik :\n${anu.result.lirik.result}`, m)
                sky.sendMessage(m.chat, { audio: { url: anu.result.mp4aLink }, mimetype: 'audio/mpeg', fileName: anu.result.lagu+'.m4a' }, { quoted: msg })
            }
            break
            case 'joox': case 'jooxdl': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw 'No Query Title'
                m.reply(mess.wait)
                let anu = await fetchJson(api('zenz', '/downloader/joox', { query: text }, 'apikey'))
                let msg = await sky.sendImage(m.chat, anu.result.img, `⭔ Title : ${anu.result.lagu}\n⭔ Album : ${anu.result.album}\n⭔ Singer : ${anu.result.penyanyi}\n⭔ Publish : ${anu.result.publish}\n⭔ Lirik :\n${anu.result.lirik.result}`, m)
                sky.sendMessage(m.chat, { audio: { url: anu.result.mp4aLink }, mimetype: 'audio/mpeg', fileName: anu.result.lagu+'.m4a' }, { quoted: msg })
            }
            break
        // Owner Fitur
            case 'soundcloud': case 'scdl': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw 'No Query Title'
                m.reply(mess.wait)
                let anu = await fetchJson(api('zenz', '/downloader/soundcloud', { url: isUrl(text)[0] }, 'apikey'))
                let msg = await sky.sendImage(m.chat, anu.result.thumb, `⭔ Title : ${anu.result.title}\n⭔ Url : ${isUrl(text)[0]}`)
                sky.sendMessage(m.chat, { audio: { url: anu.result.url }, mimetype: 'audio/mpeg', fileName: anu.result.title+'.m4a' }, { quoted: msg })
            }
            break			   
	   case 'twitdl': case 'twitter': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
			  if (!text) throw 'Masukkan Query Link!'
			m.reply(mess.wait)
			let anu = await fetchJson(`https://api.lolhuman.xyz/api/twitter?apikey=GataDios&url=${args[0]}`)
				sky.sendMessage(m.chat, { video: { url: anu.result.media[0].url }, mimetype: 'video/mp4' })					
			}
			break  
            case 'twittermp3': case 'twitteraudio': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw 'Masukkan Query Link!'
                m.reply(mess.wait)
                let anu = await fetchJson(api('zenz', '/api/downloader/twitter', { url: text }, 'apikey'))
                let Message = {
		    image: { url: anu.result.thumb },
                    caption: util.format(anu.result)
                }
                let msg = await sky.sendMessage(m.chat, Message, { quoted: m })
                sky.sendMessage(m.chat, { audio: { url: anu.result.audio } }, { quoted: msg })
            }
            break
	        case 'fbdl': case 'fb': case 'facebook': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw 'Masukkan Query Link!'
                m.reply(mess.wait)
                let anu = await fetchJson(api('zenz', '/api/downloader/facebook', { url: text }, 'apikey'))
                sky.sendMessage(m.chat, { video: { url: anu.result.url }, caption: `⭔ Title : ${anu.result.title}`}, { quoted: m })
            }
            break
	        
        case 'ringtone': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!text) throw `Example : ${prefix + command} black rover`
        let { ringtone } = require('./lib/scraper')
		let anu = await ringtone(text)
		let result = anu[Math.floor(Math.random() * anu.length)]
		sky.sendMessage(m.chat, { audio: { url: result.audio }, fileName: result.title+'.mp3', mimetype: 'audio/mpeg' }, { quoted: m })
	    }
	    break
		case 'alquran':
			if (args1.length < 1) return m.reply(`Example: ${prefix + command} 18 or ${prefix + command} 18/10 or ${prefix + command} 18/1-10`)
			m.reply(mess.wait)
			axios
				.get(`https://api.lolhuman.xyz/api/quran/${args[0]}?apikey=GataDios`)
				.then(({ data }) => {
					var ayat = data.result.ayat
					var text = `QS. ${data.result.surah} : 1-${ayat.length}\n\n`
					for (var x of ayat) {
						text += `${x.arab}\n${x.ayat}. ${x.latin}\n${x.indonesia}\n\n`
					}
					text = text.replace(/<u>/g, '_').replace(/<\/u>/g, '_')
					text = text.replace(/<strong>/g, '*').replace(/<\/strong>/g, '*')
					m.reply(text)
				})
				.catch(console.error)
            break
		case 'tafsirsurah': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!args[0]) throw `Contoh penggunaan:\n${prefix + command} 1 2\n\nmaka hasilnya adalah tafsir surah Al-Fatihah ayat 2`
		if (!args[1]) throw `Contoh penggunaan:\n${prefix + command} 1 2\n\nmaka hasilnya adalah tafsir surah Al-Fatihah ayat 2`
		let res = await fetchJson(`https://islamic-api-indonesia.herokuapp.com/api/data/quran?surah=${args[0]}&ayat=${args[1]}`)
		let txt = `「 *Tafsir Surah*  」

*Pendek* : ${res.result.data.tafsir.id.short}

*Panjang* : ${res.result.data.tafsir.id.long}

( Q.S ${res.result.data.surah.name.transliteration.id} : ${res.result.data.number.inSurah} )`
		m.reply(txt)
		}
		break
		   case 'bass': case 'blown': case 'deep': case 'earrape': case 'fast': case 'fat': case 'nightcore': case 'reverse': case 'robot': case 'slow': case 'smooth': case 'tupai': case 'echo': case 'lowpass': case 'highpass': case 'chorus':
                try {
                let set
                if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20'
                if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log'
                if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3'
                if (/earrape/.test(command)) set = '-af volume=12'
                if (/lowpass/.test(command)) set = '-af lowpass=200'
                if (/highpass/.test(command)) set = '-af highpass=200'
                if (/chorus/.test(command)) set = '-af chorus=0.7:0.7:20:0.5:0.25:2';
                if (/echo/.test(command)) set = '-af aecho=0.8:0.9:1000:0.3';                
                if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"'
                if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"'
                if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25'
                if (/reverse/.test(command)) set = '-filter_complex "areverse"'
                if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"'
                if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"'
                if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"'
                if (/tupai/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"'
                if (/audio/.test(mime)) {
                m.reply(mess.wait)
                let media = await sky.downloadAndSaveMediaMessage(qmsg)
                let ran = getRandom('.mp3')
                exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
                fs.unlinkSync(media)
                if (err) return m.reply(err)
                let buff = fs.readFileSync(ran)
                sky.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted : m })
                fs.unlinkSync(ran)
                })
                } else m.reply(`Balas audio yang ingin diubah dengan caption *${prefix + command}*`)
                } catch (e) {
                m.reply(e)
                }
                break
            case 'setcmd': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.quoted) throw 'Reply Pesan!'
                if (!m.quoted.fileSha256) throw 'SHA256 Hash Missing'
                if (!text) throw `Untuk Command Apa?`
                let hash = m.quoted.fileSha256.toString('base64')
                if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) throw 'You have no permission to change this sticker command'
                global.db.data.sticker[hash] = {
                    text,
                    mentionedJid: m.mentionedJid,
                    creator: m.sender,
                    at: + new Date,
                    locked: false,
                }
                m.reply(`Done!`)
            }
            break
            case 'delcmd': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let hash = m.quoted.fileSha256.toString('base64')
                if (!hash) throw `Tidak ada hash`
                if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) throw 'You have no permission to delete this sticker command'              
                delete global.db.data.sticker[hash]
                m.reply(`Done!`)
            }
            break
            case 'listcmd': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let teks = `
*List Hash*
Info: *bold* hash is Locked
${Object.entries(global.db.data.sticker).map(([key, value], index) => `${index + 1}. ${value.locked ? `*${key}*` : key} : ${value.text}`).join('\n')}
`.trim()
                sky.sendText(m.chat, teks, m, { mentions: Object.values(global.db.data.sticker).map(x => x.mentionedJid).reduce((a,b) => [...a, ...b], []) })
            }
            break
            case 'lockcmd': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) throw mess.owner
                if (!m.quoted) throw 'Reply Pesan!'
                if (!m.quoted.fileSha256) throw 'SHA256 Hash Missing'
                let hash = m.quoted.fileSha256.toString('base64')
                if (!(hash in global.db.data.sticker)) throw 'Hash not found in database'
                global.db.data.sticker[hash].locked = !/^un/i.test(command)
                m.reply('Done!')
            }
            break
            case 'addmsg': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.quoted) throw 'Reply Message Yang Ingin Disave Di Database'
                if (!text) throw `Example : ${prefix + command} nama file`
                let msgs = global.db.data.database
                if (text.toLowerCase() in msgs) throw `'${text}' telah terdaftar di list pesan`
                msgs[text.toLowerCase()] = quoted.fakeObj
m.reply(`Berhasil menambahkan pesan di list pesan sebagai '${text}'
    
Akses dengan ${prefix}getmsg ${text}

Lihat list Pesan Dengan ${prefix}listmsg`)
            }
            break
            case 'getmsg': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} file name\n\nLihat list pesan dengan ${prefix}listmsg`
                let msgs = global.db.data.database
                if (!(text.toLowerCase() in msgs)) throw `'${text}' tidak terdaftar di list pesan`
                sky.copyNForward(m.chat, msgs[text.toLowerCase()], true)
            }
            break
            case 'listmsg': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let msgs = JSON.parse(fs.readFileSync('./database1.json'))
	        let seplit = Object.entries(global.db.data.database).map(([nama, isi]) => { return { nama, ...isi } })
		let teks = '「 LIST DATABASE 」\n\n'
		for (let i of seplit) {
		    teks += `⬡ *Name :* ${i.nama}\n⬡ *Type :* ${getContentType(i.message).replace(/Message/i, '')}\n────────────────────────\n\n`
	        }
	        m.reply(teks)
	    }
	    break
            case 'delmsg': case 'deletemsg': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
	        let msgs = global.db.data.database
	        if (!(text.toLowerCase() in msgs)) return m.reply(`'${text}' tidak terdaftar didalam list pesan`)
		delete msgs[text.toLowerCase()]
		m.reply(`Berhasil menghapus '${text}' dari list pesan`)
            }
	    break
	    case 'anonymous': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (m.isGroup) return m.reply('Fitur Tidak Dapat Digunakan Untuk Group!')
                m.reply(`\`\`\`Hi ${await sky.getName(m.sender)} Welcome To Anonymous Chat\n\nKetik ${prefix}start Untuk Mencari Partner\`\`\``)
            }
			break
            case 'keluar': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (m.isGroup) return m.reply('Fitur Tidak Dapat Digunakan Untuk Group!')
                let room = Object.values(db.data.anonymous).find(room => room.check(m.sender))
                if (!room) {
                    m.reply(`\`\`\`Kamu Sedang Tidak Berada Di Sesi Anonymous, Ketik ${prefix}start Untuk Mencari Partner \`\`\``)
                    throw false
                }
                m.reply('Ok')
                let other = room.other(m.sender)
                if (other) await sky.sendText(other, `\`\`\`Partner Telah Meninggalkan Sesi Anonymous\`\`\``, m)
                delete db.data.anonymous[room.id]
                if (command === 'leave') break
            }
            case 'mulai': case 'start': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (m.isGroup) return m.reply('Fitur Tidak Dapat Digunakan Untuk Group!')
                if (Object.values(db.data.anonymous).find(room => room.check(m.sender))) {
                    m.reply(`\`\`\`Kamu Masih Berada Di dalam Sesi Anonymous, ketik ${prefix}keluar Untuk Menghentikan Sesi Anonymous Anda\`\`\``)
                    throw false
                }
                let room = Object.values(db.data.anonymous).find(room => room.state === 'WAITING' && !room.check(m.sender))
                if (room) {
                    sky.sendText(room.a, `\`\`\`Berhasil Menemukan Partner, sekarang kamu dapat mengirim pesan\n\nKetik ${prefix}start untuk next\nKetik ${prefix}keluar untuk keluar dari sesi anonymous.\`\`\``, m)
                    room.b = m.sender
                    room.state = 'CHATTING'
                    await sky.sendText(room.b, `\`\`\`Berhasil Menemukan Partner, sekarang kamu dapat mengirim pesan\n\nKetik ${prefix}start untuk next\nKetik ${prefix}keluar untuk keluar dari sesi anonymous.\`\`\``, m)
                } else {
                    let id = + new Date
                    db.data.anonymous[id] = {
                        id,
                        a: m.sender,
                        b: '',
                        state: 'WAITING',
                        check: function (who = '') {
                            return [this.a, this.b].includes(who)
                        },
                        other: function (who = '') {
                            return who === this.a ? this.b : who === this.b ? this.a : ''
                        },
                    }
                    m.reply(`\`\`\`Mohon Tunggu Sedang Mencari Partner\`\`\``)
                }
                break
            }
            case 'next': case 'lanjut': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (m.isGroup) return m.reply('Fitur Tidak Dapat Digunakan Untuk Group!')
                let romeo = Object.values(db.data.anonymous).find(room => room.check(m.sender))
                if (!romeo) {
                    m.reply(`\`\`\`Kamu Sedang Tidak Berada Di Sesi Anonymous, ketik ${prefix}start Untuk Mencari Partner\`\`\``)
                    throw false
                }
                let other = romeo.other(m.sender)
                if (other) await sky.sendText(other, `\`\`\`Partner Telah Meninggalkan Sesi Anonymous\`\`\``, m)
                delete db.data.anonymous[romeo.id]
                let room = Object.values(db.data.anonymous).find(room => room.state === 'WAITING' && !room.check(m.sender))
                if (room) {
                    await sky.sendText(room.a, `\`\`\`Berhasil Menemukan Partner, sekarang kamu dapat mengirim pesan\n\nKetik ${prefix}start untuk next\nKetik ${prefix}keluar untuk keluar dari sesi anonymous.\`\`\``, m)
                    room.b = m.sender
                    room.state = 'CHATTING'
                    await sky.sendText(room.b, `\`\`\`Berhasil Menemukan Partner, sekarang kamu dapat mengirim pesan\n\nKetik ${prefix}start untuk next\nKetik ${prefix}keluar untuk keluar dari sesi anonymous.\`\`\``, m)
                } else {
                    let id = + new Date
                    db.data.anonymous[id] = {
                        id,
                        a: m.sender,
                        b: '',
                        state: 'WAITING',
                        check: function (who = '') {
                            return [this.a, this.b].includes(who)
                        },
                        other: function (who = '') {
                            return who === this.a ? this.b : who === this.b ? this.a : ''
                        },
                    }
                    m.reply(`\`\`\`Mohon Tunggu Sedang Mencari Partner\`\`\``)
                }
                break
            }
            case 'public': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) throw mess.owner
                sky.public = true
                m.reply('Sukse Change To Public Usage')
            }
            break
            case 'self': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) throw mess.owner
                sky.public = false
                m.reply('Sukses Change To Self Usage')
            }
            break
                        case 'speedtest': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            m.reply('Testing Speed...')
            let cp = require('child_process')
            let { promisify } = require('util')
            let exec = promisify(cp.exec).bind(cp)
          let o
          try {
          o = await exec('python speed.py')
          } catch (e) {
          o = e
         } finally {
        let { stdout, stderr } = o
        if (stdout.trim()) m.reply(stdout)
        if (stderr.trim()) m.reply(stderr)
            }
            }
            break
case 'tagkontak': case 'randomkontak': {
    if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
    
    const count = parseInt(args[0]); // Mengambil jumlah kontak dari argumen yang diberikan
    
    if (isNaN(count) || count <= 0) {
        return m.reply('Masukkan jumlah kontak yang valid.');
    }
    
    for (let i = 0; i < count; i++) {
        var name;
        
        if (text) {
            name = text;
        } else {
            name = sky.getName(m.sender);
        }
        
        let member = participants.map(u => u.id);
        let me = m.sender;
        let jodoh = member[crypto.randomInt(0, member.length)];
        var number = jodoh.split('@')[0];
        let vcard = `
BEGIN:VCARD
VERSION:3.0
FN:@${number}
TEL;type=CELL;type=VOICE;waid=${number}:${me.split('@')[0]}
END:VCARD`;

        // Menunda pengiriman setiap kontak dengan jeda 2 detik (2000 milidetik)
        setTimeout(() => {
            sky.sendMessage(m.chat, { contacts: { displayName: name, contacts: [{ vcard }] } }, { quoted: fkontak });
        }, i * 1000); // Ini akan mengirimkan kontak pertama segera, kontak kedua setelah 2 detik, kontak ketiga setelah 4 detik, dan seterusnya.
    }
}
break;

case 'owner': case 'creator': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
              var name
  if (text) name = text
  else name = sky.getName(m.sender)
  let me = m.sender
	var number = m.sender.split('@')[0]
	let vcard = `
BEGIN:VCARD
VERSION:3.0
FN:${name.replace(/\n/g, '\\n')}
TEL;type=CELL;type=VOICE;waid=${number}:${me.split('@')[0]}
END:VCARD`
   sky.sendMessage(m.chat, { contacts: { displayName: name, contacts: [{ vcard }]}}, { quoted: m })

}
break
case 'playstore':{
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!text) throw `Example : ${prefix + command} clash of clans`
            let res = await fetch(`https://api.betabotz.org/api/search/playstore?app=${text}&apikey=2fbgCgOB`)
            let data = await res.json()
            let teks = `⭔ Playstore Search From : ${text}\n\n`
            for (let i of data.result) {
            teks += `⭔ Name : ${i.nama}\n`
            teks += `⭔ Link : ${i.link}\n`
            teks += `⭔ Developer : ${i.developer}\n`
            teks += `⭔ Link Developer : ${i.link_dev}\n\n──────────────────────\n`
            }
            m.reply(teks)
            }
            break
            case 'happymod':{
if (isBan) return m.reply('Lu Di Ban Owner Gausa So sik')
            if (!text) throw `Example : ${prefix + command} clash of clans`
          let res = await fetch(`https://api.betabotz.org/api/search/happymod?query=${text}&apikey=2fbgCgOB`)
          let data = await res.json()
            let teks = `⭔ HappyMod Search From : ${text}\n\n`
            for (let i of data.result) {
            teks += `*Title* : ${i.title}\n`
teks += `*Rating* : ${i.rating}\n`
teks += `*Link* : ${i.link}\n`
teks += `*Icon* : ${i.icon}\n\n───────────────\n\n`
}
            m.reply(teks)
            }
            break
case 'wattpad': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
if (!text) throw `Example : ${prefix + command} selingkuh`
let res = await fetch(`https://api.betabotz.org/api/webzone/wattpad?query=${text}&apikey=2fbgCgOB`)
let data = await res.json()
            let teks = `Wattpad\n\n`
            for (let i of data.result){
teks += `*Judul* : ${i.judul}\n`
teks += `*Dibaca* : ${i.dibaca}×\n`
teks += `*Divote* : ${i.divote}×\n`
teks += `*Thumb* : ${i.thumb}\n`
teks += `*Link* : ${i.link}\n\n`
            }
m.reply(teks)
            }
            break
            case 'jadwalbioskop': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!text) throw `Example: ${prefix + command} jakarta`
            let res = await fetchJson(api('zenz', '/webzone/jadwalbioskop', { kota: text }, 'apikey'))
            let capt = `Jadwal Bioskop From : ${text}\n\n`
            for (let i of res.result){
            capt += `⭔ Title: ${i.title}\n`
            capt += `⭔ Thumbnail: ${i.thumb}\n`
            capt += `⭔ Url: ${i.url}\n\n──────────────────────\n`
            }
            sky.sendImage(m.chat, res.result[0].thumb, capt, m)
            }
            break
            case 'nowplayingbioskop': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            let res = await fetchJson(api('zenz', '/webzone/nowplayingbioskop', {}, 'apikey'))
            let capt = `Now Playing Bioskop\n\n`
            for (let i of res.result){
            capt += `⭔ Title: ${i.title}\n`
            capt += `⭔ Url: ${i.url}\n`
            capt += `⭔ Img Url: ${i.img}\n\n──────────────────────\n`
            }
            sky.sendImage(m.chat, res.result[0].img, capt, m)
            }
            break
            default:
                if (budy.startsWith('=>')) {
                    if (!isCreator) return m.reply(mess.owner)
                    function Return(sul) {
                        sat = JSON.stringify(sul, null, 2)
                        bang = util.format(sat)
                            if (sat == undefined) {
                                bang = util.format(sul)
                            }
                            return m.reply(bang)
                    }
                    try {
                        m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
                    } catch (e) {
                        m.reply(String(e))
                    }
                }

                if (budy.startsWith('>')) {
                    if (!isCreator) return m.reply(mess.owner)
                    try {
                        let evaled = await eval(budy.slice(2))
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                        await m.reply(evaled)
                    } catch (err) {
                        await m.reply(String(err))
                    }
                }

                if (budy.startsWith('$')) {
                    if (!isCreator) return m.reply(mess.owner)
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return m.reply(`${err}`)
                        if (stdout) return m.reply(stdout)
                    })
                }			
		if (isCmd && budy.toLowerCase() != undefined) {
		    if (m.chat.endsWith('broadcast')) return
		    if (m.isBaileys) return
		    let msgs = global.db.data.database
		    if (!(budy.toLowerCase() in msgs)) return
		    sky.copyNForward(m.chat, msgs[budy.toLowerCase()], true)
		}
        }
        

    } catch (err) {
        m.reply(util.format(err))
    }
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})